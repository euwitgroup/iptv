<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_users' => \App\Models\User::where('role', 'user')->count(),
            'active_emails' => \App\Models\TempEmailHistory::where('expires_at', '>', now())->count(),
            'providers_count' => \App\Models\Provider::count(),
            'active_providers' => \App\Models\Provider::where('is_active', true)->count(),
            'total_generated' => \App\Models\TempEmailHistory::count(),
            'total_messages' => \App\Models\TempEmailHistory::sum('messages_count'),
        ];

        $recent_activity = \App\Models\TempEmailHistory::latest('generated_at')
            ->take(10)
            ->with('user') // Assuming relation exists, if not optional
            ->get();

        $top_providers = \App\Models\TempEmailHistory::select('provider_slug', \Illuminate\Support\Facades\DB::raw('count(*) as total'))
            ->groupBy('provider_slug')
            ->orderByDesc('total')
            ->take(5)
            ->get();

        return view('admin.dashboard', compact('stats', 'recent_activity', 'top_providers'));
    }
}
