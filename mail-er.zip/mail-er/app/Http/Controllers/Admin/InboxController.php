<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TempEmailHistory;
use Illuminate\Http\Request;

class InboxController extends Controller
{
    public function index()
    {
        $emails = TempEmailHistory::with('user')
            ->orderBy('generated_at', 'desc')
            ->paginate(20);

        return view('admin.inbox.index', compact('emails'));
    }

    public function show($id)
    {
        $email = TempEmailHistory::findOrFail($id);
        return view('admin.inbox.show', compact('email'));
    }
}
