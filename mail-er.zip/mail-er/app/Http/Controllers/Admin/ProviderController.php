<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Provider;
use Illuminate\Http\Request;

class ProviderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $providers = Provider::orderBy('priority', 'asc')->get();
        return view('admin.providers.index', compact('providers'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Define available drivers
        $drivers = [
            'App\Services\TempMail\Drivers\MailTmDriver' => 'Mail.tm',
            'App\Services\TempMail\Drivers\OneSecMailDriver' => '1secmail',
            // Add other drivers here in future
        ];

        return view('admin.providers.create', compact('drivers'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:providers',
            'driver_class' => 'required|string',
            'priority' => 'integer',
            // 'is_active' => 'boolean',
            'features' => 'nullable|array'
        ]);

        $validated['is_active'] = $request->has('is_active');
        $validated['features'] = $request->features ?? [];

        Provider::create($validated);

        return redirect()->route('admin.providers.index')->with('success', 'Provider created successfully.');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Provider $provider)
    {
        $drivers = [
            'App\Services\TempMail\Drivers\MailTmDriver' => 'Mail.tm',
            'App\Services\TempMail\Drivers\OneSecMailDriver' => '1secmail',
        ];

        return view('admin.providers.edit', compact('provider', 'drivers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Provider $provider)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:providers,slug,' . $provider->id,
            'driver_class' => 'required|string',
            'priority' => 'integer',
            // 'is_active' => 'boolean', // Checkbox sends 'on', handled manually below
            'api_key' => 'nullable|string',
            'base_url' => 'nullable|url',
        ]);

        $validated['is_active'] = $request->has('is_active');

        $provider->update($validated);

        return redirect()->route('admin.providers.index')->with('success', 'Provider updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Provider $provider)
    {
        $provider->delete();
        return redirect()->route('admin.providers.index')->with('success', 'Provider deleted.');
    }
}
