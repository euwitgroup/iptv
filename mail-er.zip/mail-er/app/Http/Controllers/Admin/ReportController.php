<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TempEmailHistory;
use App\Models\Provider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function index()
    {
        // 1. Overview Stats
        $stats = [
            'total_emails' => TempEmailHistory::count(),
            'total_messages' => TempEmailHistory::sum('messages_count'),
            'emails_today' => TempEmailHistory::whereDate('generated_at', Carbon::today())->count(),
            'messages_today' => TempEmailHistory::whereDate('last_checked_at', Carbon::today())->sum('messages_count'), // Approximate
        ];

        // 2. Provider Distribution (Pie Chart / List)
        $providerStats = TempEmailHistory::select('provider_slug', DB::raw('count(*) as count'))
            ->groupBy('provider_slug')
            ->orderByDesc('count')
            ->get();

        // 3. Activity last 7 days (Line Chart)
        $emailsPerDay = TempEmailHistory::select(DB::raw('DATE(generated_at) as date'), DB::raw('count(*) as count'))
            ->where('generated_at', '>=', Carbon::now()->subDays(7))
            ->groupBy('date')
            ->orderBy('date', 'asc')
            ->get();

        // 4. Fill missing dates for chart
        $chartData = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i)->format('Y-m-d');
            $record = $emailsPerDay->firstWhere('date', $date);
            $chartData['labels'][] = Carbon::parse($date)->format('M d');
            $chartData['data'][] = $record ? $record->count : 0;
        }

        return view('admin.reports.index', compact('stats', 'providerStats', 'chartData'));
    }
}
