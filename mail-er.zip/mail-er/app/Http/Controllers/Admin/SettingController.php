<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index()
    {
        $settings = Setting::all()->groupBy('group');
        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        $data = $request->except(['_token', '_method']);

        // Handle File Uploads
        $files = ['site_logo', 'site_favicon'];
        foreach ($files as $fileKey) {
            if ($request->hasFile($fileKey)) {
                // Store file
                $path = $request->file($fileKey)->store('uploads/settings', 'public');

                // Update DB
                Setting::updateOrCreate(
                    ['key' => $fileKey],
                    ['value' => 'storage/' . $path]
                );

                // Remove from processed data
                unset($data[$fileKey]);
            }
        }

        foreach ($data as $key => $value) {
            if ($key === 'site_logo' || $key === 'site_favicon')
                continue; // Skip if in data but no file uploaded (handled above)

            Setting::updateOrCreate(
                ['key' => $key],
                ['value' => is_array($value) ? json_encode($value) : $value]
            );
        }

        return redirect()->back()->with('success', 'Settings updated successfully.');
    }
}
