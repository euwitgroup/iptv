<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;

class SocialLoginController extends Controller
{
    /**
     * Redirect to the OAuth provider
     *
     * @param string $provider (google, facebook, etc.)
     * @return \Illuminate\Http\RedirectResponse
     */
    public function redirect($provider)
    {
        // Validate provider
        if (!in_array($provider, ['google', 'facebook'])) {
            flash()->error('Invalid social login provider');
            return redirect()->route('login');
        }

        try {
            return Socialite::driver($provider)->redirect();
        } catch (\Exception $e) {
            flash()->error('Social login is not configured properly: ' . $e->getMessage());
            return redirect()->route('login');
        }
    }

    /**
     * Handle the OAuth provider callback
     *
     * @param string $provider
     * @return \Illuminate\Http\RedirectResponse
     */
    public function callback($provider)
    {
        // Validate provider
        if (!in_array($provider, ['google', 'facebook'])) {
            flash()->error('Invalid social login provider');
            return redirect()->route('login');
        }

        try {
            // Get user data from provider
            $socialUser = Socialite::driver($provider)->user();

            // Find or create user
            $user = $this->findOrCreateUser($socialUser, $provider);

            // Login user
            Auth::login($user, true);

            // Success notification
            flash()->success('Welcome back, ' . $user->name . '!');

            // Redirect to dashboard or intended page
            return redirect()->intended('/dashboard');

        } catch (\Exception $e) {
            flash()->error('Failed to authenticate with ' . ucfirst($provider) . ': ' . $e->getMessage());
            return redirect()->route('login');
        }
    }

    /**
     * Find existing user or create new one
     *
     * @param object $socialUser
     * @param string $provider
     * @return \App\Models\User
     */
    protected function findOrCreateUser($socialUser, $provider)
    {
        // Try to find user by provider ID
        $user = User::where('provider', $provider)
            ->where('provider_id', $socialUser->getId())
            ->first();

        if ($user) {
            // Update user data if needed
            $user->update([
                'avatar' => $socialUser->getAvatar(),
            ]);
            return $user;
        }

        // Try to find user by email
        $user = User::where('email', $socialUser->getEmail())->first();

        if ($user) {
            // Link social account to existing user
            $user->update([
                'provider' => $provider,
                'provider_id' => $socialUser->getId(),
                'avatar' => $socialUser->getAvatar(),
            ]);
            return $user;
        }

        // Create new user
        return User::create([
            'name' => $socialUser->getName(),
            'email' => $socialUser->getEmail(),
            'provider' => $provider,
            'provider_id' => $socialUser->getId(),
            'avatar' => $socialUser->getAvatar(),
            'password' => Hash::make(Str::random(24)), // Random password
            'email_verified_at' => now(), // Auto-verify social logins
        ]);
    }
}
