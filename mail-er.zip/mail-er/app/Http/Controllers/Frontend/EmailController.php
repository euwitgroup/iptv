<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Services\TempMail\TempMailService;
use Illuminate\Http\Request;

class EmailController extends Controller
{
    protected $service;

    public function __construct(TempMailService $service)
    {
        $this->service = $service;
    }

    public function domains()
    {
        try {
            return response()->json($this->service->getAvailableDomains());
        } catch (\Exception $e) {
            return response()->json([], 500);
        }
    }

    public function generate(Request $request)
    {
        \Illuminate\Support\Facades\Log::info('Email generation request received.');
        try {
            $domain = $request->input('domain') ? strtolower($request->input('domain')) : null;
            $provider = $request->input('provider');

            $data = $this->service->generate($domain, $provider);

            \Illuminate\Support\Facades\Log::info('Email generated successfully: ' . $data['email']);
            return response()->json([
                'success' => true,
                'email' => $data['email'],
                'provider' => $data['provider_slug']
            ]);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Email generation failed: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function messages(Request $request)
    {
        try {
            $messages = $this->service->checkMessages();
            return response()->json([
                'success' => true,
                'messages' => $messages
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'messages' => []]);
        }
    }

    public function current()
    {
        $email = $this->service->getEmailAddress();
        if ($email) {
            return response()->json(['success' => true, 'email' => $email]);
        }
        return response()->json(['success' => false]);
    }

    public function getMessage(Request $request, $id)
    {
        try {
            $message = $this->service->getMessage($id);
            return response()->json([
                'success' => true,
                'message' => $message
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
