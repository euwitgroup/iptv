<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\User;

class InstallerController extends Controller
{
    public function welcome()
    {
        return view('installer.welcome');
    }

    public function requirements()
    {
        $requirements = [
            'php' => version_compare(PHP_VERSION, '8.0.0', '>='),
            'bcmath' => extension_loaded('bcmath'),
            'ctype' => extension_loaded('ctype'),
            'fileinfo' => extension_loaded('fileinfo'),
            'json' => extension_loaded('json'),
            'mbstring' => extension_loaded('mbstring'),
            'openssl' => extension_loaded('openssl'),
            'pdo' => extension_loaded('pdo'),
            'pdo_mysql' => extension_loaded('pdo_mysql'),
            'tokenizer' => extension_loaded('tokenizer'),
            'xml' => extension_loaded('xml'),
            'curl' => extension_loaded('curl'),
        ];

        $permissions = [
            'storage/framework' => is_writable(storage_path('framework')),
            'storage/logs' => is_writable(storage_path('logs')),
            'bootstrap/cache' => is_writable(base_path('bootstrap/cache')),
        ];

        $allRequirementsMet = !in_array(false, $requirements);
        $allPermissionsSet = !in_array(false, $permissions);

        return view('installer.requirements', compact('requirements', 'permissions', 'allRequirementsMet', 'allPermissionsSet'));
    }

    public function database()
    {
        return view('installer.database');
    }

    public function databaseStore(Request $request)
    {
        $validated = $request->validate([
            'db_host' => 'required',
            'db_port' => 'required|numeric',
            'db_name' => 'required',
            'db_user' => 'required',
            'db_password' => 'nullable',
        ]);

        try {
            // Test connection
            $connection = @mysqli_connect(
                $validated['db_host'],
                $validated['db_user'],
                $validated['db_password'],
                $validated['db_name'],
                $validated['db_port']
            );

            if (!$connection) {
                return back()->withErrors(['error' => 'Database connection failed: ' . mysqli_connect_error()]);
            }

            mysqli_close($connection);

            // Update .env file
            $this->updateEnvFile([
                'DB_HOST' => $validated['db_host'],
                'DB_PORT' => $validated['db_port'],
                'DB_DATABASE' => $validated['db_name'],
                'DB_USERNAME' => $validated['db_user'],
                'DB_PASSWORD' => $validated['db_password'],
            ]);

            // Clear config cache
            Artisan::call('config:clear');

            // Run migrations
            Artisan::call('migrate', ['--force' => true]);

            // Seed database
            Artisan::call('db:seed', ['--class' => 'DatabaseSeeder', '--force' => true]);

            return redirect()->route('installer.admin')->with('success', 'Database configured successfully!');

        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function admin()
    {
        return view('installer.admin');
    }

    public function adminStore(Request $request)
    {
        $validated = $request->validate([
            'app_name' => 'required|string|max:255',
            'app_url' => 'required|url',
            'admin_name' => 'required|string|max:255',
            'admin_email' => 'required|email|unique:users,email',
            'admin_password' => 'required|min:8|confirmed',
        ]);

        try {
            // Update .env
            $this->updateEnvFile([
                'APP_NAME' => '"' . $validated['app_name'] . '"',
                'APP_URL' => $validated['app_url'],
                'APP_ENV' => 'production',
                'APP_DEBUG' => 'false',
            ]);

            // Generate APP_KEY
            Artisan::call('key:generate', ['--force' => true]);

            // Create admin user
            User::create([
                'name' => $validated['admin_name'],
                'email' => $validated['admin_email'],
                'password' => bcrypt($validated['admin_password']),
                'role' => 'admin',
            ]);

            return redirect()->route('installer.finish')->with('success', 'Admin user created successfully!');

        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function finish()
    {
        return view('installer.finish');
    }

    public function complete()
    {
        try {
            // Run optimization commands
            Artisan::call('storage:link');
            Artisan::call('config:cache');
            Artisan::call('route:cache');
            Artisan::call('view:cache');

            // Create installation lock file
            File::put(storage_path('installed'), date('Y-m-d H:i:s'));

            // Optionally delete installer files (commented for safety)
            // File::deleteDirectory(resource_path('views/installer'));
            // File::delete(app_path('Http/Controllers/InstallerController.php'));
            // File::delete(app_path('Http/Middleware/CheckInstalled.php'));

            return response()->json([
                'success' => true,
                'message' => 'Installation completed successfully!',
                'redirect' => url('/admin/login')
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    private function updateEnvFile(array $data)
    {
        $envPath = base_path('.env');

        if (!File::exists($envPath)) {
            File::copy(base_path('.env.example'), $envPath);
        }

        $envContent = File::get($envPath);

        foreach ($data as $key => $value) {
            // Escape special characters in value
            $value = str_replace('$', '\$', $value);

            if (str_contains($envContent, $key . '=')) {
                // Update existing key
                $envContent = preg_replace(
                    "/^{$key}=.*/m",
                    "{$key}={$value}",
                    $envContent
                );
            } else {
                // Add new key
                $envContent .= "\n{$key}={$value}";
            }
        }

        File::put($envPath, $envContent);
    }
}
