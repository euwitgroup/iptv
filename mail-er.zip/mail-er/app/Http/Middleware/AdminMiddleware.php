<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Check if user is authenticated
        if (!Auth::check()) {
            flash()->error('Please log in to access the admin panel.');
            return redirect()->route('admin.login');
        }

        // Check if user has admin role
        if (!Auth::user()->isAdmin()) {
            flash()->error('You do not have permission to access the admin panel.');
            Auth::logout();
            return redirect()->route('admin.login');
        }

        return $next($request);
    }
}
