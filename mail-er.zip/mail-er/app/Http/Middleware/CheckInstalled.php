<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class CheckInstalled
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $installedFile = storage_path('installed');

        // If installed file exists and trying to access installer
        if (File::exists($installedFile) && $request->is('install*')) {
            return redirect('/')->with('info', 'Application is already installed.');
        }

        // If not installed and trying to access non-installer routes
        if (!File::exists($installedFile) && !$request->is('install*')) {
            return redirect()->route('installer.welcome');
        }

        return $next($request);
    }
}
