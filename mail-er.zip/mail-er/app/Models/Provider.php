<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Provider extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'base_url',
        'api_key',
        'driver_class',
        'is_active',
        'is_default',
        'priority',
        'max_per_day',
        'retention_hours',
        'features',
        'status',
        'last_health_check'
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_default' => 'boolean',
        'features' => 'array',
        'last_health_check' => 'datetime',
    ];
}
