<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TempEmailHistory extends Model
{
    use HasFactory;

    protected $table = 'temp_email_history';

    protected $fillable = [
        'user_id',
        'session_id',
        'email_address',
        'provider_slug',
        'is_favorite',
        'messages_count',
        'generated_at',
        'expires_at',
        'last_checked_at'
    ];

    protected $casts = [
        'is_favorite' => 'boolean',
        'generated_at' => 'datetime',
        'expires_at' => 'datetime',
        'last_checked_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
