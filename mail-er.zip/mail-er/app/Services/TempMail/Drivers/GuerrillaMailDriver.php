<?php

namespace App\Services\TempMail\Drivers;

use App\Services\TempMail\TempMailDriverInterface;
use Illuminate\Support\Facades\Http;

class GuerrillaMailDriver implements TempMailDriverInterface
{
    protected $baseUrl = 'https://api.guerrillamail.com/ajax.php';

    /**
     * Get available domains.
     * Note: Guerrilla Mail usually assigns a domain, but we can try to fetch them or hardcode common ones.
     */
    public function getDomains(): array
    {
        // Guerrilla Mail API randomly assigns domains and cannot reliably target specific ones
        // Hiding from dropdown to prevent user frustration
        // Guerrilla Mail works perfectly in "Random Domain" mode
        return [];
    }

    /**
     * Create a new email address.
     */
    public function createEmail(?string $username = null, ?string $domain = null): array
    {
        // Guerrilla Mail does not support domain selection
        // Always generates random domain

        try {
            $response = Http::withOptions(['verify' => false])
                ->timeout(3)
                ->get("{$this->baseUrl}?f=get_email_address");

            if (!$response->successful()) {
                throw new \Exception('Failed to connect to Guerrilla Mail API');
            }

            $data = $response->json();

            if (!isset($data['email_addr']) || !isset($data['sid_token'])) {
                throw new \Exception('Guerrilla Mail returned invalid response');
            }

            $email = $data['email_addr'];
            $sid = $data['sid_token'];

            // Set custom username if provided
            if ($username) {
                try {
                    $userResponse = Http::withOptions(['verify' => false])
                        ->timeout(3)
                        ->get("{$this->baseUrl}?f=set_email_user&email_user={$username}&lang=en&sid_token={$sid}");

                    if ($userResponse->successful()) {
                        $userData = $userResponse->json();
                        if (isset($userData['email_addr'])) {
                            $email = $userData['email_addr'];
                            $sid = $userData['sid_token'] ?? $sid;
                        }
                    }
                } catch (\Exception $e) {
                    // Username set failed, continue with original email
                }
            }

            return [
                'email' => $email,
                'id' => $email,
                'meta' => [
                    'sid_token' => $sid,
                    'driver' => 'guerrillamail'
                ]
            ];

        } catch (\Exception $e) {
            throw new \Exception('Guerrilla Mail error: ' . $e->getMessage());
        }
    }

    /**
     * Get messages for a specific email.
     */
    public function getMessages(string $email, array $meta = []): array
    {
        if (empty($meta['sid_token'])) {
            return []; // Cannot read without session ID
        }

        // f=get_email_list&offset=0&sid_token=...
        $response = Http::withOptions(['verify' => false])->get("{$this->baseUrl}?f=get_email_list&offset=0&sid_token={$meta['sid_token']}");

        if ($response->successful()) {
            $data = $response->json();
            $list = $data['list'] ?? [];

            return collect($list)->map(function ($msg) {
                return [
                    'id' => $msg['mail_id'],
                    'from' => $msg['mail_from'],
                    'subject' => $msg['mail_subject'],
                    'intro' => $msg['mail_excerpt'] ?? '',
                    'seen' => (bool) ($msg['mail_read'] ?? 0),
                    'created_at' => $msg['mail_date'] ?? now(),
                ];
            })->toArray();
        }

        return [];
    }

    /**
     * Get a specific message content.
     */
    public function getMessage(string $messageId, string $email, array $meta = []): array
    {
        if (empty($meta['sid_token'])) {
            throw new \Exception('Session Token missing');
        }

        // f=fetch_email&email_id=...&sid_token=...
        $response = Http::withOptions(['verify' => false])->get("{$this->baseUrl}?f=fetch_email&email_id={$messageId}&sid_token={$meta['sid_token']}");

        if ($response->successful()) {
            $data = $response->json();
            return [
                'id' => $data['mail_id'],
                'from' => $data['mail_from'],
                'subject' => $data['mail_subject'],
                'body' => $data['mail_body'] ?? '', // Only plain text usually
                'html' => $data['mail_body'] ?? '', // Guerrilla often sends HTML in body
                'attachments' => [] // Attachments logic is complex for Guerrilla, skipping for MVP
            ];
        }

        throw new \Exception('Failed to fetch message');
    }
}
