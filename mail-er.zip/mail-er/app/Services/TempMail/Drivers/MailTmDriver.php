<?php

namespace App\Services\TempMail\Drivers;

use App\Services\TempMail\TempMailDriverInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class MailTmDriver implements TempMailDriverInterface
{
    protected $baseUrl = 'https://api.mail.tm';

    /**
     * Get available domains.
     */
    public function getDomains(): array
    {
        $domains = [];
        $page = 1;

        while ($page <= 3) { // Limit to 3 pages to avoid excessive delay
            try {
                $response = Http::withOptions(['verify' => false])->get("{$this->baseUrl}/domains?page={$page}");

                if ($response->successful()) {
                    $items = $response->json('hydra:member', []);
                    if (empty($items))
                        break;

                    foreach ($items as $item) {
                        $domains[] = $item['domain'];
                    }

                    // Check if next page exists in Hydra LD
                    $view = $response->json('hydra:view', []);
                    if (!isset($view['hydra:next'])) {
                        break;
                    }
                    $page++;
                } else {
                    break;
                }
            } catch (\Exception $e) {
                break; // Stop on error
            }
        }

        return $domains;
    }

    /**
     * Create a new email address.
     */
    public function createEmail(?string $username = null, ?string $domain = null): array
    {
        // 1. Get a domain if not provided
        if (!$domain) {
            $domains = $this->getDomains();
            if (empty($domains)) {
                throw new \Exception('No domains available for Mail.tm');
            }
            $domain = $domains[array_rand($domains)];
        }

        // 2. Generate credentials
        $username = $username ?: Str::random(10);
        $fullEmail = strtolower("{$username}@{$domain}");
        // Ensure strong password to meet potential API requirements
        $password = Str::random(12) . 'Ab1!';

        // 3. Create Account
        $response = Http::withOptions(['verify' => false])->post("{$this->baseUrl}/accounts", [
            'address' => $fullEmail,
            'password' => $password
        ]);

        if (!$response->successful()) {
            // Handle error (e.g., username taken)
            throw new \Exception('Failed to create account: ' . $response->body());
        }

        $remoteId = $response->json('id');

        // 4. Get Auth Token (Important for reading messages later)
        // 4. Get Auth Token (Important for reading messages later)
        // Retry logic for potential propagation delay
        $token = null;
        $attempts = 0;
        $lastBody = '';

        while ($attempts < 3 && !$token) {
            $attempts++;
            if ($attempts > 1) {
                sleep(1); // Wait for propagation
            }

            $tokenResponse = Http::withOptions(['verify' => false])->post("{$this->baseUrl}/token", [
                'address' => $fullEmail,
                'password' => $password
            ]);

            if ($tokenResponse->successful() && $tokenResponse->json('token')) {
                $token = $tokenResponse->json('token');
            } else {
                $lastBody = $tokenResponse->body();
            }
        }

        if (!$token) {
            throw new \Exception('Failed to retrieve Mail.tm token after retries: ' . $lastBody);
        }

        $token = $tokenResponse->json('token');

        return [
            'email' => $fullEmail,
            'id' => $remoteId,
            'meta' => [
                'password' => $password,
                'token' => $token, // JWT Token needed for fetching messages
                'driver' => 'mailtm'
            ]
        ];
    }

    /**
     * Get messages for a specific email.
     */
    public function getMessages(string $email, array $meta = []): array
    {
        if (empty($meta['token'])) {
            return [];
        }

        $response = Http::withOptions(['verify' => false])->withToken($meta['token'])->get("{$this->baseUrl}/messages");

        if ($response->successful()) {
            return collect($response->json('hydra:member', []))->map(function ($msg) {
                return [
                    'id' => $msg['id'],
                    'from' => $msg['from']['address'] ?? 'unknown',
                    'from_name' => $msg['from']['name'] ?? '',
                    'subject' => $msg['subject'] ?? '(No Subject)',
                    'intro' => $msg['intro'] ?? '',
                    'seen' => $msg['seen'] ?? false,
                    'created_at' => $msg['createdAt'],
                ];
            })->toArray();
        }

        return [];
    }

    /**
     * Get a specific message content.
     */
    public function getMessage(string $messageId, string $email, array $meta = []): array
    {
        if (empty($meta['token'])) {
            throw new \Exception('Access token missing.');
        }

        $response = Http::withOptions(['verify' => false])->withToken($meta['token'])->get("{$this->baseUrl}/messages/{$messageId}");

        if ($response->successful()) {
            $data = $response->json();
            return [
                'id' => $data['id'],
                'from' => $data['from']['address'] ?? 'unknown',
                'subject' => $data['subject'] ?? '',
                'body' => $data['text'] ?? '',    // specific to Mail.tm
                'html' => $data['html'] ?? [],    // specific to Mail.tm (might be array)
                'attachments' => $data['attachments'] ?? []
            ];
        }

        throw new \Exception('Failed to fetch message');
    }
}
