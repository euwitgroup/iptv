<?php

namespace App\Services\TempMail\Drivers;

use App\Services\TempMail\TempMailDriverInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class MailsacDriver implements TempMailDriverInterface
{
    protected $baseUrl = 'https://mailsac.com/api';

    public function getDomains(): array
    {
        return ['mailsac.com'];
    }

    public function createEmail(?string $username = null, ?string $domain = null): array
    {
        $domain = 'mailsac.com';
        $username = $username ?: Str::random(10);
        $email = "{$username}@{$domain}";

        // Mailsac public addresses exist automatically.
        // If we want private, we'd need API call with Key.

        return [
            'email' => $email,
            'id' => $email,
            'meta' => [ // Public Mailsac needs no token usually
                'driver' => 'mailsac'
            ]
        ];
    }

    public function getMessages(string $email, array $meta = []): array
    {
        // Public API: GET /addresses/{email}/messages
        // Note: High rate limits or key recommended.
        $response = Http::get("{$this->baseUrl}/addresses/{$email}/messages");

        if ($response->successful()) {
            return collect($response->json())->map(function ($msg) {
                return [
                    'id' => $msg['_id'],
                    'from' => $msg['from'][0]['address'] ?? 'unknown',
                    'subject' => $msg['subject'] ?? '(No Subject)',
                    'intro' => $msg['snippet'] ?? '',
                    'seen' => false, // API doesn't track read status for public
                    'created_at' => $msg['received'] ?? now(),
                ];
            })->toArray();
        }

        return [];
    }

    public function getMessage(string $messageId, string $email, array $meta = []): array
    {
        // Public Text: GET /text/{email}/{messageId}
        // Public HTML: GET /dirty/{email}/{messageId} (Sanitized)

        $textResponse = Http::get("{$this->baseUrl}/text/{$email}/{$messageId}");
        $textBody = $textResponse->successful() ? $textResponse->body() : '';

        // Getting HTML might require separate call or is not always available publicly easily in parsed form via API without Key?
        // Actually, /dirty/{e}/{id} returns HTML.
        $htmlResponse = Http::get("{$this->baseUrl}/dirty/{$email}/{$messageId}");
        $htmlBody = $htmlResponse->successful() ? $htmlResponse->body() : '';

        return [
            'id' => $messageId,
            'from' => 'unknown', // Not provided in body endpoints
            'subject' => '',
            'body' => $textBody,
            'html' => $htmlBody,
            'attachments' => []
        ];
    }
}
