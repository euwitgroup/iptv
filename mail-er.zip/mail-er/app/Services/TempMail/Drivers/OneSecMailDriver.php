<?php

namespace App\Services\TempMail\Drivers;

use App\Services\TempMail\TempMailDriverInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class OneSecMailDriver implements TempMailDriverInterface
{
    protected $baseUrl = 'https://www.1secmail.com/api/v1/';

    public function getDomains(): array
    {
        $response = Http::withOptions(['verify' => false])
            ->withHeaders([
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'application/json, text/plain, */*',
                'Referer' => 'https://www.1secmail.com/',
            ])
            ->get("{$this->baseUrl}?action=getDomainList");

        if ($response->successful()) {
            $domains = $response->json();
            if (!empty($domains)) {
                return $domains;
            }
        }

        // Fallback domains if API fails or empty
        return ['1secmail.com', '1secmail.org', '1secmail.net'];
    }

    public function createEmail(?string $username = null, ?string $domain = null): array
    {
        if (!$domain) {
            $domains = $this->getDomains();
            if (empty($domains)) {
                // Fallback domains if API fails
                $domains = ['1secmail.com', '1secmail.org', '1secmail.net'];
            }
            $domain = $domains[array_rand($domains)];
        }

        $username = $username ?: Str::random(10);
        $fullEmail = "{$username}@{$domain}";

        // No server-side creation needed for 1secmail.
        // We just start polling.

        return [
            'email' => $fullEmail,
            'id' => $fullEmail, // ID is the email itself here
            'meta' => [
                'username' => $username,
                'domain' => $domain,
                'driver' => 'onesecmail'
            ]
        ];
    }

    public function getMessages(string $email, array $meta = []): array
    {
        // Extract username and domain if not in meta
        if (empty($meta['username']) || empty($meta['domain'])) {
            $parts = explode('@', $email);
            if (count($parts) !== 2) {
                \Illuminate\Support\Facades\Log::error('1SecMail: Invalid email format: ' . $email);
                return [];
            }
            $login = $parts[0];
            $domain = $parts[1];
        } else {
            $login = $meta['username'];
            $domain = $meta['domain'];
        }

        $url = "{$this->baseUrl}?action=getMessages&login={$login}&domain={$domain}";
        \Illuminate\Support\Facades\Log::info('1SecMail: Fetching messages from: ' . $url);

        $response = Http::withOptions(['verify' => false])
            ->withHeaders([
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'application/json, text/plain, */*',
                'Referer' => 'https://www.1secmail.com/',
            ])
            ->get($url);

        if ($response->successful()) {
            $messages = $response->json();
            \Illuminate\Support\Facades\Log::info('1SecMail: Received ' . count($messages) . ' messages');

            return collect($messages)->map(function ($msg) {
                return [
                    'id' => $msg['id'],
                    'from' => $msg['from'],
                    'subject' => $msg['subject'],
                    'intro' => substr($msg['subject'] ?? '', 0, 50), // Use subject as intro
                    'seen' => false,
                    'created_at' => $msg['date'] ?? now()->toISOString(),
                ];
            })->toArray();
        }

        \Illuminate\Support\Facades\Log::error('1SecMail: Failed to fetch messages. Status: ' . $response->status());
        return [];
    }

    public function getMessage(string $messageId, string $email, array $meta = []): array
    {
        // Extract username and domain
        if (empty($meta['username']) || empty($meta['domain'])) {
            $parts = explode('@', $email);
            if (count($parts) !== 2) {
                throw new \Exception('Invalid email format: ' . $email);
            }
            $login = $parts[0];
            $domain = $parts[1];
        } else {
            $login = $meta['username'];
            $domain = $meta['domain'];
        }

        $url = "{$this->baseUrl}?action=readMessage&login={$login}&domain={$domain}&id={$messageId}";
        \Illuminate\Support\Facades\Log::info('1SecMail: Fetching message from: ' . $url);

        $response = Http::withOptions(['verify' => false])
            ->withHeaders([
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'application/json, text/plain, */*',
                'Referer' => 'https://www.1secmail.com/',
            ])
            ->get($url);

        if ($response->successful()) {
            $data = $response->json();
            \Illuminate\Support\Facades\Log::info('1SecMail: Message fetched successfully');

            return [
                'id' => $data['id'],
                'from' => $data['from'],
                'subject' => $data['subject'],
                'body' => $data['textBody'] ?? $data['body'] ?? '',
                'html' => $data['htmlBody'] ?? '',
                'attachments' => $data['attachments'] ?? []
            ];
        }

        \Illuminate\Support\Facades\Log::error('1SecMail: Failed to fetch message. Status: ' . $response->status());
        throw new \Exception('Failed to fetch message');
    }
}
