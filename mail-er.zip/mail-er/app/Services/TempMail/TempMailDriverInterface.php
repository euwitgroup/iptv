<?php

namespace App\Services\TempMail;

interface TempMailDriverInterface
{
    /**
     * Get available domains for this provider.
     *
     * @return array
     */
    public function getDomains(): array;

    /**
     * Create a new email address.
     *
     * @param string|null $username Optional custom username
     * @param string|null $domain Optional specific domain
     * @return array Returns ['email' => '...', 'id' => '...', 'meta' => [...]]
     */
    public function createEmail(?string $username = null, ?string $domain = null): array;

    /**
     * Get messages for a specific email.
     *
     * @param string $email
     * @param array $meta Optional metadata saved during creation
     * @return array List of messages
     */
    public function getMessages(string $email, array $meta = []): array;

    /**
     * Get a specific message content.
     *
     * @param string $messageId
     * @param string $email
     * @param array $meta Optional metadata
     * @return array Message details ['from', 'subject', 'body', 'html', 'attachments']
     */
    public function getMessage(string $messageId, string $email, array $meta = []): array;
}
