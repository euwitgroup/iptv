<?php

namespace App\Services\TempMail;

use App\Models\Provider;
use Illuminate\Support\Facades\Session;

class TempMailService
{
    /**
     * Get the active provider driver instance.
     *
     * @param Provider|null $provider
     * @return TempMailDriverInterface
     * @throws \Exception
     */
    public function getDriver(?Provider $provider = null): TempMailDriverInterface
    {
        if (!$provider) {
            $provider = $this->getDefaultProvider();
        }

        if (!$provider || !$provider->driver_class) {
            throw new \Exception('No active email provider found.');
        }

        if (!class_exists($provider->driver_class)) {
            throw new \Exception("Driver class {$provider->driver_class} not found.");
        }

        // Instantiate driver (optionally pass config if needed later)
        return app($provider->driver_class);
    }

    /**
     * Get the default active provider.
     */
    public function getDefaultProvider(): ?Provider
    {
        // 1. Try Default Active
        $provider = Provider::where('is_active', true)
            ->where('is_default', true)
            ->first();

        // 2. Fallback to Highest Priority Active
        if (!$provider) {
            $provider = Provider::where('is_active', true)
                ->orderBy('priority', 'desc')
                ->first();
        }

        return $provider;
    }

    /**
     * Generate a new email for the current session.
     */
    /**
     * Generate a new email for the current session.
     */
    /**
     * Get all available domains from active providers.
     */
    public function getAvailableDomains(): array
    {
        return \Illuminate\Support\Facades\Cache::remember('temp_mail_domains', 300, function () { // Cache for 5 mins
            $providers = Provider::where('is_active', true)->orderBy('priority', 'desc')->get();
            $available = [];
            $seenDomains = []; // Track domains to avoid duplicates

            foreach ($providers as $provider) {
                try {
                    if (!class_exists($provider->driver_class))
                        continue;
                    /** @var TempMailDriverInterface $driver */
                    $driver = app($provider->driver_class);
                    $domains = $driver->getDomains(); // Array of strings

                    foreach ($domains as $d) {
                        // Skip if domain already added (1 domain 1 time rule)
                        if (in_array($d, $seenDomains)) {
                            continue;
                        }

                        $seenDomains[] = $d;
                        $available[] = [
                            'domain' => $d,
                            'provider_slug' => $provider->slug,
                            'provider_name' => $provider->name
                        ];
                    }
                } catch (\Exception $e) {
                    continue;
                }
            }
            return $available;
        });
    }

    /**
     * Generate a new email for the current session.
     */
    public function generate(?string $selectedDomain = null, ?string $selectedProviderSlug = null): array
    {
        // 1. Specific Selection Logic
        if ($selectedDomain && $selectedProviderSlug) {
            $provider = Provider::where('slug', $selectedProviderSlug)->where('is_active', true)->first();

            if (!$provider) {
                throw new \Exception("Selected provider is unavailable.");
            }

            try {
                if (!class_exists($provider->driver_class)) {
                    throw new \Exception("Driver class missing.");
                }
                /** @var TempMailDriverInterface $driver */
                $driver = app($provider->driver_class);
                $data = $driver->createEmail(null, $selectedDomain); // Pass selected domain

                return $this->storeSession($data, $provider);
            } catch (\Exception $e) {
                // Do NOT fallback. Throw error.
                throw new \Exception("Failed to generate with selected domain: " . $e->getMessage());
            }
        }

        // 2. Random Selection - Use ALL Providers Equally
        $providers = Provider::where('is_active', true)
            ->orderBy('is_default', 'desc')
            ->orderBy('priority', 'desc')
            ->get();

        if ($providers->isEmpty()) {
            throw new \Exception('No active email providers configured.');
        }

        // SHUFFLE providers to give all equal chance (not just high priority)
        $providers = $providers->shuffle();

        $lastError = null;

        foreach ($providers as $provider) {
            try {
                if (!class_exists($provider->driver_class))
                    continue;
                /** @var TempMailDriverInterface $driver */
                $driver = app($provider->driver_class);

                // Attempt Generation (Random domain)
                $data = $driver->createEmail();

                return $this->storeSession($data, $provider);

            } catch (\Exception $e) {
                $lastError = $e;
                continue;
            }
        }

        throw new \Exception('All providers failed to generate email. Last error: ' . ($lastError ? $lastError->getMessage() : 'Unknown'));
    }

    private function storeSession(array $data, Provider $provider): array
    {
        $sessionData = [
            'email' => $data['email'],
            'remote_id' => $data['id'],
            'meta' => $data['meta'],
            'provider_id' => $provider->id,
            'provider_slug' => $provider->slug,
            'created_at' => now(),
            'messages' => []
        ];

        Session::put('temp_email', $sessionData);
        Session::save();

        // Save to Database History for Admin Inbox
        try {
            $history = \App\Models\TempEmailHistory::create([
                'user_id' => \Illuminate\Support\Facades\Auth::id(), // Null if guest
                'session_id' => Session::getId(),
                'email_address' => $data['email'],
                'provider_slug' => $provider->slug,
                'generated_at' => now(),
                'expires_at' => now()->addHours($provider->retention_hours ?? 24),
                'messages_count' => 0
            ]);

            // Store history ID in session for updates
            Session::put('temp_email_history_id', $history->id);
            Session::save();
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Failed to save email history: ' . $e->getMessage());
        }

        return $sessionData;
    }

    /**
     * Check for new messages.
     */
    public function checkMessages(): array
    {
        $sessionData = Session::get('temp_email');

        if (!$sessionData) {
            \Illuminate\Support\Facades\Log::info('TempMailService: No active email session');
            return [];
        }

        \Illuminate\Support\Facades\Log::info('TempMailService: Checking messages for ' . $sessionData['email']);
        \Illuminate\Support\Facades\Log::info('TempMailService: Provider ID: ' . $sessionData['provider_id']);
        \Illuminate\Support\Facades\Log::info('TempMailService: Meta: ' . json_encode($sessionData['meta']));

        $provider = Provider::find($sessionData['provider_id']);
        if (!$provider) {
            \Illuminate\Support\Facades\Log::error('TempMailService: Provider not found');
            return [];
        }

        \Illuminate\Support\Facades\Log::info('TempMailService: Using provider: ' . $provider->name);

        $driver = $this->getDriver($provider);

        try {
            $messages = $driver->getMessages($sessionData['email'], $sessionData['meta']);

            $count = count($messages);
            \Illuminate\Support\Facades\Log::info('TempMailService: Retrieved ' . $count . ' messages');

            // Update History Record if exists
            $historyId = Session::get('temp_email_history_id');
            if ($historyId) {
                \App\Models\TempEmailHistory::where('id', $historyId)->update([
                    'messages_count' => $count,
                    'last_checked_at' => now()
                ]);
            } else {
                // Try to find by email
                $history = \App\Models\TempEmailHistory::where('email_address', $sessionData['email'])
                    ->latest()
                    ->first();

                if ($history) {
                    $history->update([
                        'messages_count' => $count,
                        'last_checked_at' => now()
                    ]);
                    Session::put('temp_email_history_id', $history->id);
                } else {
                    // Create Missing Record (Backfill)
                    try {
                        $newHistory = \App\Models\TempEmailHistory::create([
                            'user_id' => \Illuminate\Support\Facades\Auth::id(),
                            'session_id' => Session::getId(),
                            'email_address' => $sessionData['email'],
                            'provider_slug' => $provider->slug, // Use provider object
                            'generated_at' => now(),
                            'expires_at' => now()->addHours(24),
                            'messages_count' => $count,
                            'last_checked_at' => now()
                        ]);
                        Session::put('temp_email_history_id', $newHistory->id);
                        \Illuminate\Support\Facades\Log::info('TempMailService: Backfilled history record ID: ' . $newHistory->id);
                    } catch (\Exception $e) {
                        \Illuminate\Support\Facades\Log::error('TempMailService: Failed to backfill history: ' . $e->getMessage());
                    }
                }
            }

            return $messages;
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('TempMailService: Error getting messages: ' . $e->getMessage());
            return [];
        }
    }

    public function getEmailAddress(): ?string
    {
        return Session::get('temp_email.email');
    }

    public function getMessage(string $messageId): array
    {
        $sessionData = Session::get('temp_email');

        if (!$sessionData) {
            throw new \Exception('No active email session');
        }

        $provider = Provider::find($sessionData['provider_id']);
        if (!$provider) {
            throw new \Exception('Provider not found');
        }

        $driver = $this->getDriver($provider);

        return $driver->getMessage($messageId, $sessionData['email'], $sessionData['meta']);
    }
}
