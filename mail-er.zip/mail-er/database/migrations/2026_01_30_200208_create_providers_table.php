<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('providers', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('slug', 50)->unique();
            $table->string('base_url', 255);
            $table->string('api_key', 255)->nullable();
            $table->string('driver_class', 255);
            $table->boolean('is_active')->default(true);
            $table->boolean('is_default')->default(false);
            $table->integer('priority')->default(50);
            $table->integer('max_per_day')->nullable()->comment('Rate limit per user');
            $table->integer('retention_hours')->default(24);
            $table->json('features')->nullable()->comment('Supported features array');
            $table->enum('status', ['online', 'offline', 'maintenance'])->default('online');
            $table->timestamp('last_health_check')->nullable();
            $table->timestamps();

            $table->index('is_active');
            $table->index('slug');
            $table->index('priority');
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('providers');
    }
};
