<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Setting;

class AdSenseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $settings = [
            // Google AdSense Configuration
            ['key' => 'adsense_publisher_id', 'value' => ''], // e.g., pub-xxxxxxxxxxxxxxxx
            ['key' => 'adsense_auto_ads_code', 'value' => ''], // Full <script> tag for header

            // Ad Slots
            ['key' => 'adsense_home_top', 'value' => ''],
            ['key' => 'adsense_home_bottom', 'value' => ''],
            ['key' => 'adsense_home_left', 'value' => ''],
            ['key' => 'adsense_home_right', 'value' => ''],

            // Ads.txt Content
            ['key' => 'ads_txt', 'value' => 'google.com, pub-0000000000000000, DIRECT, f08c47fec0942fa0'], // Default placeholder structure
        ];

        foreach ($settings as $setting) {
            Setting::firstOrCreate(
                ['key' => $setting['key']],
                ['value' => $setting['value']]
            );
        }
    }
}
