<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Check if admin user already exists
        $adminExists = User::where('email', 'admin@mail-er.com')->exists();

        if (!$adminExists) {
            User::create([
                'name' => 'Admin',
                'email' => 'admin@mail-er.com',
                'password' => Hash::make('admin123'),
                'role' => 'admin',
                'email_verified_at' => now(),
            ]);

            $this->command->info('✅ Admin user created successfully!');
            $this->command->line('');
            $this->command->line('Admin Credentials:');
            $this->command->line('Email: admin@mail-er.com');
            $this->command->line('Password: admin123');
            $this->command->line('');
            $this->command->warn('⚠️  Please change the password after first login!');
        } else {
            $this->command->info('ℹ️  Admin user already exists.');
        }
    }
}
