<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class MainPageSeeder extends Seeder
{
    public function run()
    {
        $this->call([
            PageAboutSeeder::class,
            PagePrivacySeeder::class,
            PageTermsSeeder::class,
            PageApiSeeder::class,
            PageContactSeeder::class,
            PageBlogSeeder::class,
        ]);
    }
}
