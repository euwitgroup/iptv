<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageAboutSeeder extends Seeder
{
    public function run()
    {
        $content = <<<EOT
<div class="about-section">
    <h2 class="text-primary mb-4">Who We Are</h2>
    <p class="lead text-muted mb-5">
        Mail-ER is a premium temporary email service designed to protect your privacy and keep your primary inbox clean. 
        In an era of digital surveillance and data breaches, we believe that anonymity is a fundamental right.
    </p>

    <div class="row my-5">
        <div class="col-md-6 mb-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-shield-alt text-success me-2"></i> Uncompromised Privacy</h4>
                    <p>We do not track your IP address, strictly log zero personal data, and ensure that all emails are securely encrypted before being permanently deleted from our servers.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-bolt text-warning me-2"></i> Lightning Fast</h4>
                    <p>Our infrastructure is built on high-performance cloud servers, ensuring that you receive emails instantly. No delays, no waiting—just seamless communication.</p>
                </div>
            </div>
        </div>
    </div>

    <h3 class="mb-4">Our Mission</h3>
    <p>
        Our mission is simple: to provide a secure, reliable, and user-friendly tool that empowers individuals to navigate the internet without leaving a digital footprint. 
        Whether you are testing software, signing up for a trial, or simply avoiding spam, Mail-ER is your trusted partner.
    </p>

    <div class="mt-5 p-4 bg-light rounded text-center">
        <h5 class="fw-bold">Ready to get started?</h5>
        <p class="mb-3">Generate your secure temporary email address instantly.</p>
        <a href="/" class="btn btn-primary">Go to Homepage</a>
    </div>
</div>
EOT;

        Page::updateOrCreate(
            ['slug' => 'about-us'],
            [
                'title' => 'About Us',
                'content' => $content,
                'meta_title' => 'About Us - Mail-ER Secure Temp Mail',
                'meta_description' => 'Learn more about Mail-ER, the premium temporary email service dedicated to protecting your privacy and fighting spam.',
                'is_published' => true,
                'show_in_footer' => true,
                'show_in_header' => true,
            ]
        );
    }
}
