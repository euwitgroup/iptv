<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageApiSeeder extends Seeder
{
    public function run()
    {
        $content = <<<EOT
<div class="api-docs-section">
    <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i> Our public API is currently in <strong>Beta</strong>. Rate limits apply.
    </div>

    <h2 class="mt-4">Overview</h2>
    <p>The Mail-ER API allows developers to programmatically generate temporary emails and fetch messages. It is built around REST principles and returns JSON responses.</p>
    
    <p><strong>Base URL:</strong> <code>https://mail-er.com/api/v1</code></p>

    <h3 class="mt-5 text-primary">Endpoints</h3>

    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-header bg-white fw-bold">
            <span class="badge bg-success me-2">GET</span> /domains
        </div>
        <div class="card-body">
            <p>Fetch a list of active domains available for email generation.</p>
            <pre class="bg-light p-3 rounded"><code>[
  "example.com",
  "mail-er.com",
  "tempmail.net"
]</code></pre>
        </div>
    </div>

    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-header bg-white fw-bold">
            <span class="badge bg-primary me-2">POST</span> /inbox/create
        </div>
        <div class="card-body">
            <p>Create a new random inbox.</p>
            <pre class="bg-light p-3 rounded"><code>{
  "email": "x82js@example.com",
  "token": "a1b2c3d4e5..."
}</code></pre>
        </div>
    </div>

    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-header bg-white fw-bold">
            <span class="badge bg-success me-2">GET</span> /inbox/{email}/messages
        </div>
        <div class="card-body">
            <p>Get messages for a specific inbox. Requires authentication token.</p>
            <pre class="bg-light p-3 rounded"><code>{
  "messages": [
    {
      "id": 102,
      "from": "sender@gmail.com",
      "subject": "Verification Code",
      "date": "2026-01-31T12:00:00Z"
    }
  ]
}</code></pre>
        </div>
    </div>

    <h3 class="mt-5">Authentication</h3>
    <p>Currently, the API is open for public testing without keys for read-only domain lists. For inbox management, usage is session-based. API Keys for high-volume access will be available in the Premium plan.</p>
</div>
EOT;

        Page::updateOrCreate(
            ['slug' => 'api-docs'],
            [
                'title' => 'API Documentation',
                'content' => $content,
                'meta_title' => 'API Documentation - Mail-ER Developers',
                'meta_description' => 'Integrate Mail-ER into your applications. Full documentation for our REST API endpoints including domain lists and message retrieval.',
                'is_published' => true,
                'show_in_footer' => true,
                'show_in_header' => true, // Often useful in header for Devs
            ]
        );
    }
}
