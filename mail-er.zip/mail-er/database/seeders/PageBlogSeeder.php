<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageBlogSeeder extends Seeder
{
    public function run()
    {
        $content = <<<EOT
<div class="blog-section">
    <h2 class="mb-5 text-center">Latest from the Blog</h2>

    <div class="row">
        <!-- Post 1 -->
        <div class="col-md-6 mb-5">
            <div class="card h-100 border-0 shadow-sm overflow-hidden">
                <img src="https://source.unsplash.com/random/800x400?technology,security" class="card-img-top" alt="Cyber Security">
                <div class="card-body p-4">
                    <span class="badge bg-primary mb-2">Tips</span>
                    <h4 class="card-title fw-bold">Why Your Real Email is a Target for Spammers</h4>
                    <p class="card-text text-muted">Every time you sign up for a newsletter or free trial, you expose your primary email to potential breaches. Learn how temporary emails act as a firewall for your personal life.</p>
                    <a href="#" class="btn btn-outline-primary btn-sm mt-3">Read More</a>
                </div>
                <div class="card-footer bg-white border-0 p-4 pt-0">
                    <small class="text-muted">January 15, 2026</small>
                </div>
            </div>
        </div>

        <!-- Post 2 -->
        <div class="col-md-6 mb-5">
            <div class="card h-100 border-0 shadow-sm overflow-hidden">
                <img src="https://source.unsplash.com/random/800x400?hacker,code" class="card-img-top" alt="Phishing Protection">
                <div class="card-body p-4">
                    <span class="badge bg-danger mb-2">Security</span>
                    <h4 class="card-title fw-bold">How to Spot a Phishing Attempt Instantly</h4>
                    <p class="card-text text-muted">Phishing attacks are getting smarter. AI-generated emails can fool even the tech-savvy. Here are 5 red flags to look for before you click that link.</p>
                    <a href="#" class="btn btn-outline-primary btn-sm mt-3">Read More</a>
                </div>
                <div class="card-footer bg-white border-0 p-4 pt-0">
                    <small class="text-muted">January 10, 2026</small>
                </div>
            </div>
        </div>

        <!-- Post 3 -->
        <div class="col-md-12">
            <div class="card border-0 shadow-sm p-4 bg-light">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="fw-bold">Stay Updated!</h4>
                        <p class="mb-0">Subscribe to our (spam-free) newsletter to get the latest privacy tips delivered to your... well, maybe use a temp mail for this too?</p>
                    </div>
                    <div class="col-md-4 text-end">
                       <button class="btn btn-dark btn-lg">Subscribe</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
EOT;

        Page::updateOrCreate(
            ['slug' => 'blog'],
            [
                'title' => 'Blog',
                'content' => $content,
                'meta_title' => 'Mail-ER Blog - Privacy & Security Tips',
                'meta_description' => 'Stay informed with the latest news, tips, and security advice from the Mail-ER team.',
                'is_published' => true,
                'show_in_footer' => true,
                'show_in_header' => true,
            ]
        );
    }
}
