<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageContactSeeder extends Seeder
{
    public function run()
    {
        $content = <<<EOT
<div class="contact-section">
    <div class="row justify-content-center text-center">
        <div class="col-lg-8">
            <h2 class="section-heading mb-4">We'd Love to Hear From You</h2>
            <p class="lead text-muted mb-5">Whether you have a question about our features, need technical support, or just want to give feedback, our team is ready to help.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card text-center h-100 border-0 shadow-sm py-4">
                <div class="card-body">
                    <div class="icon-box mb-3 text-primary fs-1">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h5 class="fw-bold">Email Us</h5>
                    <p class="text-muted">For general inquiries and support.</p>
                    <a href="mailto:support@mail-er.com" class="fw-bold text-decoration-none">support@mail-er.com</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card text-center h-100 border-0 shadow-sm py-4">
                <div class="card-body">
                    <div class="icon-box mb-3 text-success fs-1">
                        <i class="fab fa-twitter"></i>
                    </div>
                    <h5 class="fw-bold">Social Media</h5>
                    <p class="text-muted">Follow us for updates and tips.</p>
                    <a href="#" class="fw-bold text-decoration-none">@MailER_Official</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card text-center h-100 border-0 shadow-sm py-4">
                <div class="card-body">
                    <div class="icon-box mb-3 text-danger fs-1">
                        <i class="fas fa-bug"></i>
                    </div>
                    <h5 class="fw-bold">Bug Reports</h5>
                    <p class="text-muted">Found a vulnerability? Let us know.</p>
                    <a href="mailto:security@mail-er.com" class="fw-bold text-decoration-none">security@mail-er.com</a>
                </div>
            </div>
        </div>
    </div>

    <h3 class="mt-5 mb-4 text-center">Frequently Asked Questions</h3>
    <div class="accordion" id="faqAccordion">
        <div class="accordion-item border-0 shadow-sm mb-3">
            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                    <strong>How long are emails kept?</strong>
                </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                    Emails are kept for 24 hours. After that, they are permanently deleted from our servers for your privacy.
                </div>
            </div>
        </div>
        <div class="accordion-item border-0 shadow-sm mb-3">
            <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                    <strong>Can I restore a deleted email?</strong>
                </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                    No. Once an email is deleted (either automatically or by you), it is gone forever. We do not keep backups of user emails.
                </div>
            </div>
        </div>
    </div>
</div>
EOT;

        Page::updateOrCreate(
            ['slug' => 'contact'],
            [
                'title' => 'Contact Support',
                'content' => $content,
                'meta_title' => 'Contact Support - Mail-ER',
                'meta_description' => 'Get in touch with the Mail-ER support team. Find our email, social media links, and answers to frequently asked questions.',
                'is_published' => true,
                'show_in_footer' => true,
                'show_in_header' => false,
            ]
        );
    }
}
