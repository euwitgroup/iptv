<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PagePrivacySeeder extends Seeder
{
    public function run()
    {
        $content = <<<EOT
<div class="privacy-section">
    <p class="text-muted">Last Updated: January 2026</p>
    
    <p>At Mail-ER, accessible from mail-er.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Mail-ER and how we use it.</p>

    <h3 class="mt-4 mb-3">Log Files</h3>
    <p>Mail-ER follows a standard procedure of using log files. However, unlike traditional services, <strong>we strictly limit</strong> logging to ensure anonymity. We do not log full IP addresses or associate activity with specific users unless necessary for security (e.g., preventing DDoS attacks).</p>

    <h3 class="mt-4 mb-3">Data Retention</h3>
    <p>We are a temporary email service. This means data retention is deliberately short-term:</p>
    <ul class="list-group list-group-flush mb-3">
        <li class="list-group-item bg-transparent"><i class="fas fa-check text-success me-2"></i> <strong>Emails:</strong> Automatically deleted after 24 hours (or sooner if you manually delete them).</li>
        <li class="list-group-item bg-transparent"><i class="fas fa-check text-success me-2"></i> <strong>Address History:</strong> Your generated email addresses are session-based and discarded when you clear cookies or after inactivity.</li>
    </ul>

    <h3 class="mt-4 mb-3">Cookies and Web Beacons</h3>
    <p>Like any other website, Mail-ER uses 'cookies'. These cookies are used to store information including visitors' preferences, such as your current active temporary email address. We do not use cookies for tracking across third-party websites.</p>

    <h3 class="mt-4 mb-3">CCPA Privacy Rights</h3>
    <p>Under the CCPA, among other rights, California consumers have the right to request that a business that collects a consumer's personal data disclose the categories and specific pieces of personal data that a business has collected about consumers. Since we collect minimal data, we often have nothing to disclose, but we honor all requests.</p>

    <h3 class="mt-4 mb-3">GDPR Data Protection Rights</h3>
    <p>We would like to make sure you are fully aware of all of your data protection rights. Every user is entitled to the right to access, rectification, erasure, restrict processing, object to processing, and data portability.</p>

    <h3 class="mt-4 mb-3">Contact Us</h3>
    <p>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.</p>
</div>
EOT;

        Page::updateOrCreate(
            ['slug' => 'privacy-policy'],
            [
                'title' => 'Privacy Policy',
                'content' => $content,
                'meta_title' => 'Privacy Policy - Mail-ER',
                'meta_description' => 'Our commitment to your privacy. Read how Mail-ER handles your data with strict zero-logging and auto-deletion policies.',
                'is_published' => true,
                'show_in_footer' => true,
                'show_in_header' => false,
            ]
        );
    }
}
