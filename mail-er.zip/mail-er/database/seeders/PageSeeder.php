<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $pages = [
            [
                'title' => 'About Us',
                'slug' => 'about-us',
                'content' => '<h1>About Us</h1><p>Welcome to our Temporary Email Service. We provide secure and disposable email addresses to protect your privacy.</p>',
                'show_in_footer' => true,
                'show_in_header' => true,
            ],
            [
                'title' => 'Privacy Policy',
                'slug' => 'privacy-policy',
                'content' => '<h1>Privacy Policy</h1><p>We do not store your emails for more than 24 hours. Your privacy is our top priority.</p>',
                'show_in_footer' => true,
                'show_in_header' => false,
            ],
            [
                'title' => 'Terms of Service',
                'slug' => 'terms-of-service',
                'content' => '<h1>Terms of Service</h1><p>By using our service, you agree not to use it for illegal activities.</p>',
                'show_in_footer' => true,
                'show_in_header' => false,
            ],
            [
                'title' => 'API Documentation',
                'slug' => 'api-docs',
                'content' => '<h1>API Documentation</h1><p>Coming soon...</p>',
                'show_in_footer' => true,
                'show_in_header' => true,
            ],
            [
                'title' => 'Contact Support',
                'slug' => 'contact',
                'content' => '<h1>Contact Support</h1><p>Please email us at support@example.com</p>',
                'show_in_footer' => true,
                'show_in_header' => true,
            ],
            [
                'title' => 'Blog',
                'slug' => 'blog',
                'content' => '<h1>Blog</h1><p>Latest updates and news will appear here.</p>',
                'show_in_footer' => true,
                'show_in_header' => true,
            ],
        ];

        foreach ($pages as $page) {
            Page::updateOrCreate(
                ['slug' => $page['slug']],
                $page
            );
        }
    }
}
