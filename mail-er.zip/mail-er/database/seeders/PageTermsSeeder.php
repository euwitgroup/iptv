<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PageTermsSeeder extends Seeder
{
    public function run()
    {
        $content = <<<EOT
<div class="terms-section">
    <p class="lead">By accessing this website, we assume you accept these terms and conditions. Do not continue to use Mail-ER if you do not agree to take all of the terms and conditions stated on this page.</p>

    <h3 class="mt-4 mb-3">1. Service Description</h3>
    <p>Mail-ER provides temporary, disposable email addresses. The service is provided "as is" and is intended for personal use to protect privacy and avoid spam. Emails are not permanent and will be deleted automatically.</p>

    <h3 class="mt-4 mb-3">2. Prohibited Activities</h3>
    <p>You agree not to use Mail-ER for:</p>
    <ul>
        <li>Illegal activities, including fraud, phishing, or distribution of malware.</li>
        <li>Sending spam or unsolicited bulk emails.</li>
        <li>Harassment, threatening behavior, or violating the rights of others.</li>
        <li>Registering accounts on platforms that strictly prohibit the use of disposable emails (though we strive for compatibility, it is your responsibility to comply with third-party terms).</li>
    </ul>

    <h3 class="mt-4 mb-3">3. Disclaimer</h3>
    <p>Mail-ER makes no warranties, may it be expressed or implied, therefore negates all other warranties. Furthermore, Mail-ER does not make any representations concerning the accuracy or reliability of the use of the materials on its website or otherwise relating to such materials or on any sites linked to this site.</p>

    <h3 class="mt-4 mb-3">4. Limitation of Liability</h3>
    <p>In no event shall Mail-ER or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Mail-ER's website.</p>

    <h3 class="mt-4 mb-3">5. Modifications</h3>
    <p>Mail-ER may revise these terms of service for its website at any time without notice. By using this website you are agreeing to be bound by the then current version of these terms of service.</p>
</div>
EOT;

        Page::updateOrCreate(
            ['slug' => 'terms-of-service'],
            [
                'title' => 'Terms of Service',
                'content' => $content,
                'meta_title' => 'Terms of Service - Mail-ER',
                'meta_description' => 'Read the Terms of Service for using Mail-ER. Understand the rules, prohibited activities, and liability disclaimers.',
                'is_published' => true,
                'show_in_footer' => true,
                'show_in_header' => false,
            ]
        );
    }
}
