<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Provider;

class ProviderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $providers = [
            [
                'name' => 'Mail.tm',
                'slug' => 'mail-tm',
                'driver_class' => 'App\Services\TempMail\Drivers\MailTmDriver',
                'is_active' => true,
                'priority' => 100,
                'base_url' => 'https://api.mail.tm',
                'features' => ['jwt', 'custom_username', 'domains_list'],
            ],
            [
                'name' => '1secmail',
                'slug' => '1secmail',
                'driver_class' => 'App\Services\TempMail\Drivers\OneSecMailDriver',
                'is_active' => true,
                'priority' => 90,
                'base_url' => 'https://www.1secmail.com/api/v1/',
                'features' => ['simple', 'no_auth', 'domains_list'],
            ],
            [
                'name' => 'Guerrilla Mail',
                'slug' => 'guerrilla-mail',
                'driver_class' => 'App\Services\TempMail\Drivers\GuerrillaMailDriver',
                'is_active' => true,
                'priority' => 80,
                'base_url' => 'https://api.guerrillamail.com/ajax.php',
                'features' => ['session_based', 'legacy'],
            ],
            [
                'name' => 'DropMail.me',
                'slug' => 'dropmail',
                'driver_class' => 'App\Services\TempMail\Drivers\DropMailDriver',
                'is_active' => true,
                'priority' => 70,
                'base_url' => 'https://dropmail.me/api/graphql/',
                'features' => ['graphql', 'token_based'],
            ],
            [
                'name' => 'Mailsac',
                'slug' => 'mailsac',
                'driver_class' => 'App\Services\TempMail\Drivers\MailsacDriver',
                'is_active' => true,
                'priority' => 60,
                'base_url' => 'https://mailsac.com/api/',
                'features' => ['public', 'rest'],
            ],
        ];

        foreach ($providers as $providerData) {
            Provider::updateOrCreate(
                ['slug' => $providerData['slug']], // Search by slug
                $providerData // Update/Create data
            );
        }
    }
}
