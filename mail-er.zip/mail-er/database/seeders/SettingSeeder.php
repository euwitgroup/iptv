<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $settings = [
            // General
            ['key' => 'site_name', 'value' => 'Mail-ER'],
            ['key' => 'site_title', 'value' => 'Mail-ER | Premium Disposable Email'],
            ['key' => 'contact_email', 'value' => 'support@mail-er.com'],
            ['key' => 'footer_copyright', 'value' => '© 2026 Mail-ER. All rights reserved.'],

            // SEO
            ['key' => 'meta_title', 'value' => 'Free Temp Mail - Secure & Anonymous Email Service'],
            ['key' => 'meta_description', 'value' => 'Get a free temporary email address instantly. Protect your privacy, avoid spam, and stay anonymous with Mail-ER.'],
            ['key' => 'meta_keywords', 'value' => 'temp mail, disposable email, anonymous email, fake email, 10 minute mail, privacy, secure email'],

            // Social (Empty defaults)
            ['key' => 'social_facebook', 'value' => '#'],
            ['key' => 'social_twitter', 'value' => '#'],
            ['key' => 'social_instagram', 'value' => '#'],
            ['key' => 'social_telegram', 'value' => '#'],
            ['key' => 'social_whatsapp', 'value' => '#'],
            ['key' => 'social_youtube', 'value' => '#'],
        ];

        foreach ($settings as $setting) {
            \App\Models\Setting::updateOrCreate(
                ['key' => $setting['key']],
                ['value' => $setting['value']]
            );
        }
    }
}
