# API Provider Documentation

This document lists the supported temporary email API providers and their integration details.

## 1. Mail.tm (Recommended)
*   **Website**: [https://mail.tm/](https://mail.tm/)
*   **API Docs**: [https://docs.mail.tm/](https://docs.mail.tm/)
*   **Base URL**: `https://api.mail.tm`
*   **Auth**: Bearer Token (JWT). Requires creating an account via API first.
*   **Features**:
    *   RESTful API.
    *   Create custom username addresses.
    *   Real-time message retrieval.
    *   Generous free tier.

## 2. 1secmail
*   **Website**: [https://www.1secmail.com/](https://www.1secmail.com/)
*   **API Docs**: [https://www.1secmail.com/api/](https://www.1secmail.com/api/)
*   **Base URL**: `https://www.1secmail.com/api/v1/`
*   **Auth**: None required.
*   **Features**:
    *   Simple GET requests.
    *   No registration needed.
    *   `getMessages`, `readMessage`, `downloadAttachment`.

## 3. Guerrilla Mail
*   **Website**: [https://www.guerrillamail.com/](https://www.guerrillamail.com/)
*   **API Docs**: [https://docs.google.com/document/d/1KwQKKCQUIKOnQbspNXAX2O-Y0T-xM4G2y-XnB1HkCks/edit](https://docs.google.com/document/d/1KwQKKCQUIKOnQbspNXAX2O-Y0T-xM4G2y-XnB1HkCks/edit)
*   **Base URL**: `https://api.guerrillamail.com/ajax.php`
*   **Auth**: None (Session/Cookie based).
*   **Features**:
    *   Oldest provider.
    *   JSONP support.
    *   "Set Email User" function.

## 4. DropMail.me
*   **Website**: [https://dropmail.me/](https://dropmail.me/)
*   **API Docs**: [https://dropmail.me/api/](https://dropmail.me/api/)
*   **Base URL**: `https://dropmail.me/api/graphql/`
*   **Auth**: None (Token based session).
*   **Features**:
    *   GraphQL API (unique).
    *   Websocket support for instant notifications.
    *   Unlimited duration sessions.

## 5. Mailsac
*   **Website**: [https://mailsac.com/](https://mailsac.com/)
*   **API Docs**: [https://mailsac.com/docs/api](https://mailsac.com/docs/api)
*   **Base URL**: `https://mailsac.com/api/`
*   **Auth**: API Key (Header: `Mailsac-Key`).
*   **Features**:
    *   Public inboxes (free).
    *   Private inboxes (paid).
    *   Webhook support.
