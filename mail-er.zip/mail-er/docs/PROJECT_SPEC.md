# Project Specification: Mail-ER - Temp Mail Aggregator

## 📋 Executive Summary

**Mail-ER** is a modern, feature-rich web application that aggregates multiple temporary email service providers into a unified platform. The system enables users to generate disposable email addresses for privacy protection, spam prevention, and secure online interactions without revealing their real email addresses.

**Key Differentiators:**
- 🔄 Multi-provider aggregation with automatic failover
- 🎯 Premium Gaming UI with dark cyberpunk theme
- 💰 Monetization through Google AdSense integration
- 👥 Three-tier role-based access (Guest, User, Admin)
- 🔐 Social authentication (Google, Facebook)
- 📊 Comprehensive admin analytics dashboard

---

## 1. 🎯 Project Overview

### Vision
To provide the most reliable and user-friendly temporary email service by leveraging multiple providers, ensuring high availability and offering a premium user experience with modern design aesthetics.

### Mission
Create a sustainable, ad-supported platform that protects user privacy while providing seamless temporary email services with zero downtime through intelligent provider management.

### Target Audience
1. **Privacy-Conscious Users**: People who want to protect their real email addresses
2. **Web Developers/Testers**: Need temp emails for testing registrations
3. **Online Shoppers**: Avoid spam from e-commerce sites
4. **Forum Users**: Quick registration without commitment
5. **Students**: Temporary accounts for educational trials

---

## 2. 🌟 Core Features

### 2.1 Multi-Provider System

#### Provider Aggregation
- **Integrated Providers**: Mail.tm, 1secmail.com, TempMail.org (expandable)
- **Load Balancing**: Distribute users across multiple providers
- **Auto-Failover**: Automatically switch to backup provider if primary fails
- **Health Monitoring**: Real-time API status checking
- **Provider Priority**: Admin-configurable provider preference order

#### Provider Features Matrix
| Provider | Attachments | HTML Emails | API Rate Limit | Retention | Cost |
|----------|-------------|-------------|----------------|-----------|------|
| Mail.tm | ✅ | ✅ | 100 req/min | 24 hours | Free |
| 1secmail | ❌ | ✅ | Unlimited | 1 hour | Free |
| TempMail | ✅ | ✅ | 50 req/min | 48 hours | Free |

#### Driver Architecture
```php
interface TempMailDriverInterface
{
    public function generateEmail(): string;
    public function getInbox(string $email): array;
    public function getMessage(string $email, string $id): object;
    public function deleteEmail(string $email): bool;
    public function healthCheck(): bool;
}
```

### 2.2 Email Generation & Management

#### For Guests:
- **Instant Generation**: Auto-generate on page load
- **Random Addresses**: Cryptographically random usernames
- **Copy to Clipboard**: One-click copy functionality
- **QR Code Display**: Mobile-friendly email sharing
- **Manual Refresh**: Force inbox update
- **Provider Rotation**: Automatic provider selection

#### For Registered Users:
- **Custom Prefix**: Choose email prefix (e.g., myname@mail.tm)
- **Provider Selection**: Choose preferred provider from dropdown
- **History Management**: Save and retrieve old emails
- **Bulk Generation**: Generate multiple emails at once
- **Favorites**: Pin frequently used temp emails
- **Search**: Find emails by address, sender, or subject

### 2.3 Real-Time Inbox

#### AJAX Polling System:
```javascript
- Poll Interval: 5-30 seconds (configurable)
- Smart Polling: Faster when tab is active, slower when inactive
- WebSocket Ready: Future upgrade for true real-time
- Notification Sound: Optional audio alert on new message
- Browser Notifications: Desktop notifications (with permission)
```

#### Inbox Features:
- **Message List**: Subject, sender, timestamp, attachment icon
- **Read/Unread Status**: Visual indicators
- **Message Preview**: First 100 characters
- **Full Message View**: HTML rendering with sanitization
- **Attachment Download**: Direct download links
- **Message Deletion**: Remove individual messages
- **Mark as Read/Unread**: Manual status control
- **Spam Detection**: Highlight suspected spam (future)

### 2.4 User Authentication & Roles

#### Three Access Levels:
| Role | Features | Restrictions |
|------|----------|--------------|
| **Guest** | Generate email, view inbox, read messages | No history, session-limited |
| **Registered** | All guest features + history, provider choice, profile | Rate limits apply |
| **Admin** | All features + provider mgmt, user mgmt, analytics | Full system control |

#### Authentication Methods:
1. **Email/Password**: Traditional registration with verification
2. **Google OAuth 2.0**: One-click social login
3. **Facebook Login**: Alternative social authentication

### 2.5 Google AdSense Integration

#### Strategic Ad Placement:
```
Ad Zone 1: HEADER BANNER (728x90 or responsive)
├─ Position: Top of every page
├─ Visibility: All users (guest & registered)
├─ Type: Display banner
└─ Priority: High visibility

Ad Zone 2: SIDEBAR (300x600 or 300x250)
├─ Position: Right sidebar on inbox/dashboard
├─ Visibility: Present during email reading
├─ Type: Display or matched content
└─ Priority: Medium visibility

Ad Zone 3: EMAIL FOOTER (Responsive)
├─ Position: Below email message content
├─ Visibility: When viewing email details
├─ Type: In-article or matched content
└─ Priority: Contextual placement

Ad Zone 4: INTERSTITIAL (Full screen)
├─ Position: Popup overlay
├─ Visibility: Configurable (once per session/hour)
├─ Type: Interstitial ad
└─ Priority: High revenue, low frequency
```

#### Admin Ad Management:
- **Enable/Disable**: Toggle each ad zone independently
- **Code Editor**: Paste AdSense or custom ad HTML
- **Preview Mode**: See ads before publishing
- **Analytics**: Track impressions and revenue (via AdSense)
- **A/B Testing**: Test different ad placements (future)

---

## 3. 💻 Technology Stack

### Backend Framework
- **Laravel 9.x**
  - PHP 8.0+ required
  - MVC architecture
  - Eloquent ORM
  - Blade templating
  - Artisan CLI

### Frontend Stack
- **Blade Templates**: Server-side rendering
- **Bootstrap 5.3.3**: Responsive UI framework (via CDN)
- **Premium Gaming Theme**: Custom dark cyberpunk design
  - Neon cyan/violet color scheme
  - Glassmorphism effects
  - Floating particle backgrounds
  - Glitch-style buttons
  - Orbitron & Rajdhani fonts

### Database
- **MySQL 8.0+** (or MariaDB 10.5+)
  - InnoDB storage engine
  - UTF8MB4 encoding
  - Full-text search capabilities

### Key Dependencies

#### Production Dependencies:
```json
{
    "laravel/framework": "^9.0",
    "laravel/socialite": "^5.24",
    "php-flasher/flasher-toastr-laravel": "^1.15",
    "guzzlehttp/guzzle": "^7.2",
    "laravel/sanctum": "^2.14"
}
```

| Package | Version | Purpose |
|---------|---------|---------|
| `laravel/socialite` | 5.24.2 | Google/Facebook OAuth integration |
| `php-flasher/flasher-toastr-laravel` | 1.15.14 | Beautiful toast notifications |
| `guzzlehttp/guzzle` | 7.2+ | HTTP client for provider APIs |
| `laravel/sanctum` | 2.14+ | API token authentication |

#### Optional Dependencies (Future):
- `laravel/horizon`: Queue monitoring (for background jobs)
- `predis/predis`: Redis cache driver (for sessions)
- `pusher/pusher-php-server`: WebSocket notifications
- `barryvdh/laravel-debugbar`: Development debugging

### API Integration
```php
// Provider API Clients
- Mail.tm: REST API (JSON)
- 1secmail: REST API (JSON)
- TempMail.org: REST API (JSON)
- Temp-mail.io: GraphQL (future)

// External Services
- Google OAuth 2.0 API
- Facebook Graph API
- Google AdSense API (reporting)
- Google reCAPTCHA v3
```

### Development Tools
- **Composer**: Dependency management
- **NPM**: Frontend asset management
- **Laravel Mix**: Asset compilation
- **PHPUnit**: Unit testing
- **Laravel Pint**: Code formatting

---

## 4. 💰 Monetization Strategy

### Primary Revenue: Google AdSense

#### Revenue Projections (Example):
```
Monthly Traffic: 100,000 page views
Average CPM: $2.00
Ad Zones: 4 zones × 80% fill rate
Estimated Monthly: $640

With optimizations:
- Improved CTR (1.5% → 2.5%)
- Better ad placement
- Quality traffic
Potential Monthly: $1,000 - $1,500
```

#### Monetization Rules:
1. **Guest Users**: See all ads (max monetization)
2. **Registered Users**: See most ads (slight reduction)
3. **Premium Users (Future)**: Pay $2.99/month for ad-free

### Secondary Revenue Streams (Future):
1. **Premium Subscriptions**:
   - Ad-free experience
   - Extended email retention (7 days vs 24 hours)
   - Custom domain emails
   - API access
   - Priority support
   - Price: $2.99/month or $29/year

2. **API Access**:
   - Developer tier: $9/month (1000 emails/month)
   - Business tier: $49/month (10,000 emails/month)
   - Enterprise: Custom pricing

3. **Affiliate Marketing**:
   - VPN services (privacy-related)
   - Password managers
   - Privacy tools

### Anti-Ad-Blocker Strategy:
```javascript
// Detect ad blockers
if (adBlockDetected) {
    show_message("Please disable ad blocker to support us");
    // Optional: Limit features for ad-block users
}
```

---

## 5. 🗄️ Database Schema

### Core Tables

#### 1. Users Table
```sql
CREATE TABLE users (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255),
    provider VARCHAR(50) NULL COMMENT 'google, facebook, local',
    provider_id VARCHAR(255) NULL,
    avatar VARCHAR(255) NULL,
    role ENUM('guest', 'user', 'admin') DEFAULT 'user',
    is_banned BOOLEAN DEFAULT FALSE,
    email_verified_at TIMESTAMP NULL,
    remember_token VARCHAR(100),
    last_login_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_provider (provider, provider_id),
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 2. Temp Email History Table
```sql
CREATE TABLE temp_email_history (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NULL,  -- NULL for guests
    session_id VARCHAR(255) NULL,  -- For guest tracking
    email_address VARCHAR(255) NOT NULL,
    provider_slug VARCHAR(50) NOT NULL,
    is_favorite BOOLEAN DEFAULT FALSE,
    messages_count INT DEFAULT 0,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    last_checked_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_session (session_id),
    INDEX idx_email (email_address),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 3. Providers Table
```sql
CREATE TABLE providers (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    base_url VARCHAR(255) NOT NULL,
    api_key VARCHAR(255) NULL,
    driver_class VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_default BOOLEAN DEFAULT FALSE,
    priority INT DEFAULT 50,
    max_per_day INT NULL COMMENT 'Rate limit per user',
    retention_hours INT DEFAULT 24,
    features JSON COMMENT '["attachments", "html"]',
    status ENUM('online', 'offline', 'maintenance') DEFAULT 'online',
    last_health_check TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_active (is_active),
    INDEX idx_slug (slug),
    INDEX idx_priority (priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 4. Settings Table
```sql
CREATE TABLE settings (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT NULL,
    type ENUM('string', 'integer', 'boolean', 'json') DEFAULT 'string',
    group VARCHAR(50) DEFAULT 'general' COMMENT 'general, email, ads, security',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_key (key),
    INDEX idx_group (group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 5. Activity Logs Table
```sql
CREATE TABLE activity_logs (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL COMMENT 'email_generated, login, provider_changed',
    description TEXT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    metadata JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 6. 🏗️ System Architecture

### Application Flow

```
┌─────────────┐
│   Browser   │
└──────┬──────┘
       │ HTTP/HTTPS
       ▼
┌──────────────────┐
│   Laravel App    │
│  ┌────────────┐  │
│  │ Routes     │  │
│  │ Middleware │  │
│  │ Controllers│  │
│  └────────────┘  │
└────┬─────────┬───┘
     │         │
     ▼         ▼
┌─────────┐ ┌──────────────┐
│ MySQL   │ │ Provider APIs│
│Database │ │ (Mail.tm etc)│
└─────────┘ └──────────────┘
```

### Request Flow

```
1. User visits site
   ↓
2. Session started (guest or authenticated)
   ↓
3. Controller generates temp email
   ↓
4. Driver calls provider API (Mail.tm)
   ↓
5. Email address returned
   ↓
6. Stored in session/database
   ↓
7. Rendered in Blade view
   ↓
8. AJAX polling starts (every 10s)
   ↓
9. Controller checks inbox via API
   ↓
10. Messages displayed in real-time
```

### Provider Failover Logic

```php
1. Try primary provider (Mail.tm)
   ↓ Failed?
2. Try secondary provider (1secmail)
   ↓ Failed?
3. Try tertiary provider (TempMail)
   ↓ All failed?
4. Show error: "Service temporarily unavailable"
```

---

## 7. 🚀 Deployment Requirements

### Server Requirements

#### Minimum Specifications:
- **CPU**: 2 cores @ 2.0 GHz
- **RAM**: 2 GB
- **Storage**: 20 GB SSD
- **Bandwidth**: 100 GB/month
- **OS**: Ubuntu 20.04+ or CentOS 8+

#### Recommended Specifications:
- **CPU**: 4 cores @ 2.5 GHz
- **RAM**: 4 GB
- **Storage**: 50 GB SSD
- **Bandwidth**: Unmetered
- **OS**: Ubuntu 22.04 LTS

### Software Stack:
- **PHP**: 8.0, 8.1, or 8.2
- **MySQL**: 8.0+ or MariaDB 10.5+
- **Web Server**: Nginx 1.18+ or Apache 2.4+
- **Composer**: 2.x
- **Node.js**: 16+ (for asset compilation)
- **SSL Certificate**: Required (Let's Encrypt)

### PHP Extensions Required:
```bash
- BCMath
- Ctype
- Fileinfo
- JSON
- Mbstring
- OpenSSL
- PDO (PDO_MYSQL)
- Tokenizer
- XML
- cURL
- GD or Imagick (for image manipulation)
- Redis or Memcached (optional, for caching)
```

### Hosting Recommendations:
| Provider | Plan | Price/Month | Notes |
|----------|------|-------------|-------|
| DigitalOcean | Droplet 2GB | $12 | Recommended for small-medium traffic |
| Vultr | High Frequency 2GB | $12 | Good performance |
| Linode | Nanode 2GB | $12 | Reliable SSD instances |
| AWS Lightsail | 2GB | $10 | Easy AWS entry point |
| Cloudways | DO 2GB | $14 | Managed, includes staging |

### Domain & DNS:
- **Domain**: Any registrar (Namecheap, GoDaddy, etc.)
- **DNS**: Cloudflare (recommended for CDN + DDoS protection)
- **SSL**: Let's Encrypt (free) or Cloudflare SSL

### Deployment Steps:

```bash
# 1. Clone repository
git clone https://github.com/yourusername/mail-er.git
cd mail-er

# 2. Install dependencies
composer install --optimize-autoloader --no-dev
npm install && npm run production

# 3. Configure environment
cp .env.example .env
php artisan key:generate

# 4. Configure database in .env
DB_HOST=127.0.0.1
DB_DATABASE=mailer_db
DB_USERNAME=mailer_user
DB_PASSWORD=strong_password

# 5. Run migrations
php artisan migrate --force

# 6. Seed initial data
php artisan db:seed --class=ProviderSeeder
php artisan db:seed --class=SettingsSeeder

# 7. Set permissions
chmod -R 755 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache

# 8. Configure web server (Nginx example)
# Create /etc/nginx/sites-available/mail-er

# 9. Enable site and restart
ln -s /etc/nginx/sites-available/mail-er /etc/nginx/sites-enabled/
systemctl restart nginx

# 10. Setup SSL
certbot --nginx -d mail-er.com -d www.mail-er.com

# 11. Setup supervisor for queues (optional)
# Create /etc/supervisor/conf.d/mail-er.conf

# 12. Cache config for production
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

---

## 8. 🔒 Security Considerations

### Authentication Security:
- ✅ Password hashing with bcrypt (cost factor 12)
- ✅ Rate limiting on login (5 attempts per 15 minutes)
- ✅ Email verification required for registration
- ✅ Remember tokens with secure random generation
- ✅ OAuth tokens encrypted in database
- ✅ CSRF protection on all forms
- ✅ XSS prevention via Blade escaping

### API Security:
- ✅ API rate limiting (60 requests per minute)
- ✅ Input validation and sanitization
- ✅ Provider API keys stored encrypted
- ✅ HTTPS required for production
- ✅ CORS policy configured
- ✅ SQL injection prevention via Eloquent ORM

### Data Privacy:
- ✅ No permanent email storage (temp data only)
- ✅ Messages deleted after provider retention period
- ✅ User data deletion on account termination
- ✅ IP logging anonymization option
- ✅ GDPR compliance ready
- ✅ Cookie consent banner

---

## 9. 📈 Scalability & Performance

### Caching Strategy:
```php
- Config caching: php artisan config:cache
- Route caching: php artisan route:cache
- View caching: php artisan view:cache
- Query caching: Redis for database queries
- Session storage: Redis/Memcached
- Provider health status: Cache for 5 minutes
```

### Queue System:
```php
Jobs to Queue:
- Email generation (if heavy load)
- Provider health checks
- Analytics aggregation
- Email cleanup (expired emails)
- User notifications

Driver: database, redis, or sqs
Workers: 2-4 processes via Supervisor
```

### Load Balancing (Future):
- Multiple app servers behind Nginx
- Database read replicas
- CDN for static assets (Cloudflare)
- Redis cluster for sessions

---

## 10. 🧪 Testing Strategy

### Test Coverage:
- **Unit Tests**: Service classes, helpers, utilities
- **Feature Tests**: Routes, controllers, authentication
- **Browser Tests**: Laravel Dusk for UI testing
- **API Tests**: Provider integration tests

---

## 11. 📊 Success Metrics (KPIs)

### User Metrics:
- Daily Active Users (DAU)
- Monthly Active Users (MAU)
- User Registration Rate
- User Retention (7-day, 30-day)

### System Metrics:
- Emails Generated per Day
- Messages Received per Day
- Provider Uptime %
- API Response Time
- Error Rate

### Business Metrics:
- Ad Revenue (daily/monthly)
- Click-Through Rate (CTR)
- Cost Per Thousand Impressions (CPM)
- Premium Subscription Conversion (future)

---

## 12. 📅 Development Roadmap

### Phase 1: MVP (Current)
- ✅ Core email generation
- ✅ Multi-provider support
- ✅ User authentication
- ✅ Basic admin panel
- ✅ AdSense integration

### Phase 2: Enhancement (Q1 2026)
- 🔄 WebSocket real-time updates
- 🔄 Mobile responsive improvements
- 🔄 Advanced analytics dashboard
- 🔄 Email forwarding feature
- 🔄 Browser extension

### Phase 3: Monetization (Q2 2026)
- 💰 Premium subscription tier
- 💰 API access for developers
- 💰 Custom domain support
- 💰 Advanced ad optimization

### Phase 4: Scale (Q3 2026)
- 🚀 Multi-language support
- 🚀 Progressive Web App (PWA)
- 🚀 Mobile apps (iOS/Android)
- 🚀 Enterprise features

---

## 13. 🤝 Support & Maintenance

### Documentation:
- User Guide
- API Documentation
- Admin Manual
- Developer Guide

### Support Channels:
- Email support
- FAQ page
- Community forum (future)
- GitHub issues

### Maintenance:
- Weekly security updates
- Monthly feature updates
- Quarterly major releases
- Daily backups

---

## 14. 📝 License & Legal

### Application License:
- Proprietary (or MIT/GPL if open source)

### Third-Party Licenses:
- Laravel: MIT License
- Bootstrap: MIT License
- All dependencies: See composer.json

### Terms of Service:
- Usage limits
- Prohibited activities
- Data retention policy
- Privacy policy

---

## 15. 📞 Project Contacts

### Development Team:
- **Project Lead**: [Your Name]
- **Backend Developer**: [Name]
- **Frontend Developer**: [Name]
- **DevOps Engineer**: [Name]

### Stakeholders:
- **Product Owner**: [Name]
- **Business Analyst**: [Name]

---

**Document Version:** 2.0  
**Last Updated:** 2026-01-31  
**Status:** ✅ Active Development

---

This specification provides a comprehensive blueprint for building a scalable, monetizable, and user-friendly temporary email aggregation platform with Laravel 9 and modern web technologies.
