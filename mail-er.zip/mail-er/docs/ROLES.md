# User Roles & Permissions - Enhanced

## Overview
The Mail-ER application implements a three-tier role-based access control (RBAC) system designed to provide different levels of functionality and access to users based on their authentication status and privileges.

---

## 1. 👤 Guest (Unregistered User)

### Access Level: **Public**
**Description:** Anonymous visitors who can use the core temporary email service without creating an account.

### Landing Page Experience
- **Auto-Generation**: Automatically generates a temporary email address upon visiting the site
- **Provider Selection**: Uses the active/default provider configured by admin
- **Instant Access**: No registration required for immediate use
- **Session-Based**: Email persists only for the current browser session

### Capabilities

#### ✅ Core Features:
- **Generate Email**: Automatically create temp email on page load
- **Copy Email Address**: One-click copy to clipboard
- **View Inbox**: Real-time email checking via AJAX polling (every 5-10 seconds)
- **Read Emails**: Open and read received messages
- **View Attachments**: Download attachments (if supported by provider API)
- **Change Email**: Generate a new random email address
- **QR Code**: Display email as QR code for mobile scanning
- **Email Refresh**: Manual refresh button for instant inbox update

#### ❌ Limitations:
- **No History**: Email history is lost after session expires or browser close
- **No Persistence**: Cannot save or favorite emails
- **Limited Retention**: Subject to provider's temporary storage policies
- **No Provider Choice**: Cannot select specific provider (uses default)
- **Ad Exposure**: Full ads visible (no ad-free option)
- **No Notifications**: No email alerts or notifications
- **Session Timeout**: Typically 30-60 minutes of inactivity

### UI Elements (Guest)
```
┌─────────────────────────────────────────┐
│ Header Ad (AdSense Zone 1)             │
├─────────────────────────────────────────┤
│ Your Temp Email: abc123@mail.tm [Copy] │
│ [Refresh] [Generate New]                │
├─────────────────────────────────────────┤
│ Inbox (Auto-refresh every 10s)          │
│ ┌───────────────────────────────────┐   │
│ │ No emails yet...                  │   │
│ └───────────────────────────────────┘   │
├─────────────────────────────────────────┤
│ Sidebar Ad (AdSense Zone 2)            │
└─────────────────────────────────────────┘
```

### Guest User Flow
```
1. Visit Site
   ↓
2. Email Auto-Generated (e.g., random123@mail.tm)
   ↓
3. Use Email Anywhere
   ↓
4. Check Inbox (AJAX polling)
   ↓
5. Read Messages
   ↓
6. [Session Expires] → Email Lost
```

---

## 2. 👥 Registered User

### Access Level: **Authenticated**
**Description:** Users who have created an account via email/password or social login (Google, Facebook).

### Registration Methods
1. **Email/Password**: Traditional registration with email verification
2. **Google OAuth**: One-click sign up with Google account
3. **Facebook Login**: One-click sign up with Facebook account

### Dashboard Features

#### 📧 Email Management:
- **Active Email**: View currently active temporary email
- **Email History**: List of all previously generated emails (with timestamps)
- **Saved Emails**: Pin/favorite important temp emails
- **Search History**: Search through past emails by subject, sender, or content
- **Delete History**: Clear old temp emails from history
- **Export History**: Download email history as CSV/JSON

#### 📊 History Table:
| Email Address | Generated | Provider | Messages | Status | Actions |
|---------------|-----------|----------|----------|--------|---------|
| abc@mail.tm | 2 hrs ago | Mail.tm | 3 | Active | Delete |
| xyz@1secmail.com | 1 day ago | 1secmail | 0 | Expired | Remove |

#### 👤 Profile Management:
- **Update Name**: Change display name
- **Change Password**: Update account password
- **Email Preferences**: Set notification preferences
- **Avatar**: Upload profile picture (or use OAuth avatar)
- **Delete Account**: Permanently delete account and all data
- **Two-Factor Auth**: Enable 2FA for security (future feature)

### Benefits Over Guest

#### ✅ Enhanced Features:
- **Persistent History**: Email history saved in database
- **Longer Sessions**: Stay logged in for 30 days (remember me)
- **Email Notifications**: Optional email alerts for new messages (future)
- **Provider Selection**: Choose preferred temp email provider
- **Priority Support**: Access to support channels
- **Statistics**: View usage stats (emails generated, messages received)
- **API Access**: Personal API key for programmatic access (future)
- **Reduced Ads**: Fewer ad interruptions (configurable by admin)
- **Premium Providers**: Access to premium/paid temp email services (future)

#### ⚙️ Settings & Preferences:
```php
- Auto-refresh interval (5s, 10s, 30s)
- Default provider selection
- Email retention period
- Theme preference (dark/light)
- Language selection
- Notification preferences
```

### Registered User Dashboard
```
┌─────────────────────────────────────────────────┐
│ Welcome back, John! [Profile] [Logout]         │
├─────────────────────────────────────────────────┤
│ Active Email: xyz789@mail.tm [Copy] [Refresh]  │
│ [Generate New] [Provider: Mail.tm ▼]           │
├─────────────────────────────────────────────────┤
│ Recent History                                   │
│ ┌───────────────────────────────────────────┐   │
│ │ abc@mail.tm      | 2 hrs | 3 msgs | [×]  │   │
│ │ xyz@1secmail    | 1 day | 0 msgs | [×]  │   │
│ └───────────────────────────────────────────┘   │
├─────────────────────────────────────────────────┤
│ Stats: 15 emails generated | 42 msgs received  │
└─────────────────────────────────────────────────┘
```

### Data Retention
- **Email History**: Stored for 30 days (configurable)
- **Message Content**: Retained per provider policy (usually 24 hours)
- **Account Data**: Permanent until user deletes account
- **Attachments**: Not stored locally (links to provider)

---

## 3. 👨‍💼 Admin (Super User)

### Access Level: **Administrator**
**Description:** Privileged users with full access to system configuration, user management, and analytics.

### Admin Dashboard

#### 📊 Statistics & Analytics:
```
┌─────────────────────────────────────────────────┐
│ Admin Dashboard                                  │
├─────────────────────────────────────────────────┤
│ Overview Stats                                   │
│ • Total Users: 1,234                            │
│ • Active Users (24h): 456                       │
│ • Emails Generated Today: 3,567                 │
│ • Total Messages Received: 12,345               │
│ • Active Provider: Mail.tm ✅                   │
│ • System Uptime: 99.8%                          │
├─────────────────────────────────────────────────┤
│ Charts                                          │
│ [User Growth Graph]                             │
│ [Email Generation Trends]                       │
│ [Provider Performance]                          │
└─────────────────────────────────────────────────┘
```

### Management Modules

#### 1️⃣ **API Providers Management**

**Purpose:** Configure and manage temporary email service providers

**CRUD Operations:**
- **Create**: Add new provider configuration
- **Read**: View all providers and their status
- **Update**: Modify provider settings
- **Delete**: Remove provider (if no dependencies)

**Provider Fields:**
| Field | Type | Description | Required |
|-------|------|-------------|----------|
| Name | String | Provider name (e.g., "Mail.tm") | ✅ |
| Slug | String | Unique identifier (e.g., "mail-tm") | ✅ |
| Base URL | String | API endpoint (e.g., "https://api.mail.tm") | ✅ |
| API Key | String | Authentication key (if required) | ❌ |
| Driver Class | String | Laravel adapter class | ✅ |
| Is Active | Boolean | Enable/disable provider | ✅ |
| Is Default | Boolean | Use as default for guests | ✅ |
| Priority | Integer | Order preference (1-100) | ✅ |
| Max Per Day | Integer | Rate limit per user | ❌ |
| Retention Hours | Integer | How long emails last | ✅ |
| Features | JSON | Supported features array | ❌ |
| Status | Enum | online/offline/maintenance | ✅ |

**Provider Configuration Example:**
```php
[
    'name' => 'Mail.tm',
    'slug' => 'mail-tm',
    'base_url' => 'https://api.mail.tm',
    'api_key' => null, // No key needed
    'driver_class' => 'App\Services\Providers\MailTmDriver',
    'is_active' => true,
    'is_default' => true,
    'priority' => 1,
    'retention_hours' => 24,
    'features' => ['attachments', 'html_emails'],
    'status' => 'online'
]
```

**Provider Actions:**
- ✅ **Enable/Disable**: Toggle provider availability
- 🔄 **Test Connection**: Verify API is responding
- 📊 **View Stats**: See usage statistics
- 🔧 **Edit Config**: Update settings
- 🗑️ **Delete**: Remove provider
- ⭐ **Set Default**: Make default for new users
- 🚀 **Set All Active**: Enable multiple providers simultaneously

**Multi-Provider Strategy:**
- **Load Balancing**: Distribute users across providers
- **Failover**: Auto-switch if primary fails
- **Provider Selection**: Users can choose preferred provider
- **Health Checks**: Automatic monitoring

#### 2️⃣ **User Management**

**Purpose:** Manage registered users and their permissions

**User List View:**
| ID | Name | Email | Role | Provider | Registered | Status | Actions |
|----|------|-------|------|----------|------------|--------|---------|
| 1 | John | john@mail.com | User | Google | 2 days ago | Active | Edit/Ban/Delete |
| 2 | Jane | jane@mail.com | User | Email | 1 week ago | Active | Edit/Ban/Delete |

**User Actions:**
- **View Details**: See full user profile
- **Edit User**: Update name, email, role
- **Ban User**: Suspend account temporarily
- **Unban User**: Restore banned account
- **Delete User**: Permanently remove (with confirmation)
- **Reset Password**: Force password reset
- **View History**: See user's email generation history
- **Login As**: Impersonate user (debugging)
- **Promote to Admin**: Elevate privileges

**User Statistics:**
```
User: John Doe
- Registered: 2024-01-15
- Last Login: 2 hours ago
- Emails Generated: 45
- Messages Received: 123
- Provider Used: Mail.tm
- Status: Active
- Auth Method: Google OAuth
```

**Bulk Actions:**
- Export user list (CSV/Excel)
- Bulk ban/unban
- Send announcement email
- Delete inactive users (30+ days)

#### 3️⃣ **Settings & Configuration**

##### **General Settings**
```php
- Site Name: "Mail-ER"
- Site Tagline: "Temporary Email Service"
- App URL: "https://mail-er.com"
- Admin Email: "admin@mail-er.com"
- Default Language: "English"
- Timezone: "UTC"
- Date Format: "Y-m-d H:i:s"
- Items Per Page: 20
```

##### **Email Settings**
```php
- SMTP Host: "smtp.gmail.com"
- SMTP Port: 587
- SMTP Username: "..."
- SMTP Password: "..."
- From Name: "Mail-ER"
- From Email: "noreply@mail-er.com"
```

##### **Security Settings**
```php
- Enable Registration: true/false
- Email Verification Required: true/false
- Recaptcha Enabled: true/false
- Recaptcha Site Key: "..."
- Recaptcha Secret: "..."
- Max Login Attempts: 5
- Lockout Duration: 15 minutes
```

##### **Session Settings**
```php
- Guest Session Lifetime: 60 minutes
- User Session Lifetime: 1440 minutes (24h)
- Remember Me Duration: 43200 minutes (30 days)
- Session Driver: "database"
```

#### 4️⃣ **AdSense & Monetization**

**Ad Zone Management:**

| Zone | Position | Size | Code Status | Actions |
|------|----------|------|-------------|---------|
| Header Banner | Top of all pages | 728x90 | ✅ Active | Edit/Disable |
| Sidebar | Right column | 300x600 | ✅ Active | Edit/Disable |
| Email Footer | Below email content | Responsive | ✅ Active | Edit/Disable |
| Interstitial | Full page popup | Full screen | ❌ Disabled | Edit/Enable |

**Ad Configuration Fields:**
```php
[
    'header_ad_enabled' => true,
    'header_ad_code' => '<script async src="..."></script>',
    
    'sidebar_ad_enabled' => true,
    'sidebar_ad_code' => '<script async src="..."></script>',
    
    'email_footer_ad_enabled' => true,
    'email_footer_ad_code' => '<script async src="..."></script>',
    
    'interstitial_enabled' => false,
    'interstitial_code' => '<script async src="..."></script>',
    'interstitial_frequency' => 'once_per_session', // once_per_session, every_hour, every_visit
    'interstitial_delay' => 5, // seconds before showing
    
    'ad_free_for_registered' => false, // Hide ads for logged-in users
]
```

**Ad Revenue Stats:**
```
Monthly Revenue: $1,234.56
Impressions: 45,678
Click-Through Rate: 2.3%
Best Performing Zone: Sidebar
```

#### 5️⃣ **System Logs & Monitoring**

**Activity Log:**
- User registrations
- Login attempts (success/failed)
- Email generations
- Provider failures
- Admin actions
- Security events

**Error Log:**
- API connection failures
- Database errors
- Email delivery failures
- Authentication errors

---

## Permission Matrix

| Feature | Guest | Registered | Admin |
|---------|-------|------------|-------|
| Generate Email | ✅ | ✅ | ✅ |
| View Inbox | ✅ | ✅ | ✅ |
| Read Messages | ✅ | ✅ | ✅ |
| Download Attachments | ✅ | ✅ | ✅ |
| **Save History** | ❌ | ✅ | ✅ |
| **Choose Provider** | ❌ | ✅ | ✅ |
| **Profile Settings** | ❌ | ✅ | ✅ |
| **Export Data** | ❌ | ✅ | ✅ |
| **Manage Providers** | ❌ | ❌ | ✅ |
| **Manage Users** | ❌ | ❌ | ✅ |
| **View Analytics** | ❌ | ❌ | ✅ |
| **Configure Ads** | ❌ | ❌ | ✅ |
| **System Settings** | ❌ | ❌ | ✅ |
| **View Logs** | ❌ | ❌ | ✅ |

---

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255),
    provider VARCHAR(50) NULL,  -- 'google', 'facebook', 'local'
    provider_id VARCHAR(255) NULL,
    avatar VARCHAR(255) NULL,
    role ENUM('guest', 'user', 'admin') DEFAULT 'user',
    is_banned BOOLEAN DEFAULT FALSE,
    email_verified_at TIMESTAMP NULL,
    remember_token VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL,
    INDEX idx_provider (provider, provider_id),
    INDEX idx_role (role)
);
```

---

## Security Considerations

### Guest Users:
- ✅ Rate limiting (max 10 emails per hour per IP)
- ✅ CAPTCHA on generation (if excessive)
- ✅ Session-based tracking
- ✅ No sensitive data storage

### Registered Users:
- ✅ Email verification required
- ✅ Password hashing (bcrypt)
- ✅ Remember token for sessions
- ✅ OAuth token encryption

### Admin Users:
- ✅ 2FA enforcement
- ✅ Activity logging
- ✅ IP whitelist (optional)
- ✅ Separate admin panel route
- ✅ CSRF protection
- ✅ XSS prevention

---

## Future Enhancements

### Potential Features by Role:

**Guest:**
- CAPTCHA-free for trusted IPs
- Browser extension integration

**Registered:**
- Email forwarding to real email
- Push notifications (PWA)
- API access for automation
- Premium ad-free tier ($2.99/month)
- Custom email domains

**Admin:**
- Provider marketplace
- Automated health checks
- Revenue analytics dashboard
- User behavior analytics
- A/B testing for ads
- Multi-admin support with granular permissions

---

This enhanced role system ensures a clear separation of concerns while providing value at each access level, driving user registration through feature incentives while maintaining monetization through strategic ad placement.
