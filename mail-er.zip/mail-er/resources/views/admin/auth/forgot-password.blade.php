<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family:Rajdhani:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        :root {
            --neon-cyan: #00f3ff;
            --neon-violet: #bc13fe;
            --bg-dark: #050510;
            --card-bg: rgba(10, 10, 30, 0.95);
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background: linear-gradient(135deg, #050510 0%, #0a0a1e 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
        }

        .reset-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(0, 243, 255, 0.2);
            border-radius: 20px;
            padding: 50px 40px;
            box-shadow: 0 0 30px rgba(0, 243, 255, 0.1);
            max-width: 450px;
            width: 100%;
            animation: slideUpFade 0.6s ease-out;
        }

        @keyframes slideUpFade {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .reset-logo h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2rem;
            background: linear-gradient(135deg, var(--neon-cyan), var(--neon-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-align: center;
            margin-bottom: 10px;
        }

        .reset-logo p {
            color: rgba(255, 255, 255, 0.7);
            text-align: center;
            margin-bottom: 35px;
        }

        .form-label {
            color: var(--neon-cyan);
            font-weight: 600;
            margin-bottom: 10px;
        }

        .form-control {
            background: rgba(0, 0, 0, 0.6) !important;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: #ffffff !important;
            padding: 12px 15px;
        }

        .form-control:focus {
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.3);
        }

        .btn-glitch {
            background: transparent;
            border: 2px solid var(--neon-cyan);
            color: var(--neon-cyan);
            padding: 12px 30px;
            font-weight: 700;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-family: 'Orbitron', sans-serif;
            text-transform: uppercase;
        }

        .btn-glitch:hover {
            background: var(--neon-cyan);
            color: var(--bg-dark);
            box-shadow: 0 0 25px var(--neon-cyan);
        }

        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border-color: rgba(40, 167, 69, 0.5);
            color: #5dff5d;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="reset-card">
                    <div class="reset-logo">
                        <h1><i class="fas fa-key me-2"></i>RESET PASSWORD</h1>
                        <p>Enter your email to receive a reset link</p>
                    </div>

                    @if (session('status'))
                        <div class="alert alert-success mb-4">
                            <i class="fas fa-check-circle me-2"></i>{{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('admin.password.email') }}">
                        @csrf

                        <div class="mb-4">
                            <label for="email" class="form-label">
                                <i class="fas fa-envelope me-2"></i>EMAIL ADDRESS
                            </label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror" id="email"
                                name="email" value="{{ old('email') }}" required>
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-glitch">
                                <i class="fas fa-paper-plane me-2"></i>SEND RESET LINK
                            </button>
                        </div>

                        <div class="text-center mt-4">
                            <a href="{{ route('admin.login') }}" style="color: var(--neon-violet);">
                                <i class="fas fa-arrow-left me-2"></i>Back to Login
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>