<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Login - Mail-ER</title>

    {{-- Bootstrap 5.3.3 --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    {{-- Font Awesome 6 --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    {{-- Google Fonts --}}
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        :root {
            --neon-cyan: #00f3ff;
            --neon-violet: #bc13fe;
            --bg-dark: #050510;
            --card-bg: rgba(10, 10, 30, 0.95);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background: linear-gradient(135deg, #050510 0%, #0a0a1e 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Background Particles */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            pointer-events: none;
        }

        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: var(--neon-cyan);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--neon-cyan);
            animation: float 20s infinite;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0) translateX(0);
                opacity: 0.5;
            }

            50% {
                transform: translateY(-100px) translateX(50px);
                opacity: 1;
            }
        }

        /* Login Container */
        .login-container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 450px;
            padding: 20px;
        }

        /* Login Card with Glassmorphism */
        .login-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(0, 243, 255, 0.2);
            border-radius: 20px;
            padding: 50px 40px;
            box-shadow:
                0 0 30px rgba(0, 243, 255, 0.1),
                0 8px 32px rgba(0, 0, 0, 0.4),
                inset 0 0 20px rgba(0, 243, 255, 0.05);
            position: relative;
            overflow: hidden;
            animation: slideUpFade 0.6s ease-out;
        }

        @keyframes slideUpFade {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Corner Borders (HUD Style) */
        .login-card::before,
        .login-card::after {
            content: '';
            position: absolute;
            width: 30px;
            height: 30px;
            border: 2px solid var(--neon-cyan);
        }

        .login-card::before {
            top: -1px;
            left: -1px;
            border-right: none;
            border-bottom: none;
        }

        .login-card::after {
            bottom: -1px;
            right: -1px;
            border-left: none;
            border-top: none;
        }

        /* Logo/Title */
        .login-logo {
            text-align: center;
            margin-bottom: 35px;
        }

        .login-logo h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            font-weight: 900;
            background: linear-gradient(135deg, var(--neon-cyan), var(--neon-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: 0 0 30px rgba(0, 243, 255, 0.5);
            margin-bottom: 10px;
        }

        .login-logo p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
            letter-spacing: 1px;
        }

        /* Form Inputs */
        .form-label {
            color: var(--neon-cyan);
            font-weight: 600;
            margin-bottom: 10px;
            font-size: 0.95rem;
            letter-spacing: 0.5px;
        }

        .form-control {
            background: rgba(0, 0, 0, 0.6) !important;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: #ffffff !important;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background: rgba(0, 0, 0, 0.7) !important;
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.3);
            outline: none;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }

        /* Autofill Override */
        .form-control:-webkit-autofill,
        .form-control:-webkit-autofill:hover,
        .form-control:-webkit-autofill:focus {
            -webkit-text-fill-color: #ffffff !important;
            -webkit-box-shadow: 0 0 0px 1000px rgba(0, 0, 0, 0.6) inset !important;
            box-shadow: 0 0 0px 1000px rgba(0, 0, 0, 0.6) inset !important;
            transition: background-color 5000s ease-in-out 0s;
        }

        /* Checkbox */
        .form-check-input {
            background-color: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.2);
            cursor: pointer;
        }

        .form-check-input:checked {
            background-color: var(--neon-cyan);
            border-color: var(--neon-cyan);
        }

        .form-check-label {
            color: rgba(255, 255, 255, 0.8);
            cursor: pointer;
        }

        /* Glitch Button */
        .btn-glitch {
            background: transparent;
            border: 2px solid var(--neon-cyan);
            color: var(--neon-cyan);
            padding: 12px 30px;
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: 1px;
            border-radius: 8px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            font-family: 'Orbitron', sans-serif;
            text-transform: uppercase;
        }

        .btn-glitch::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, var(--neon-cyan), transparent);
            transition: all 0.5s ease;
        }

        .btn-glitch:hover::before {
            left: 100%;
        }

        .btn-glitch:hover {
            background: var(--neon-cyan);
            color: var(--bg-dark);
            box-shadow: 0 0 25px var(--neon-cyan);
            transform: translateY(-2px);
        }

        /* Links */
        a {
            color: var(--neon-violet);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        a:hover {
            color: var(--neon-cyan);
            text-shadow: 0 0 10px var(--neon-cyan);
        }

        /* Alert Messages */
        .alert {
            border-radius: 8px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 25px;
        }

        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border-color: rgba(220, 53, 69, 0.5);
            color: #ff6b6b;
        }

        /* Footer Links */
        .footer-links {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-links a {
            font-size: 0.9rem;
            margin: 0 15px;
        }

        /* Icon in Input */
        .input-group-text {
            background: rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--neon-cyan);
        }
    </style>
</head>

<body>
    {{-- Animated Background Particles --}}
    <div class="particles">
        @for ($i = 0; $i < 20; $i++)
            <div class="particle" style="
                    left: {{ rand(0, 100) }}%;
                    top: {{ rand(0, 100) }}%;
                    animation-delay: {{ rand(0, 10) }}s;
                    animation-duration: {{ rand(15, 25) }}s;
                "></div>
        @endfor
    </div>

    {{-- Login Container --}}
    <div class="login-container">
        <div class="login-card">
            {{-- Logo/Title --}}
            <div class="login-logo">
                <h1><i class="fas fa-shield-halved me-2"></i>ADMIN</h1>
                <p>MAIL-ER Control Panel</p>
            </div>

            {{-- Error Messages --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    @foreach ($errors->all() as $error)
                        <div>{{ $error }}</div>
                    @endforeach
                </div>
            @endif

            {{-- Login Form --}}
            <form method="POST" action="{{ route('admin.login') }}">
                @csrf

                {{-- Email --}}
                <div class="mb-4">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope me-2"></i>EMAIL ADDRESS
                    </label>
                    <input type="email" class="form-control @error('email') is-invalid @enderror" id="email"
                        name="email" value="{{ old('email') }}" placeholder="admin@mail-er.com" required autofocus>
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Password --}}
                <div class="mb-4">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock me-2"></i>PASSWORD
                    </label>
                    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password"
                        name="password" placeholder="••••••••" required>
                    @error('password')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Remember Me --}}
                <div class="mb-4 form-check">
                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                    <label class="form-check-label" for="remember">
                        Remember Me
                    </label>
                </div>

                {{-- Submit Button --}}
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-glitch">
                        <i class="fas fa-sign-in-alt me-2"></i>ACCESS SYSTEM
                    </button>
                </div>

                {{-- Footer Links --}}
                <div class="footer-links">
                    <a href="{{ route('admin.password.request') }}">
                        <i class="fas fa-key me-1"></i>Forgot Password?
                    </a>
                </div>
            </form>
        </div>

        {{-- Back to Homepage --}}
        <div class="text-center mt-4">
            <a href="{{ url('/') }}" class="text-white-50">
                <i class="fas fa-arrow-left me-2"></i>Back to Homepage
            </a>
        </div>
    </div>

    {{-- Bootstrap JS --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>