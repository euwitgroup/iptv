@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
    <style>
        .welcome-banner {
            background: linear-gradient(135deg, #0d8abc 0%, #7b1fa2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            background: white;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }

        .bg-cyan-light { background-color: rgba(13, 224, 255, 0.1); color: #00cfe8; }
        .bg-purple-light { background-color: rgba(115, 103, 240, 0.1); color: #7367f0; }
        .bg-green-light { background-color: rgba(40, 199, 111, 0.1); color: #28c76f; }
        .bg-orange-light { background-color: rgba(255, 159, 67, 0.1); color: #ff9f43; }

        .progress-slim { height: 6px; border-radius: 10px; }
    </style>

    {{-- Welcome Banner --}}
    <div class="welcome-banner d-flex justify-content-between align-items-center">
        <div>
            <h2 class="fw-bold mb-1">Hello, {{ Auth::user()->name }}! 👋</h2>
            <p class="mb-0 opacity-75">Here's what's happening with your platform today.</p>
        </div>
        <div class="d-none d-md-block">
            <button class="btn btn-light text-primary fw-bold shadow-sm" onclick="window.location.reload()">
                <i class="fas fa-sync-alt me-2"></i> Refresh Data
            </button>
        </div>
    </div>

    {{-- Stats Row --}}
    <div class="row g-4 mb-4">
        {{-- Total Users --}}
        <div class="col-md-3">
            <div class="card stat-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <p class="text-muted small text-uppercase fw-bold mb-1">Total Users</p>
                            <h3 class="mb-0 fw-bold">{{ number_format($stats['total_users']) }}</h3>
                        </div>
                        <div class="stat-icon bg-purple-light">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Active Emails --}}
        <div class="col-md-3">
            <div class="card stat-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <p class="text-muted small text-uppercase fw-bold mb-1">Active Inboxes</p>
                            <h3 class="mb-0 fw-bold">{{ number_format($stats['active_emails']) }}</h3>
                        </div>
                        <div class="stat-icon bg-green-light">
                            <i class="fas fa-envelope-open-text"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Total Messages --}}
        <div class="col-md-3">
            <div class="card stat-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <p class="text-muted small text-uppercase fw-bold mb-1">Total Messages</p>
                            <h3 class="mb-0 fw-bold">{{ number_format($stats['total_messages']) }}</h3>
                        </div>
                        <div class="stat-icon bg-cyan-light">
                            <i class="fas fa-comment-dots"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Providers Count --}}
        <div class="col-md-3">
            <div class="card stat-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <p class="text-muted small text-uppercase fw-bold mb-1">Active Providers</p>
                            <h3 class="mb-0 fw-bold">{{ number_format($stats['active_providers']) }}</h3>
                        </div>
                        <div class="stat-icon bg-orange-light">
                            <i class="fas fa-server"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        {{-- Main Chart / Analytics Area --}}
        <div class="col-md-8">
            <div class="card stat-card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="card-title mb-0 fw-bold text-dark">System Analytics</h5>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-light text-dark active">Daily</button>
                            <button class="btn btn-outline-light text-dark">Weekly</button>
                            <button class="btn btn-outline-light text-dark">Monthly</button>
                        </div>
                    </div>

                    <div class="chart-container bg-light rounded-3 d-flex flex-column align-items-center justify-content-center border" style="min-height: 320px;">
                        <i class="fas fa-chart-area fa-3x text-muted opacity-25 mb-3"></i>
                        <h6 class="text-muted fw-bold">Traffic Analysis</h6>
                        <p class="text-muted small mb-0">Detailed traffic charts will appear here once enough data is collected.</p>
                    </div>
                </div>
            </div>
        </div>

        {{-- Top Providers --}}
        <div class="col-md-4">
            <div class="card stat-card h-100">
                <div class="card-body">
                    <h5 class="card-title fw-bold mb-4">Top Domains</h5>
                    <div class="d-flex flex-column gap-4">
                        @foreach($top_providers as $provider)
                            <div>
                                <div class="d-flex justify-content-between small mb-2">
                                    <span class="fw-bold text-dark">{{ ucfirst($provider->provider_slug) }}</span>
                                    <span class="text-muted">{{ number_format($provider->total) }}</span>
                                </div>
                                <div class="progress progress-slim">
                                    @php $percent = $stats['total_generated'] > 0 ? ($provider->total / $stats['total_generated']) * 100 : 0; @endphp
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: {{ $percent }}%"></div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Recent Activity Table --}}
    <div class="card stat-card border-0 mb-4">
        <div class="card-header bg-white border-0 py-3">
             <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title fw-bold mb-0">Recent Activity</h5>
                <a href="#" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="min-width: 600px;">
                <thead class="bg-light">
                    <tr class="text-secondary small text-uppercase">
                        <th class="ps-4 py-3 border-0">Email Identity</th>
                        <th class="py-3 border-0">User</th>
                        <th class="py-3 border-0">Provider</th>
                        <th class="py-3 border-0">Date</th>
                        <th class="pe-4 py-3 text-end border-0">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($recent_activity as $log)
                        <tr>
                            <td class="ps-4 py-3">
                                <div class="d-flex align-items-center">
                                    <div class="stat-icon bg-light text-primary me-3" style="width: 36px; height: 36px; font-size: 1rem;">
                                        <i class="fas fa-at"></i>
                                    </div>
                                    <span class="fw-bold text-dark">{{ $log->email_address }}</span>
                                </div>
                            </td>
                            <td>
                                @if($log->user)
                                    <span class="badge bg-light text-dark border">{{ $log->user->name }}</span>
                                @else
                                    <span class="badge bg-light text-muted border">Guest</span>
                                @endif
                            </td>
                            <td>
                                <span class="text-muted small">
                                    <i class="fas fa-globe me-1"></i> {{ ucfirst($log->provider_slug) }}
                                </span>
                            </td>
                            <td class="text-muted small">
                                {{ $log->generated_at ? \Carbon\Carbon::parse($log->generated_at)->diffForHumans() : '-' }}
                            </td>
                            <td class="pe-4 text-end">
                                @if($log->expires_at && \Carbon\Carbon::parse($log->expires_at)->isPast())
                                    <span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2 rounded-pill">Expired</span>
                                @else
                                    <span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill">Active</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <div class="d-flex flex-column align-items-center">
                                    <i class="far fa-folder-open fa-2x mb-2 opacity-50"></i>
                                    <p class="mb-0">No recent activity logs found.</p>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection