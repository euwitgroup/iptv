@extends('admin.layouts.app')

@section('content')
    <div class="page-header">
        <div>
            <h1 class="page-title">Inbox History</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Inbox</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Generated Emails Log</h5>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Email Address</th>
                            <th>Provider</th>
                            <th>Messages</th>
                            <th>Generated At</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($emails as $email)
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="avatar-sm rounded-circle bg-light d-flex align-items-center justify-content-center me-2 text-primary">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                        <span class="fw-medium">{{ $email->email_address }}</span>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border">{{ $email->provider_slug }}</span>
                                </td>
                                <td>
                                    @if($email->messages_count > 0)
                                        <span class="badge bg-success">{{ $email->messages_count }}</span>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>
                                <td class="text-muted small">
                                    {{ $email->generated_at->diffForHumans() }}
                                </td>
                                <td>
                                    @if($email->expires_at && $email->expires_at->isPast())
                                        <span class="badge bg-danger">Expired</span>
                                    @else
                                        <span class="badge bg-success">Active</span>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('admin.inbox.show', $email->id) }}"
                                        class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="fas fa-inbox fa-3x mb-3 opacity-25"></i>
                                    <p>No email history found.</p>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $emails->links() }}
            </div>
        </div>
    </div>
@endsection