@extends('admin.layouts.app')

@section('content')
    <div class="page-header">
        <div>
            <h1 class="page-title">Email Details</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.inbox.index') }}">Inbox</a></li>
                    <li class="breadcrumb-item active" aria-current="page">{{ $email->email_address }}</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="{{ route('admin.inbox.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to List
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Session Information</h5>

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="text-muted">Email Address</span>
                            <span class="fw-bold">{{ $email->email_address }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="text-muted">Provider</span>
                            <span class="badge bg-info text-dark">{{ $email->provider_slug }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="text-muted">Status</span>
                            @if($email->expires_at && $email->expires_at->isPast())
                                <span class="badge bg-danger">Expired</span>
                            @else
                                <span class="badge bg-success">Active</span>
                            @endif
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="text-muted">Generated At</span>
                            <span>{{ $email->generated_at->format('M d, Y H:i:s') }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="text-muted">Last Checked</span>
                            <span>{{ $email->last_checked_at ? $email->last_checked_at->format('M d, Y H:i:s') : 'Never' }}</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Activity Stats</h5>
                    <div class="text-center py-4">
                        <div class="row">
                            <div class="col-6">
                                <h2 class="display-4 fw-bold text-primary">{{ $email->messages_count }}</h2>
                                <p class="text-muted text-uppercase small letter-spacing-1">Messages Received</p>
                            </div>
                            <div class="col-6 border-start">
                                <div class="mt-3">
                                    @if($email->is_favorite)
                                        <i class="fas fa-star fa-3x text-warning mb-2"></i>
                                        <p class="text-muted text-uppercase small">Marked Favorite</p>
                                    @else
                                        <i class="far fa-star fa-3x text-muted mb-2 opacity-50"></i>
                                        <p class="text-muted text-uppercase small">Not Favorite</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection