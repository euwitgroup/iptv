@extends('admin.layouts.app')

@section('title', 'Create Page')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
             <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.pages.index') }}">Pages</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create</li>
                </ol>
            </nav>
            <h2 class="page-title">Create Page</h2>
        </div>
        <div>
             <a href="{{ route('admin.pages.index') }}" class="btn btn-outline-secondary shadow-sm"><i class="fas fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <form action="{{ route('admin.pages.store') }}" method="POST">
        @csrf
        <div class="row">
            {{-- Main Content --}}
            <div class="col-lg-8">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Page Title</label>
                            <input type="text" class="form-control form-control-lg" name="title" value="{{ old('title') }}" placeholder="e.g. Terms of Service" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Content</label>
                            <textarea class="form-control" name="content" id="content" rows="15">{{ old('content') }}</textarea>
                        </div>
                    </div>
                </div>

                {{-- SEO Section --}}
                 <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-white py-3">
                        <h6 class="card-title mb-0 fw-bold">SEO Optimization</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Meta Title</label>
                            <input type="text" class="form-control" name="meta_title" value="{{ old('meta_title') }}" placeholder="Custom title for search engines (optional)">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Meta Description</label>
                            <textarea class="form-control" name="meta_description" rows="3" placeholder="Brief summary for search results (optional)">{{ old('meta_description') }}</textarea>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Sidebar Settings --}}
            <div class="col-lg-4">
                 <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-white py-3">
                        <h6 class="card-title mb-0 fw-bold">Publishing</h6>
                    </div>
                    <div class="card-body">
                         <div class="mb-3">
                            <label class="form-label">URL Slug</label>
                            <input type="text" class="form-control" name="slug" value="{{ old('slug') }}" placeholder="Auto-generated if empty">
                        </div>
                        
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" id="is_published" name="is_published" checked>
                            <label class="form-check-label" for="is_published">Published</label>
                        </div>
                        <hr>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="show_in_header" name="show_in_header">
                            <label class="form-check-label" for="show_in_header">Show in Header Menu</label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="show_in_footer" name="show_in_footer" checked>
                            <label class="form-check-label" for="show_in_footer">Show in Footer Links</label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">Create Page</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<style>
    .note-editor .note-toolbar {
        background: #f8f9fa;
    }
    .note-editor.note-frame {
        border: 1px solid #dee2e6;
        box-shadow: none;
    }
</style>
@endpush

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
<script>
    $(document).ready(function() {
        $('#content').summernote({
            placeholder: 'Write your page content here...',
            tabsize: 2,
            height: 500,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video', 'hr']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
    });
</script>
@endpush