@extends('admin.layouts.app')

@section('title', 'Pages Management')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Pages</li>
                </ol>
            </nav>
            <h2 class="page-title">Pages</h2>
        </div>
        <div>
            <a href="{{ route('admin.pages.create') }}" class="btn btn-primary shadow-sm"><i class="fas fa-plus me-1"></i>
                Create Page</a>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3 border-0">Title</th>
                            <th class="py-3 border-0">Slug</th>
                            <th class="py-3 border-0">Status</th>
                            <th class="py-3 border-0">Display</th>
                            <th class="py-3 border-0 text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pages as $page)
                            <tr>
                                <td class="ps-4 py-3 fw-bold">{{ $page->title }}</td>
                                <td class="text-muted">{{ $page->slug }}</td>
                                <td>
                                    @if($page->is_published)
                                        <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3">Published</span>
                                    @else
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-3">Draft</span>
                                    @endif
                                </td>
                                <td>
                                    @if($page->show_in_header)
                                        <span class="badge bg-info bg-opacity-10 text-info">Header</span>
                                    @endif
                                    @if($page->show_in_footer)
                                        <span class="badge bg-dark bg-opacity-10 text-dark">Footer</span>
                                    @endif
                                </td>
                                <td class="text-end pe-4">
                                    <a href="{{ route('admin.pages.edit', $page->id) }}"
                                        class="btn btn-sm btn-outline-primary me-1"><i class="fas fa-edit"></i></a>
                                    <form action="{{ route('admin.pages.destroy', $page->id) }}" method="POST" class="d-inline"
                                        onsubmit="return confirm('Are you sure?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" class="btn btn-sm btn-outline-danger"
                                            onclick="this.closest('form').submit()"><i class="fas fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">No pages found. Create one to get started!
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection