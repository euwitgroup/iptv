@extends('admin.layouts.app')

@section('title', 'Add Provider')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('admin.providers.index') }}">Providers</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Add New</li>
                        </ol>
                    </nav>
                    <h2 class="page-title">Add Provider</h2>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <form action="{{ route('admin.providers.store') }}" method="POST">
                        @csrf

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small text-uppercase">Provider Name</label>
                                <input type="text" name="name" class="form-control" placeholder="e.g. Mail.tm" required
                                    value="{{ old('name') }}">
                                @error('name') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small text-uppercase">Slug</label>
                                <input type="text" name="slug" class="form-control" placeholder="e.g. mailtm" required
                                    value="{{ old('slug') }}">
                                @error('slug') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Driver Class</label>
                            <select name="driver_class" class="form-select" required>
                                <option value="">Select a Driver...</option>
                                @foreach($drivers as $class => $name)
                                    <option value="{{ $class }}" {{ old('driver_class') == $class ? 'selected' : '' }}>
                                        {{ $name }} ({{ $class }})
                                    </option>
                                @endforeach
                            </select>
                            @error('driver_class') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Priority (Higher runs first)</label>
                            <input type="number" name="priority" class="form-control" value="0">
                        </div>

                        <div class="mb-4">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" id="isActive" checked>
                                <label class="form-check-label" for="isActive">Active Status</label>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between pt-3 border-top">
                            <a href="{{ route('admin.providers.index') }}" class="btn btn-light text-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary px-4">Create Provider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection