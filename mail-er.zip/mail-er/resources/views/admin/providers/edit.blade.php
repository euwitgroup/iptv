@extends('admin.layouts.app')

@section('title', 'Edit Provider')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('admin.providers.index') }}">Providers</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Edit: {{ $provider->name }}</li>
                        </ol>
                    </nav>
                    <h2 class="page-title">Edit Provider</h2>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <form action="{{ route('admin.providers.update', $provider) }}" method="POST">
                        @csrf
                        @method('PUT')

                        @if ($errors->any())
                            <div class="alert alert-danger mb-4">
                                <ul class="mb-0">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small text-uppercase">Provider Name</label>
                                <input type="text" name="name" class="form-control"
                                    value="{{ old('name', $provider->name) }}" required>
                                @error('name') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small text-uppercase">Slug</label>
                                <input type="text" name="slug" class="form-control"
                                    value="{{ old('slug', $provider->slug) }}" required>
                                @error('slug') <small class="text-danger">{{ $message }}</small> @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Driver Class</label>
                            <select name="driver_class" class="form-select" required>
                                @foreach($drivers as $class => $name)
                                    <option value="{{ $class }}" {{ old('driver_class', $provider->driver_class) == $class ? 'selected' : '' }}>
                                        {{ $name }} ({{ $class }})
                                    </option>
                                @endforeach
                            </select>
                            @error('driver_class') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">API Key (Optional)</label>
                            <input type="text" name="api_key" class="form-control"
                                value="{{ old('api_key', $provider->api_key) }}" placeholder="Leave empty if not required">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Base URL (Automatic if empty)</label>
                            <input type="url" name="base_url" class="form-control"
                                value="{{ old('base_url', $provider->base_url) }}" placeholder="https://api.example.com">
                            @error('base_url') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Priority</label>
                            <input type="number" name="priority" class="form-control"
                                value="{{ old('priority', $provider->priority) }}">
                        </div>

                        <div class="mb-4">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" id="isActive" {{ $provider->is_active ? 'checked' : '' }}>
                                <label class="form-check-label" for="isActive">Active Status</label>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between pt-3 border-top">
                            <a href="{{ route('admin.providers.index') }}" class="btn btn-light text-secondary">Cancel</a>
                            <div class="d-flex gap-2">
                                {{-- Optional Test Button --}}
                                <button type="submit" class="btn btn-primary px-4">Update Provider</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection