@extends('admin.layouts.app')

@section('title', 'Email Providers')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Providers</li>
                </ol>
            </nav>
            <h2 class="page-title">Manage Providers</h2>
        </div>
        <div>
            <a href="{{ route('admin.providers.create') }}" class="btn btn-primary shadow-sm">
                <i class="fas fa-plus me-1"></i> Add Provider
            </a>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary text-uppercase small">
                        <tr>
                            <th class="ps-4">Name</th>
                            <th>Class / Driver</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($providers as $provider)
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold">{{ $provider->name }}</div>
                                    <div class="small text-muted">{{ $provider->slug }}</div>
                                </td>
                                <td>
                                    <code class="small text-primary">{{ class_basename($provider->driver_class) }}</code>
                                </td>
                                <td>
                                    <span class="badge bg-secondary rounded-pill">{{ $provider->priority }}</span>
                                </td>
                                <td>
                                    @if($provider->is_active)
                                        <span class="badge bg-success bg-opacity-10 text-success">Active</span>
                                    @else
                                        <span class="badge bg-danger bg-opacity-10 text-danger">Inactive</span>
                                    @endif
                                </td>
                                <td class="text-end pe-4">
                                    <a href="{{ route('admin.providers.edit', $provider) }}"
                                        class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('admin.providers.destroy', $provider) }}" method="POST"
                                        class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-outline-danger"
                                            onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <i class="fas fa-server fa-3x text-muted mb-3 opacity-25"></i>
                                    <p class="text-muted">No providers configured yet.</p>
                                    <a href="{{ route('admin.providers.create') }}" class="btn btn-sm btn-primary mt-2">Add
                                        First Provider</a>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection