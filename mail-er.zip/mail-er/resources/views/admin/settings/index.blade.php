@extends('admin.layouts.app')

@section('content')
    <div class="page-header">
        <div>
            <h1 class="page-title">System Settings</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Settings</li>
                </ol>
            </nav>
        </div>
    </div>

    @php
        $get = fn($key, $default = '') => \App\Models\Setting::where('key', $key)->value('value') ?? $default;
    @endphp

    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card sticky-top" style="top: 100px;">
                <div class="card-body p-0">
                    <div class="nav flex-column nav-pills" id="settings-tab" role="tablist" aria-orientation="vertical">
                        <a class="nav-link active" id="general-tab" data-bs-toggle="pill" href="#general" role="tab"><i
                                class="fas fa-sliders-h me-2"></i> General</a>
                        <a class="nav-link" id="branding-tab" data-bs-toggle="pill" href="#branding" role="tab"><i
                                class="fas fa-images me-2"></i> Logo & Branding</a>
                        <a class="nav-link" id="seo-tab" data-bs-toggle="pill" href="#seo" role="tab"><i
                                class="fas fa-search me-2"></i> SEO</a>
                        <a class="nav-link" id="mail-tab" data-bs-toggle="pill" href="#mail" role="tab"><i
                                class="fas fa-envelope me-2"></i> Mail Configuration</a>
                        <a class="nav-link" id="plugins-tab" data-bs-toggle="pill" href="#plugins" role="tab"><i
                                class="fas fa-plug me-2"></i> Plugins & Integrations</a>
                        <a class="nav-link" id="ads-tab" data-bs-toggle="pill" href="#ads" role="tab"><i
                                class="fas fa-ad me-2"></i> Google AdSense</a>
                        <a class="nav-link" id="scripts-tab" data-bs-toggle="pill" href="#scripts" role="tab"><i
                                class="fas fa-code me-2"></i> Custom Scripts</a>
                        <a class="nav-link" id="cookies-tab" data-bs-toggle="pill" href="#cookies" role="tab"><i
                                class="fas fa-cookie-bite me-2"></i> Cookie Consent</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="card">
                    <div class="card-body">
                        <div class="tab-content" id="settings-tabContent">

                            {{-- Tab 1: General --}}
                            <div class="tab-pane fade show active" id="general" role="tabpanel">
                                <h5 class="card-title mb-4">General Configuration</h5>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Site Name</label>
                                        <input type="text" class="form-control" name="site_name"
                                            value="{{ $get('site_name', config('app.name')) }}">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Site Title (HTML Title)</label>
                                        <input type="text" class="form-control" name="site_title"
                                            value="{{ $get('site_title') }}">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Copyright Text</label>
                                    <input type="text" class="form-control" name="footer_copyright"
                                        value="{{ $get('footer_copyright', '© ' . date('Y') . ' Mail-ER. All rights reserved.') }}">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Contact Email</label>
                                    <input type="email" class="form-control" name="contact_email"
                                        value="{{ $get('contact_email') }}">
                                </div>

                                <hr>
                                <h6 class="text-muted mb-3">Social Media Links</h6>

                                <div class="row mb-3">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fab fa-whatsapp text-success me-1"></i> WhatsApp
                                            URL</label>
                                        <input type="text" class="form-control" name="social_whatsapp"
                                            value="{{ $get('social_whatsapp') }}" placeholder="https://wa.me/...">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fab fa-facebook text-primary me-1"></i> Facebook
                                            URL</label>
                                        <input type="text" class="form-control" name="social_facebook"
                                            value="{{ $get('social_facebook') }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fab fa-telegram text-info me-1"></i> Telegram
                                            URL</label>
                                        <input type="text" class="form-control" name="social_telegram"
                                            value="{{ $get('social_telegram') }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fab fa-youtube text-danger me-1"></i> YouTube
                                            URL</label>
                                        <input type="text" class="form-control" name="social_youtube"
                                            value="{{ $get('social_youtube') }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fab fa-instagram text-danger me-1"></i>
                                            Instagram URL</label>
                                        <input type="text" class="form-control" name="social_instagram"
                                            value="{{ $get('social_instagram') }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fab fa-twitter text-info me-1"></i> Twitter/X
                                            URL</label>
                                        <input type="text" class="form-control" name="social_twitter"
                                            value="{{ $get('social_twitter') }}">
                                    </div>
                                </div>
                            </div>

                            {{-- Tab 2: Branding --}}
                            <div class="tab-pane fade" id="branding" role="tabpanel">
                                <h5 class="card-title mb-4">Logo & Branding</h5>

                                <div class="mb-4">
                                    <label class="form-label">Site Logo</label>
                                    @if($get('site_logo'))
                                        <div class="mb-2 p-3 bg-light border rounded">
                                            <img src="{{ url($get('site_logo')) }}" alt="Current Logo"
                                                style="max-height: 50px;">
                                        </div>
                                    @endif
                                    <input type="file" class="form-control" name="site_logo" accept="image/*">
                                    <small class="text-muted">Recommended: PNG with transparent background.</small>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label">Favicon</label>
                                    @if($get('site_favicon'))
                                        <div class="mb-2 p-2 bg-light border rounded" style="width: fit-content;">
                                            <img src="{{ asset($get('site_favicon')) }}" alt="Favicon"
                                                style="width: 32px; height: 32px;">
                                        </div>
                                    @endif
                                    <input type="file" class="form-control" name="site_favicon"
                                        accept="image/x-icon,image/png">
                                    <small class="text-muted">Recommended: 32x32px or 16x16px.</small>
                                </div>
                            </div>

                            {{-- Tab 3: SEO --}}
                            <div class="tab-pane fade" id="seo" role="tabpanel">
                                <h5 class="card-title mb-4">SEO Settings</h5>

                                <div class="mb-3">
                                    <label class="form-label">Default Meta Title</label>
                                    <input type="text" class="form-control" name="meta_title"
                                        value="{{ $get('meta_title') }}">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Meta Description</label>
                                    <textarea class="form-control" name="meta_description"
                                        rows="3">{{ $get('meta_description') }}</textarea>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Meta Keywords</label>
                                    <input type="text" class="form-control" name="meta_keywords"
                                        value="{{ $get('meta_keywords') }}"
                                        placeholder="temp mail, disposable email, privacy">
                                </div>
                            </div>

                            {{-- Tab 4: Mail Config --}}
                            <div class="tab-pane fade" id="mail" role="tabpanel">
                                <h5 class="card-title mb-4">Mail Configuration (SMTP)</h5>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i> For the app to send outgoing emails
                                    (e.g., admin notifications), configure SMTP below.
                                </div>

                                <div class="row">
                                    <div class="col-md-8 mb-3">
                                        <label class="form-label">SMTP Host</label>
                                        <input type="text" class="form-control" name="smtp_host"
                                            value="{{ $get('smtp_host', env('MAIL_HOST')) }}">
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">SMTP Port</label>
                                        <input type="text" class="form-control" name="smtp_port"
                                            value="{{ $get('smtp_port', env('MAIL_PORT')) }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">SMTP Username</label>
                                        <input type="text" class="form-control" name="smtp_username"
                                            value="{{ $get('smtp_username', env('MAIL_USERNAME')) }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">SMTP Password</label>
                                        <input type="password" class="form-control" name="smtp_password"
                                            value="{{ $get('smtp_password') }}" placeholder="Leave blank to keep current">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">From Address</label>
                                        <input type="email" class="form-control" name="mail_from_address"
                                            value="{{ $get('mail_from_address', env('MAIL_FROM_ADDRESS')) }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">From Name</label>
                                        <input type="text" class="form-control" name="mail_from_name"
                                            value="{{ $get('mail_from_name', env('MAIL_FROM_NAME')) }}">
                                    </div>
                                </div>
                            </div>

                            {{-- Tab 5: Plugins --}}
                            <div class="tab-pane fade" id="plugins" role="tabpanel">
                                <h5 class="card-title mb-4">Plugins & Integrations</h5>

                                <div class="mb-4 border-bottom pb-4">
                                    <h6 class="fw-bold"><i class="fab fa-whatsapp text-success me-2"></i> WhatsApp Floating
                                        Widget</h6>
                                    <div class="mb-3">
                                        <label class="form-label">WhatsApp Number (with country code)</label>
                                        <input type="text" class="form-control" name="plugin_whatsapp_number"
                                            value="{{ $get('plugin_whatsapp_number') }}" placeholder="e.g. 15551234567">
                                        <small class="text-muted">Adding a number will enable the floating chat
                                            button.</small>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <h6 class="fw-bold"><i class="fas fa-comments text-primary me-2"></i> Tawk.to Live Chat
                                    </h6>
                                    <div class="mb-3">
                                        <label class="form-label">Tawk.to Property ID / Embed Link</label>
                                        <textarea class="form-control" name="plugin_tawk_to_code" rows="5"
                                            placeholder="Paste your Tawk.io embed code here..."></textarea>
                                        <div class="form-text">Current: {{ substr($get('plugin_tawk_to_code'), 0, 50) }}...
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- Tab 6: Ads --}}
                            <div class="tab-pane fade" id="ads" role="tabpanel">
                                <h5 class="card-title mb-4">Google AdSense Configuration</h5>

                                <div class="mb-3">
                                    <label class="form-label">Publisher ID</label>
                                    <input type="text" class="form-control" name="adsense_publisher_id"
                                        value="{{ $get('adsense_publisher_id') }}" placeholder="pub-xxxxxxxxxxxxxxxx">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Auto Ads Code / Header Script</label>
                                    <textarea class="form-control font-monospace" name="adsense_auto_ads_code" rows="5"
                                        placeholder="<script async src=...></script>">{{ $get('adsense_auto_ads_code') }}</textarea>
                                    <small class="text-muted">Paste the code snippet provided by AdSense here. It will be
                                        injected into the &lt;head&gt;.</small>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Home Top Ad (Below Title)</label>
                                        <textarea class="form-control font-monospace" name="adsense_home_top" rows="5"
                                            placeholder="&lt;ins class='adsbygoogle' ...&gt;&lt;/ins&gt;">{{ $get('adsense_home_top') }}</textarea>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Home Bottom Ad (Above Footer)</label>
                                        <textarea class="form-control font-monospace" name="adsense_home_bottom" rows="5"
                                            placeholder="&lt;ins class='adsbygoogle' ...&gt;&lt;/ins&gt;">{{ $get('adsense_home_bottom') }}</textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Home Left Sidebar Ad</label>
                                        <textarea class="form-control font-monospace" name="adsense_home_left" rows="5"
                                            placeholder="&lt;ins class='adsbygoogle' ...&gt;&lt;/ins&gt;">{{ $get('adsense_home_left') }}</textarea>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Home Right Sidebar Ad</label>
                                        <textarea class="form-control font-monospace" name="adsense_home_right" rows="5"
                                            placeholder="&lt;ins class='adsbygoogle' ...&gt;&lt;/ins&gt;">{{ $get('adsense_home_right') }}</textarea>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">ads.txt Content</label>
                                    <textarea class="form-control font-monospace" name="ads_txt" rows="6"
                                        placeholder="google.com, pub-0000000000000000, DIRECT, f08c47fec0942fa0">{{ $get('ads_txt') }}</textarea>
                                    <small class="text-muted">This content will be served at <a href="{{ url('/ads.txt') }}"
                                            target="_blank">{{ url('/ads.txt') }}</a></small>
                                </div>
                            </div>

                            {{-- Tab 7: Custom Scripts --}}
                            <div class="tab-pane fade" id="scripts" role="tabpanel">
                                <h5 class="card-title mb-4">Custom Scripts</h5>

                                <div class="mb-3">
                                    <label class="form-label">Header Scripts (Before &lt;/head&gt;)</label>
                                    <textarea class="form-control font-monospace" name="custom_header_scripts" rows="6"
                                        placeholder="<script>...</script>">{{ $get('custom_header_scripts') }}</textarea>
                                    <small class="text-muted">Useful for Google Analytics, AdSense, etc.</small>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Footer Scripts (Before &lt;/body&gt;)</label>
                                    <textarea class="form-control font-monospace" name="custom_footer_scripts" rows="6"
                                        placeholder="<script>...</script>">{{ $get('custom_footer_scripts') }}</textarea>
                                </div>
                            </div>

                            {{-- Tab 8: Cookie Consent --}}
                            <div class="tab-pane fade" id="cookies" role="tabpanel">
                                <h5 class="card-title mb-4">Cookie Consent Settings</h5>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i> Configure the cookie banner.
                                </div>
                                <div class="form-check form-switch mb-3 p-3 border rounded bg-light">
                                    <input type="hidden" name="cookie_consent_enabled" value="0">
                                    <input class="form-check-input" type="checkbox" name="cookie_consent_enabled" value="1"
                                        id="cookieEnabled" {{ $get('cookie_consent_enabled', '') ? 'checked' : '' }}
                                        style="margin-left: 0; margin-right: 10px;">
                                    <label class="form-check-label fw-bold" for="cookieEnabled">Enable Cookie Consent
                                        Banner</label>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Message Text</label>
                                    <textarea class="form-control" name="cookie_consent_message"
                                        rows="3">{{ $get('cookie_consent_message', 'We use cookies to ensure you get the best experience on our website.') }}</textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">"Accept" Button Text</label>
                                        <input type="text" class="form-control" name="cookie_consent_agree"
                                            value="{{ $get('cookie_consent_agree', 'Accept') }}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">"Decline" Button Text</label>
                                        <input type="text" class="form-control" name="cookie_consent_decline"
                                            value="{{ $get('cookie_consent_decline', 'Decline') }}">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer text-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Save Changes
                        </button>
                        <button type="reset" class="btn btn-outline-secondary ms-2">Reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <style>
        .nav-pills .nav-link {
            color: #495057;
            padding: 12px 20px;
            text-align: left;
        }

        .nav-pills .nav-link.active {
            background-color: #0d6efd;
        }

        .nav-pills .nav-link i {
            width: 25px;
            text-align: center;
        }
    </style>
@endsection