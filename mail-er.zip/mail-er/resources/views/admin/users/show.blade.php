@extends('admin.layouts.app')

@section('content')
    <div class="page-header">
        <div>
            <h1 class="page-title">User Profile</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}">Users</a></li>
                    <li class="breadcrumb-item active" aria-current="page">{{ $user->name }}</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="{{ route('admin.users.edit', $user->id) }}" class="btn btn-primary me-2">
                <i class="fas fa-edit me-2"></i> Edit User
            </a>
            <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to List
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card text-center h-100">
                <div class="card-body">
                    <img src="https://ui-avatars.com/api/?name={{ urlencode($user->name) }}&background=random&size=128"
                        class="rounded-circle mb-3" alt="{{ $user->name }}" style="width: 100px; height: 100px;">
                    <h4 class="mb-1">{{ $user->name }}</h4>
                    <p class="text-muted mb-3">{{ $user->email }}</p>

                    <span class="badge {{ $user->role === 'admin' ? 'bg-primary' : 'bg-secondary' }} px-3 py-2">
                        {{ ucfirst($user->role) }}
                    </span>
                </div>
                <div class="card-footer bg-light text-muted small">
                    Member since {{ $user->created_at->format('M Y') }}
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Profile Details</h5>

                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                                <tr>
                                    <th style="width: 30%">Full Name</th>
                                    <td>{{ $user->name }}</td>
                                </tr>
                                <tr>
                                    <th>Email Address</th>
                                    <td>{{ $user->email }}</td>
                                </tr>
                                <tr>
                                    <th>Role</th>
                                    <td>{{ ucfirst($user->role) }}</td>
                                </tr>
                                <tr>
                                    <th>Account Status</th>
                                    <td><span class="text-success"><i class="fas fa-check-circle me-1"></i> Active</span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Registered On</th>
                                    <td>{{ $user->created_at->format('F d, Y h:i A') }}</td>
                                </tr>
                                <tr>
                                    <th>Last Updated</th>
                                    <td>{{ $user->updated_at->format('F d, Y h:i A') }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    @if(method_exists($user, 'tempEmails') && $user->tempEmails->count() > 0)
                        <hr>
                        <h5 class="card-title mt-4">Recent Activity</h5>
                        <p>Generated {{ $user->tempEmails->count() }} temporary emails.</p>
                        <a href="{{ route('admin.inbox.index') }}" class="btn btn-sm btn-outline-primary">View History</a>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection