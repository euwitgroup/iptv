@extends('installer.layout')

@section('content')
    <div class="installer-header">
        <h1><i class="fas fa-user-shield me-2"></i>Admin Account</h1>
        <p>Create your administrator account</p>
    </div>

    <div class="step-indicator">
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Welcome</div>
        </div>
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Requirements</div>
        </div>
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Database</div>
        </div>
        <div class="step active">
            <div class="step-circle">4</div>
            <div class="step-label">Admin</div>
        </div>
        <div class="step">
            <div class="step-circle">5</div>
            <div class="step-label">Finish</div>
        </div>
    </div>

    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Error:</strong>
            <ul class="mb-0 mt-2">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('installer.admin.store') }}" method="POST">
        @csrf

        <h5 class="mb-3"><i class="fas fa-cog me-2"></i>Application Settings</h5>

        <div class="mb-3">
            <label for="app_name" class="form-label">Application Name</label>
            <input type="text" class="form-control" id="app_name" name="app_name" value="{{ old('app_name', 'Mail-ER') }}"
                required>
        </div>

        <div class="mb-4">
            <label for="app_url" class="form-label">Application URL</label>
            <input type="url" class="form-control" id="app_url" name="app_url"
                value="{{ old('app_url', request()->root()) }}" placeholder="https://yourdomain.com" required>
            <small class="text-muted">Your website URL (with http:// or https://)</small>
        </div>

        <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">

        <h5 class="mb-3"><i class="fas fa-user-shield me-2"></i>Administrator Account</h5>

        <div class="mb-3">
            <label for="admin_name" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="admin_name" name="admin_name" value="{{ old('admin_name') }}"
                placeholder="John Doe" required>
        </div>

        <div class="mb-3">
            <label for="admin_email" class="form-label">Email Address</label>
            <input type="email" class="form-control" id="admin_email" name="admin_email" value="{{ old('admin_email') }}"
                placeholder="admin@yourdomain.com" required>
            <small class="text-muted">You'll use this to login to the admin panel</small>
        </div>

        <div class="mb-3">
            <label for="admin_password" class="form-label">Password</label>
            <input type="password" class="form-control" id="admin_password" name="admin_password"
                placeholder="Minimum 8 characters" required>
            <div class="progress mt-2" style="height: 4px;">
                <div id="password-strength" class="progress-bar" role="progressbar" style="width: 0%"></div>
            </div>
            <small id="password-strength-text" class="text-muted">Password strength: <span>Weak</span></small>
        </div>

        <div class="mb-3">
            <label for="admin_password_confirmation" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="admin_password_confirmation" name="admin_password_confirmation"
                placeholder="Re-enter password" required>
        </div>

        <div class="alert alert-warning"
            style="background: rgba(255, 193, 7, 0.1); color: #fff; border-left: 4px solid #ffc107;">
            <i class="fas fa-lock me-2"></i>
            <strong>Important:</strong> Remember these credentials! You'll need them to access the admin panel.
        </div>

        <div class="d-flex justify-content-between mt-4">
            <a href="{{ route('installer.database') }}" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-2"></i> Back
            </a>

            <button type="submit" class="btn btn-primary" id="btnSubmit">
                <span class="btn-text">Create & Continue <i class="fas fa-arrow-right ms-2"></i></span>
                <span class="btn-loader d-none">
                    <span class="spinner-border spinner-border-sm me-2"></span> Creating...
                </span>
            </button>
        </div>
    </form>
@endsection

@section('scripts')
    <script>
        // Password strength indicator
        document.getElementById('admin_password').addEventListener('input', function () {
            const password = this.value;
            let strength = 0;

            if (password.length >= 8) strength += 25;
            if (password.length >= 12) strength += 25;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength += 25;
            if (/[0-9]/.test(password) && /[^a-zA-Z0-9]/.test(password)) strength += 25;

            const bar = document.getElementById('password-strength');
            const text = document.querySelector('#password-strength-text span');

            bar.style.width = strength + '%';

            if (strength < 50) {
                bar.className = 'progress-bar bg-danger';
                text.textContent = 'Weak';
            } else if (strength < 75) {
                bar.className = 'progress-bar bg-warning';
                text.textContent = 'Medium';
            } else {
                bar.className = 'progress-bar bg-success';
                text.textContent = 'Strong';
            }
        });

        // Form submission
        document.querySelector('form').addEventListener('submit', function () {
            const btn = document.getElementById('btnSubmit');
            btn.disabled = true;
            btn.querySelector('.btn-text').classList.add('d-none');
            btn.querySelector('.btn-loader').classList.remove('d-none');
        });
    </script>
@endsection