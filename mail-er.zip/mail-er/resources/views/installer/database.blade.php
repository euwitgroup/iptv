@extends('installer.layout')

@section('content')
    <div class="installer-header">
        <h1><i class="fas fa-database me-2"></i>Database Configuration</h1>
        <p>Enter your database credentials</p>
    </div>

    <div class="step-indicator">
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Welcome</div>
        </div>
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Requirements</div>
        </div>
        <div class="step active">
            <div class="step-circle">3</div>
            <div class="step-label">Database</div>
        </div>
        <div class="step">
            <div class="step-circle">4</div>
            <div class="step-label">Admin</div>
        </div>
        <div class="step">
            <div class="step-circle">5</div>
            <div class="step-label">Finish</div>
        </div>
    </div>

    @if($errors->any())
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Error:</strong> {{ $errors->first() }}
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">
            <i class="fas fa-check-circle me-2"></i>
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('installer.database.store') }}" method="POST">
        @csrf

        <div class="row">
            <div class="col-md-8 mb-3">
                <label for="db_host" class="form-label">Database Host</label>
                <input type="text" class="form-control" id="db_host" name="db_host"
                    value="{{ old('db_host', '127.0.0.1') }}" placeholder="127.0.0.1" required>
                <small class="text-muted">Usually: localhost or 127.0.0.1</small>
            </div>

            <div class="col-md-4 mb-3">
                <label for="db_port" class="form-label">Port</label>
                <input type="number" class="form-control" id="db_port" name="db_port" value="{{ old('db_port', '3306') }}"
                    placeholder="3306" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="db_name" class="form-label">Database Name</label>
            <input type="text" class="form-control" id="db_name" name="db_name" value="{{ old('db_name') }}"
                placeholder="mail_er_db" required>
            <small class="text-muted">Database must already exist in MySQL</small>
        </div>

        <div class="mb-3">
            <label for="db_user" class="form-label">Database Username</label>
            <input type="text" class="form-control" id="db_user" name="db_user" value="{{ old('db_user', 'root') }}"
                placeholder="root" required>
        </div>

        <div class="mb-3">
            <label for="db_password" class="form-label">Database Password</label>
            <input type="password" class="form-control" id="db_password" name="db_password" value="{{ old('db_password') }}"
                placeholder="Enter password (leave blank if none)">
        </div>

        <div class="alert alert-info"
            style="background: rgba(0, 243, 255, 0.1); color: #fff; border-left: 4px solid var(--primary-cyan);">
            <i class="fas fa-info-circle me-2"></i>
            <strong>Note:</strong> This will create all necessary database tables and seed initial data.
        </div>

        <div class="d-flex justify-content-between mt-4">
            <a href="{{ route('installer.requirements') }}" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-2"></i> Back
            </a>

            <button type="submit" class="btn btn-primary" id="btnSubmit">
                <span class="btn-text">Test & Continue <i class="fas fa-arrow-right ms-2"></i></span>
                <span class="btn-loader d-none">
                    <span class="spinner-border spinner-border-sm me-2"></span> Configuring...
                </span>
            </button>
        </div>
    </form>
@endsection

@section('scripts')
    <script>
        document.querySelector('form').addEventListener('submit', function () {
            const btn = document.getElementById('btnSubmit');
            btn.disabled = true;
            btn.querySelector('.btn-text').classList.add('d-none');
            btn.querySelector('.btn-loader').classList.remove('d-none');
        });
    </script>
@endsection