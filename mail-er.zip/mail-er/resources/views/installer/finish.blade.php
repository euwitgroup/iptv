@extends('installer.layout')

@section('content')
    <div class="installer-header">
        <h1><i class="fas fa-check-circle me-2"></i>Installation Complete!</h1>
        <p>Finalizing your setup</p>
    </div>

    <div class="step-indicator">
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Welcome</div>
        </div>
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Requirements</div>
        </div>
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Database</div>
        </div>
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Admin</div>
        </div>
        <div class="step active">
            <div class="step-circle">5</div>
            <div class="step-label">Finish</div>
        </div>
    </div>

    <div id="installation-progress" class="text-center">
        <h3 class="mb-4">Running final optimizations...</h3>

        <div class="progress mb-4" style="height: 30px; border-radius: 15px; overflow: hidden;">
            <div id="progress-bar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
                style="width: 0%; background: linear-gradient(90deg, var(--primary-cyan), var(--primary-violet));">
                <span id="progress-text">0%</span>
            </div>
        </div>

        <div id="status-messages" class="text-start mb-4">
            <div class="status-item mb-2" data-step="1">
                <i class="fas fa-spinner fa-spin me-2"></i>
                <span>Creating storage links...</span>
            </div>
            <div class="status-item mb-2 text-muted" data-step="2">
                <i class="far fa-circle me-2"></i>
                <span>Optimizing configuration...</span>
            </div>
            <div class="status-item mb-2 text-muted" data-step="3">
                <i class="far fa-circle me-2"></i>
                <span>Caching routes...</span>
            </div>
            <div class="status-item mb-2 text-muted" data-step="4">
                <i class="far fa-circle me-2"></i>
                <span>Caching views...</span>
            </div>
            <div class="status-item mb-2 text-muted" data-step="5">
                <i class="far fa-circle me-2"></i>
                <span>Finalizing installation...</span>
            </div>
        </div>
    </div>

    <div id="installation-complete" class="text-center d-none">
        <i class="fas fa-check-circle fa-5x mb-4" style="color: #28a745;"></i>
        <h2 class="mb-4">🎉 Installation Successful!</h2>

        <div class="alert alert-success"
            style="background: rgba(40, 167, 69, 0.2); color: #fff; border-left: 4px solid #28a745;">
            <i class="fas fa-check-circle me-2"></i>
            <strong>Great!</strong> Mail-ER has been installed successfully.
        </div>

        <div class="row text-start my-4">
            <div class="col-md-6">
                <div class="p-3 rounded" style="background: rgba(0, 0, 0, 0.2);">
                    <h6 class="mb-3"><i class="fas fa-user me-2"></i>Frontend Access</h6>
                    <p class="mb-2"><strong>URL:</strong> <a href="/" target="_blank" class="text-info">{{ url('/') }}</a>
                    </p>
                    <p class="mb-0 text-muted">Your main website for users</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="p-3 rounded" style="background: rgba(0, 0, 0, 0.2);">
                    <h6 class="mb-3"><i class="fas fa-shield-alt me-2"></i>Admin Panel</h6>
                    <p class="mb-2"><strong>URL:</strong> <a href="/admin/login" target="_blank"
                            class="text-info">{{ url('/admin/login') }}</a></p>
                    <p class="mb-0 text-muted">Login with your admin credentials</p>
                </div>
            </div>
        </div>

        <div class="alert alert-info"
            style="background: rgba(0, 243, 255, 0.1); color: #fff; border-left: 4px solid var(--primary-cyan);">
            <i class="fas fa-lightbulb me-2"></i>
            <strong>Next Steps:</strong>
            <ul class="mb-0 mt-2 text-start">
                <li>Configure your site settings in Admin Panel → Settings</li>
                <li>Review and customize your content pages</li>
                <li>Test email generation and inbox functionality</li>
                <li>Enable HTTPS/SSL for your domain</li>
            </ul>
        </div>

        <div class="mt-4">
            <a href="/admin/login" class="btn btn-primary btn-lg me-2">
                <i class="fas fa-sign-in-alt me-2"></i> Go to Admin Panel
            </a>
            <a href="/" class="btn btn-outline-light btn-lg">
                <i class="fas fa-home me-2"></i> View Website
            </a>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        let currentStep = 0;
        const steps = ['storage:link', 'config:cache', 'route:cache', 'view:cache', 'complete'];

        function updateProgress(step) {
            const progress = Math.round(((step) / steps.length) * 100);
            document.getElementById('progress-bar').style.width = progress + '%';
            document.getElementById('progress-text').textContent = progress + '%';

            // Update status items
            document.querySelectorAll('.status-item').forEach((item, index) => {
                const icon = item.querySelector('i');
                const stepNum = index + 1;

                if (stepNum < step) {
                    item.classList.remove('text-muted');
                    item.classList.add('text-success');
                    icon.className = 'fas fa-check-circle me-2';
                } else if (stepNum === step) {
                    item.classList.remove('text-muted');
                    icon.className = 'fas fa-spinner fa-spin me-2';
                }
            });
        }

        function runInstallation() {
            const interval = setInterval(() => {
                currentStep++;
                updateProgress(currentStep);

                if (currentStep >= steps.length) {
                    clearInterval(interval);
                    setTimeout(() => {
                        fetch('{{ route('installer.complete') }}', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            }
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    document.getElementById('installation-progress').classList.add('d-none');
                                    document.getElementById('installation-complete').classList.remove('d-none');
                                } else {
                                    alert('Error completing installation: ' + data.message);
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                            });
                    }, 500);
                }
            }, 1000);
        }

        // Auto-start installation
        document.addEventListener('DOMContentLoaded', runInstallation);
    </script>
@endsection