<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail-ER Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap"
        rel="stylesheet">
    <style>
        :root {
            --primary-cyan: #00f3ff;
            --primary-violet: #bc13fe;
            --dark-bg: #050510;
        }

        body {
            background: linear-gradient(135deg, #0a0a1e 0%, #1a1a2e 100%);
            font-family: 'Rajdhani', sans-serif;
            min-height: 100vh;
            color: #fff;
        }

        .installer-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }

        .installer-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .installer-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .installer-header h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            background: linear-gradient(135deg, var(--primary-cyan) 0%, var(--primary-violet) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }

        .installer-header p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.1rem;
        }

        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            position: relative;
        }

        .step-indicator::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 2px;
            background: rgba(255, 255, 255, 0.1);
            z-index: 0;
        }

        .step {
            text-align: center;
            flex: 1;
            position: relative;
            z-index: 1;
        }

        .step-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
            transition: all 0.3s;
        }

        .step.active .step-circle {
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            border-color: var(--primary-cyan);
            box-shadow: 0 0 20px rgba(0, 243, 255, 0.5);
        }

        .step.completed .step-circle {
            background: #28a745;
            border-color: #28a745;
        }

        .step-label {
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.6);
        }

        .step.active .step-label {
            color: #fff;
            font-weight: 600;
        }

        .form-label {
            color: rgba(255, 255, 255, 0.9);
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-control,
        .form-select {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 12px;
            border-radius: 8px;
        }

        .form-control:focus,
        .form-select:focus {
            background: rgba(0, 0, 0, 0.4);
            border-color: var(--primary-cyan);
            color: #fff;
            box-shadow: 0 0 0 3px rgba(0, 243, 255, 0.1);
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-violet) 0%, #9b10d4 100%);
            border: none;
            padding: 14px 32px;
            font-weight: 700;
            border-radius: 24px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(188, 19, 254, 0.4);
        }

        .btn-outline-light {
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 24px;
            padding: 14px 32px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .btn-outline-light:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: #fff;
        }

        .alert {
            border-radius: 12px;
            border: none;
        }

        .requirement-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .requirement-item.success {
            border-left: 3px solid #28a745;
        }

        .requirement-item.error {
            border-left: 3px solid #dc3545;
        }

        .loader {
            border: 3px solid rgba(255, 255, 255, 0.1);
            border-top: 3px solid var(--primary-cyan);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
    @yield('styles')
</head>

<body>
    <div class="installer-container">
        <div class="installer-card">
            @yield('content')
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    @yield('scripts')
</body>

</html>