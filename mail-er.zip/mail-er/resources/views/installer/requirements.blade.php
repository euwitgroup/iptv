@extends('installer.layout')

@section('content')
    <div class="installer-header">
        <h1><i class="fas fa-tasks me-2"></i>System Requirements</h1>
        <p>Checking your server configuration</p>
    </div>

    <div class="step-indicator">
        <div class="step completed">
            <div class="step-circle"><i class="fas fa-check"></i></div>
            <div class="step-label">Welcome</div>
        </div>
        <div class="step active">
            <div class="step-circle">2</div>
            <div class="step-label">Requirements</div>
        </div>
        <div class="step">
            <div class="step-circle">3</div>
            <div class="step-label">Database</div>
        </div>
        <div class="step">
            <div class="step-circle">4</div>
            <div class="step-label">Admin</div>
        </div>
        <div class="step">
            <div class="step-circle">5</div>
            <div class="step-label">Finish</div>
        </div>
    </div>

    <div class="mb-5">
        <h4 class="mb-3"><i class="fas fa-server me-2"></i>PHP Extensions</h4>
        @foreach($requirements as $name => $installed)
            <div class="requirement-item {{ $installed ? 'success' : 'error' }}">
                <span>
                    @if($installed)
                        <i class="fas fa-check-circle text-success me-2"></i>
                    @else
                        <i class="fas fa-times-circle text-danger me-2"></i>
                    @endif
                    {{ ucfirst($name) }}
                </span>
                <span class="badge {{ $installed ? 'bg-success' : 'bg-danger' }}">
                    {{ $installed ? 'Installed' : 'Missing' }}
                </span>
            </div>
        @endforeach
    </div>

    <div class="mb-5">
        <h4 class="mb-3"><i class="fas fa-folder-open me-2"></i>Directory Permissions</h4>
        @foreach($permissions as $path => $writable)
            <div class="requirement-item {{ $writable ? 'success' : 'error' }}">
                <span>
                    @if($writable)
                        <i class="fas fa-check-circle text-success me-2"></i>
                    @else
                        <i class="fas fa-times-circle text-danger me-2"></i>
                    @endif
                    {{ $path }}
                </span>
                <span class="badge {{ $writable ? 'bg-success' : 'bg-danger' }}">
                    {{ $writable ? 'Writable' : 'Not Writable' }}
                </span>
            </div>
        @endforeach
    </div>

    @if(!$allRequirementsMet || !$allPermissionsSet)
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Warning:</strong> Some requirements are not met. Please fix the issues above before continuing.

            @if(!$allPermissionsSet)
                <div class="mt-3">
                    <strong>To fix permissions, run:</strong>
                    <pre class="bg-dark p-3 rounded mt-2" style="color: #0f0;">chmod -R 775 storage bootstrap/cache</pre>
                </div>
            @endif
        </div>
    @else
        <div class="alert alert-success"
            style="background: rgba(40, 167, 69, 0.2); color: #fff; border-left: 4px solid #28a745;">
            <i class="fas fa-check-circle me-2"></i>
            <strong>Great!</strong> Your server meets all requirements.
        </div>
    @endif

    <div class="d-flex justify-content-between mt-4">
        <a href="{{ route('installer.welcome') }}" class="btn btn-outline-light">
            <i class="fas fa-arrow-left me-2"></i> Back
        </a>

        @if($allRequirementsMet && $allPermissionsSet)
            <a href="{{ route('installer.database') }}" class="btn btn-primary">
                Continue <i class="fas fa-arrow-right ms-2"></i>
            </a>
        @else
            <button class="btn btn-secondary" disabled>
                Fix Issues First
            </button>
        @endif
    </div>
@endsection