@extends('installer.layout')

@section('content')
    <div class="installer-header">
        <h1><i class="fas fa-rocket me-2"></i>Mail-ER Installation</h1>
        <p>Welcome to the automated installation wizard</p>
    </div>

    <div class="step-indicator">
        <div class="step active">
            <div class="step-circle">1</div>
            <div class="step-label">Welcome</div>
        </div>
        <div class="step">
            <div class="step-circle">2</div>
            <div class="step-label">Requirements</div>
        </div>
        <div class="step">
            <div class="step-circle">3</div>
            <div class="step-label">Database</div>
        </div>
        <div class="step">
            <div class="step-circle">4</div>
            <div class="step-label">Admin</div>
        </div>
        <div class="step">
            <div class="step-circle">5</div>
            <div class="step-label">Finish</div>
        </div>
    </div>

    <div class="text-center">
        <i class="fas fa-envelope fa-5x mb-4" style="color: var(--primary-cyan);"></i>
        <h2 class="mb-4">Welcome to Mail-ER</h2>
        <p class="lead mb-4">
            This installation wizard will guide you through the setup process.<br>
            It will take approximately 2-3 minutes to complete.
        </p>

        <div class="row text-start my-5">
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-check-circle text-success me-2"></i>What we'll do:</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i> Check server requirements</li>
                    <li class="mb-2"><i class="fas fa-database text-primary me-2"></i> Configure database</li>
                    <li class="mb-2"><i class="fas fa-user-shield text-primary me-2"></i> Create admin account</li>
                    <li class="mb-2"><i class="fas fa-rocket text-primary me-2"></i> Optimize for production</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-info-circle text-info me-2"></i>Requirements:</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> PHP 8.0+</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> MySQL 5.7+</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Composer installed</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Writable storage folder</li>
                </ul>
            </div>
        </div>

        <div class="alert alert-info"
            style="background: rgba(0, 243, 255, 0.1); color: #fff; border-left: 4px solid var(--primary-cyan);">
            <i class="fas fa-lightbulb me-2"></i>
            <strong>Tip:</strong> Make sure you have your database credentials ready before proceeding.
        </div>

        <div class="mt-4">
            <a href="{{ route('installer.requirements') }}" class="btn btn-primary btn-lg">
                Get Started <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>
@endsection