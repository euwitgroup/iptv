<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Mail-ER') }} - @yield('title', 'Premium Gaming Platform')</title>

    <!-- Google Fonts: Orbitron (Headers) & Rajdhani (Body) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5.3.3 (Latest) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        /* ===============================================
           PREMIUM GAMING THEME - GLOBAL STYLES
           =============================================== */
        
        :root {
            /* Neon Colors */
            --neon-cyan: #00f3ff;
            --neon-violet: #bc13fe;
            --neon-cyan-glow: rgba(0, 243, 255, 0.5);
            --neon-violet-glow: rgba(188, 19, 254, 0.5);
            
            /* Dark Theme */
            --bg-deep-dark: #050510;
            --bg-overlay: rgba(5, 5, 16, 0.95);
            --bg-glass: rgba(255, 255, 255, 0.05);
            --bg-glass-hover: rgba(255, 255, 255, 0.08);
            
            /* Text */
            --text-white: #ffffff;
            --text-gray: rgba(255, 255, 255, 0.7);
            
            /* Borders */
            --border-neon: rgba(0, 243, 255, 0.3);
            --border-white: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background-color: var(--bg-deep-dark);
            color: var(--text-white);
            min-height: 100vh;
            background-image: url('https://images.unsplash.com/photo-1614732414444-096e5f1122d5?q=80&w=2000&auto=format&fit=crop');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--bg-overlay);
            z-index: -1;
        }

        /* Floating Particles Background Effect */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: var(--neon-cyan);
            border-radius: 50%;
            opacity: 0.3;
            animation: float 15s infinite ease-in-out;
            box-shadow: 0 0 10px var(--neon-cyan-glow);
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-100px) translateX(50px); }
            50% { transform: translateY(-200px) translateX(-30px); }
            75% { transform: translateY(-100px) translateX(-60px); }
        }

        /* Typography */
        h1, h2, h3, h4, h5, h6,
        .orbitron {
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        h1 { font-size: 3rem; }
        h2 { font-size: 2.5rem; }
        h3 { font-size: 2rem; }

        /* HUD-Style Cards with Glassmorphism */
        .card-hud,
        .card {
            background: var(--bg-glass);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 2px solid var(--border-neon);
            border-radius: 15px;
            padding: 2rem;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            animation: slideUpFade 0.8s ease-out;
        }

        .card-hud::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--neon-cyan-glow) 0%, transparent 50%, var(--neon-violet-glow) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
            pointer-events: none;
        }

        .card-hud:hover::before {
            opacity: 0.1;
        }

        .card-hud:hover {
            border-color: var(--neon-cyan);
            box-shadow: 0 0 30px var(--neon-cyan-glow);
            transform: translateY(-5px);
        }

        /* Corner Borders for HUD Effect */
        .corner-borders {
            position: relative;
        }

        .corner-borders::before,
        .corner-borders::after,
        .corner-borders > *::before,
        .corner-borders > *::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            border: 2px solid var(--neon-cyan);
        }

        .corner-borders::before {
            top: -2px;
            left: -2px;
            border-right: none;
            border-bottom: none;
        }

        .corner-borders::after {
            top: -2px;
            right: -2px;
            border-left: none;
            border-bottom: none;
        }

        /* Inputs - STRICTLY DARK */
        .form-control,
        .form-select,
        input,
        textarea,
        select {
            background-color: rgba(0, 0, 0, 0.6) !important;
            border: 1px solid var(--border-white);
            border-radius: 8px;
            color: var(--text-white) !important;
            padding: 0.75rem 1rem;
            font-family: 'Rajdhani', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        /* Critical: Autofill Override */
        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus,
        input:-webkit-autofill:active {
            -webkit-box-shadow: 0 0 0 30px rgba(0, 0, 0, 0.6) inset !important;
            -webkit-text-fill-color: var(--text-white) !important;
            caret-color: var(--text-white);
        }

        .form-control:focus,
        .form-select:focus,
        input:focus,
        textarea:focus,
        select:focus {
            background-color: rgba(0, 0, 0, 0.8) !important;
            border-color: var(--neon-cyan);
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.3);
            outline: none;
        }

        .form-control::placeholder {
            color: var(--text-gray);
        }

        /* Glitch-Style Buttons */
        .btn-glitch,
        .btn-primary {
            background: transparent;
            border: 2px solid var(--neon-cyan);
            color: var(--neon-cyan);
            font-family: 'Orbitron', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            padding: 0.75rem 2rem;
            border-radius: 8px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-glitch::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: var(--neon-cyan);
            transition: left 0.3s ease;
            z-index: -1;
        }

        .btn-glitch:hover::before,
        .btn-primary:hover::before {
            left: 0;
        }

        .btn-glitch:hover,
        .btn-primary:hover {
            color: var(--bg-deep-dark);
            box-shadow: 0 0 20px var(--neon-cyan-glow);
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: transparent;
            border: 2px solid var(--neon-violet);
            color: var(--neon-violet);
        }

        /* Animations */
        @keyframes slideUpFade {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes neonPulse {
            0%, 100% {
                text-shadow: 0 0 10px var(--neon-cyan-glow),
                             0 0 20px var(--neon-cyan-glow);
            }
            50% {
                text-shadow: 0 0 20px var(--neon-cyan-glow),
                             0 0 40px var(--neon-cyan-glow);
            }
        }

        .neon-text {
            color: var(--neon-cyan);
            text-shadow: 0 0 10px var(--neon-cyan-glow);
            animation: neonPulse 2s infinite;
        }

        /* Main Content Area */
        .main-content {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            padding: 2rem 0;
        }

        /* Navigation Bar */
        .navbar-gaming {
            background: var(--bg-glass);
            backdrop-filter: blur(20px);
            border-bottom: 2px solid var(--border-neon);
            padding: 1rem 0;
        }

        .navbar-gaming .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--neon-cyan);
            text-shadow: 0 0 10px var(--neon-cyan-glow);
        }

        .navbar-gaming .nav-link {
            color: var(--text-white);
            font-family: 'Rajdhani', sans-serif;
            font-weight: 600;
            font-size: 1.1rem;
            margin: 0 0.5rem;
            transition: all 0.3s ease;
        }

        .navbar-gaming .nav-link:hover {
            color: var(--neon-cyan);
            text-shadow: 0 0 10px var(--neon-cyan-glow);
        }

        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 10px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-deep-dark);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--neon-cyan);
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--neon-violet);
        }

        @yield('styles')
    </style>
</head>
<body>
    <!-- Floating Particles Background -->
    <div class="particles">
        <div class="particle" style="top: 10%; left: 20%; animation-delay: 0s;"></div>
        <div class="particle" style="top: 30%; left: 80%; animation-delay: 2s;"></div>
        <div class="particle" style="top: 50%; left: 50%; animation-delay: 4s;"></div>
        <div class="particle" style="top: 70%; left: 30%; animation-delay: 6s;"></div>
        <div class="particle" style="top: 20%; left: 60%; animation-delay: 8s;"></div>
        <div class="particle" style="top: 80%; left: 70%; animation-delay: 10s;"></div>
    </div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-gaming">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                <i class="fas fa-envelope-open-text me-2"></i>
                {{ config('app.name', 'Mail-ER') }}
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" style="border-color: var(--neon-cyan);">
                <i class="fas fa-bars" style="color: var(--neon-cyan);"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    @guest
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-sign-in-alt me-1"></i> Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-user-plus me-1"></i> Register
                            </a>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-user me-1"></i> {{ Auth::user()->name }}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt me-1"></i> Logout
                            </a>
                            <form id="logout-form" action="#" method="POST" class="d-none">
                                @csrf
                            </form>
                        </li>
                    @endguest
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        @yield('content')
    </main>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
    @yield('scripts')
</body>
</html>
