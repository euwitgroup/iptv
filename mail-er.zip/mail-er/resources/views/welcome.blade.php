<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail-ER - Installation Required</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;600;700&display=swap"
        rel="stylesheet">
    <style>
        :root {
            --primary-cyan: #00f3ff;
            --primary-violet: #bc13fe;
            --dark-bg: #050510;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #0a0a1e 0%, #1a1a2e 100%);
            font-family: 'Rajdhani', sans-serif;
            min-height: 100vh;
            color: #fff;
            overflow-x: hidden;
            position: relative;
        }

        /* Animated Background */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background: var(--primary-cyan);
            border-radius: 50%;
            animation: float 20s infinite;
            opacity: 0.3;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0) translateX(0);
            }

            50% {
                transform: translateY(-100vh) translateX(100px);
            }
        }

        .container {
            position: relative;
            z-index: 1;
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .logo-section {
            text-align: center;
            margin-bottom: 60px;
            animation: slideDown 0.8s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo-icon {
            font-size: 5rem;
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 20px;
            filter: drop-shadow(0 0 30px rgba(0, 243, 255, 0.5));
        }

        .logo-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 3.5rem;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-cyan) 0%, var(--primary-violet) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .logo-subtitle {
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.3rem;
            font-weight: 300;
        }

        .main-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(30px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 50px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 1s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .main-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-cyan), var(--primary-violet));
        }

        .status-badge {
            display: inline-block;
            background: rgba(255, 193, 7, 0.2);
            border: 2px solid #ffc107;
            color: #ffc107;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 700;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.9rem;
        }

        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #fff;
        }

        .lead {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 40px;
            line-height: 1.8;
        }

        .install-btn {
            background: linear-gradient(135deg, var(--primary-violet) 0%, #9b10d4 100%);
            border: none;
            color: #fff;
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 1.3rem;
            padding: 20px 50px;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 10px 30px rgba(188, 19, 254, 0.4);
            transition: all 0.3s ease;
            display: inline-block;
            text-decoration: none;
            position: relative;
            overflow: hidden;
        }

        .install-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .install-btn:hover::before {
            width: 300px;
            height: 300px;
        }

        .install-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(188, 19, 254, 0.6);
            color: #fff;
        }

        .install-btn i {
            margin-right: 10px;
            position: relative;
            z-index: 1;
        }

        .install-btn span {
            position: relative;
            z-index: 1;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin: 50px 0;
        }

        .feature-item {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 25px;
            transition: all 0.3s ease;
        }

        .feature-item:hover {
            background: rgba(0, 0, 0, 0.5);
            border-color: var(--primary-cyan);
            transform: translateY(-5px);
        }

        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .feature-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.1rem;
            margin-bottom: 10px;
            color: #fff;
        }

        .feature-desc {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .steps-section {
            margin: 50px 0;
        }

        .step-item {
            display: flex;
            align-items: start;
            margin-bottom: 25px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            border-left: 4px solid var(--primary-cyan);
        }

        .step-number {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5rem;
            font-weight: 700;
            margin-right: 20px;
            flex-shrink: 0;
        }

        .step-content h4 {
            font-family: 'Orbitron', sans-serif;
            margin-bottom: 8px;
            color: #fff;
        }

        .step-content p {
            color: rgba(255, 255, 255, 0.7);
            margin: 0;
            line-height: 1.6;
        }

        .docs-link {
            display: inline-block;
            color: var(--primary-cyan);
            text-decoration: none;
            font-weight: 600;
            margin-top: 10px;
            transition: all 0.3s;
        }

        .docs-link:hover {
            color: var(--primary-violet);
            text-decoration: underline;
        }

        .footer {
            text-align: center;
            margin-top: 60px;
            padding: 30px 0;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.5);
        }

        @media (max-width: 768px) {
            .logo-title {
                font-size: 2.5rem;
            }

            .main-card {
                padding: 30px 20px;
            }

            h1 {
                font-size: 2rem;
            }

            .install-btn {
                font-size: 1.1rem;
                padding: 16px 40px;
            }
        }
    </style>
</head>

<body>
    <!-- Animated Background Particles -->
    <div class="particles" id="particles"></div>

    <div class="container">
        <!-- Logo Section -->
        <div class="logo-section">
            <div class="logo-icon">
                <i class="fas fa-envelope-open-text"></i>
            </div>
            <h1 class="logo-title">Mail-ER</h1>
            <p class="logo-subtitle">Premium Disposable Email Service</p>
        </div>

        <!-- Main Installation Card -->
        <div class="main-card">
            <div class="text-center">
                <span class="status-badge">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Installation Required
                </span>
            </div>

            <h1 class="text-center">
                <i class="fas fa-rocket me-2" style="color: var(--primary-cyan);"></i>
                Welcome to Mail-ER
            </h1>

            <p class="lead text-center">
                Thank you for choosing Mail-ER! To get started, please run the quick installation wizard.<br>
                It will only take 2-3 minutes to complete.
            </p>

            <div class="text-center mb-5">
                <a href="/install" class="install-btn">
                    <i class="fas fa-play-circle"></i>
                    <span>Start Installation</span>
                </a>
            </div>

            <!-- Installation Steps -->
            <div class="steps-section">
                <h3 class="text-center mb-4" style="font-family: 'Orbitron', sans-serif;">
                    <i class="fas fa-list-check me-2"></i>Quick Installation Guide
                </h3>

                <div class="step-item">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h4>System Requirements</h4>
                        <p>The wizard will check PHP version, extensions, and directory permissions automatically.</p>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h4>Database Configuration</h4>
                        <p>Enter your MySQL database credentials. The wizard will test the connection and create all
                            tables.</p>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h4>Create Admin Account</h4>
                        <p>Set up your administrator account with a secure password to access the admin panel.</p>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h4>Automatic Optimization</h4>
                        <p>The wizard will optimize caches, create storage links, and configure your site for
                            production.</p>
                    </div>
                </div>
            </div>

            <!-- Features Grid -->
            <div class="features-grid">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h4 class="feature-title">5 Email Providers</h4>
                    <p class="feature-desc">Mail.tm, 1SecMail, Guerrilla Mail, DropMail.me, Mailsac</p>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-gauge-high"></i>
                    </div>
                    <h4 class="feature-title">Instant Setup</h4>
                    <p class="feature-desc">Fully automated installation in just 2-3 minutes</p>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-shield-halved"></i>
                    </div>
                    <h4 class="feature-title">Production Ready</h4>
                    <p class="feature-desc">Automatic security settings and optimization</p>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-palette"></i>
                    </div>
                    <h4 class="feature-title">Premium UI</h4>
                    <p class="feature-desc">Dark cyberpunk theme with glassmorphism</p>
                </div>
            </div>

            <!-- Documentation Links -->
            <div class="text-center mt-5">
                <p style="color: rgba(255, 255, 255, 0.7);">
                    <i class="fas fa-book me-2"></i>
                    Need help? Check out the documentation:
                </p>
                <a href="/INSTALLATION_WIZARD.md" class="docs-link me-3" target="_blank">
                    <i class="fas fa-file-alt me-1"></i> Installation Guide
                </a>
                <a href="/DEPLOYMENT_GUIDE.md" class="docs-link" target="_blank">
                    <i class="fas fa-file-alt me-1"></i> Deployment Guide
                </a>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>
                <i class="fas fa-code me-2"></i>
                Mail-ER v1.0.0 - Powered by Laravel 9 & Bootstrap 5
            </p>
            <p class="mb-0">
                <i class="fas fa-heart me-1" style="color: #e74c3c;"></i>
                Premium Disposable Email Service
            </p>
        </div>
    </div>

    <script>
        // Generate random particles
        const particlesContainer = document.getElementById('particles');
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 20 + 's';
            particle.style.animationDuration = (10 + Math.random() * 20) + 's';
            particlesContainer.appendChild(particle);
        }

        // Add pulse effect to install button
        const installBtn = document.querySelector('.install-btn');
        setInterval(() => {
            installBtn.style.boxShadow = '0 15px 50px rgba(188, 19, 254, 0.8)';
            setTimeout(() => {
                installBtn.style.boxShadow = '0 10px 30px rgba(188, 19, 254, 0.4)';
            }, 500);
        }, 2000);
    </script>
</body>

</html>