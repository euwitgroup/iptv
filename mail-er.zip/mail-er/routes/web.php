<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Installer Routes (No middleware - must be accessible before installation)
Route::prefix('install')->name('installer.')->group(function () {
    Route::get('/', [\App\Http\Controllers\InstallerController::class, 'welcome'])->name('welcome');
    Route::get('/requirements', [\App\Http\Controllers\InstallerController::class, 'requirements'])->name('requirements');
    Route::get('/database', [\App\Http\Controllers\InstallerController::class, 'database'])->name('database');
    Route::post('/database', [\App\Http\Controllers\InstallerController::class, 'databaseStore'])->name('database.store');
    Route::get('/admin', [\App\Http\Controllers\InstallerController::class, 'admin'])->name('admin');
    Route::post('/admin', [\App\Http\Controllers\InstallerController::class, 'adminStore'])->name('admin.store');
    Route::get('/finish', [\App\Http\Controllers\InstallerController::class, 'finish'])->name('finish');
    Route::post('/complete', [\App\Http\Controllers\InstallerController::class, 'complete'])->name('complete');
});

Route::get('/', [\App\Http\Controllers\Frontend\HomeController::class, 'index'])->name('home');

// Frontend Email Operations
// Frontend Email Operations
$prefix = request()->is('mail-er/*') ? 'mail-er/frontend/email-v2' : 'frontend/email-v2';

Route::prefix($prefix)->group(function () {
    Route::any('generate', [\App\Http\Controllers\Frontend\EmailController::class, 'generate'])->name('email.generate');
    Route::get('domains', [\App\Http\Controllers\Frontend\EmailController::class, 'domains'])->name('email.domains');
    Route::get('messages', [\App\Http\Controllers\Frontend\EmailController::class, 'messages'])->name('email.messages');
    Route::get('message/{id}', [\App\Http\Controllers\Frontend\EmailController::class, 'getMessage'])->name('email.message');
    Route::get('current', [\App\Http\Controllers\Frontend\EmailController::class, 'current'])->name('email.current');
});

// Dynamic Admin Route Prefix (Handles both XAMPP subdirectory and Artisan serve)
$adminPrefix = request()->is('mail-er/*') ? 'mail-er/admin' : 'admin';

Route::group(['prefix' => $adminPrefix, 'as' => 'admin.'], function () {

    // Auth Routes
    Route::get('login', [\App\Http\Controllers\Admin\AuthController::class, 'showLoginForm'])->name('login');
    Route::post('login', [\App\Http\Controllers\Admin\AuthController::class, 'login']);
    Route::post('logout', [\App\Http\Controllers\Admin\AuthController::class, 'logout'])->name('logout');
    Route::get('forgot-password', [\App\Http\Controllers\Admin\AuthController::class, 'showForgotPasswordForm'])->name('password.request');
    Route::post('forgot-password', [\App\Http\Controllers\Admin\AuthController::class, 'sendResetLink'])->name('password.email');

    // Protected Routes
    Route::middleware(['auth', 'admin'])->group(function () {
        Route::get('dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');

        // Resource Controllers
        Route::resource('providers', \App\Http\Controllers\Admin\ProviderController::class);
        Route::resource('users', \App\Http\Controllers\Admin\UserController::class);
        Route::resource('inbox', \App\Http\Controllers\Admin\InboxController::class)->only(['index', 'show']);
        Route::resource('pages', \App\Http\Controllers\Admin\PageController::class);

        // System Routes
        Route::get('reports', [\App\Http\Controllers\Admin\ReportController::class, 'index'])->name('reports.index');
        Route::get('settings', [\App\Http\Controllers\Admin\SettingController::class, 'index'])->name('settings.index');
        Route::put('settings', [\App\Http\Controllers\Admin\SettingController::class, 'update'])->name('settings.update');
    });
});

// Ads.txt Route
Route::get('/ads.txt', function () {
    $content = \App\Models\Setting::where('key', 'ads_txt')->value('value');
    return response(trim($content ?? ''), 200)->header('Content-Type', 'text/plain; charset=UTF-8');
});

// Storage File Route (Fallback if symlink fails)
Route::get('storage/{path}', function ($path) {
    $filePath = storage_path('app/public/' . $path);

    if (!file_exists($filePath)) {
        abort(404);
    }

    return response()->file($filePath);
})->where('path', '.*');

// Dynamic Pages (Must be last)
Route::get('/{slug}', [\App\Http\Controllers\Frontend\PageController::class, 'show'])->name('page.show');

// Fallback for debugging
Route::fallback(function () {
    return '404 - Page Not Found (Laravel handling). Path: ' . request()->path();
});
