<?php
    $s = \App\Models\Setting::all()->pluck('value', 'key');
    $title = $s['meta_title'] ?? $s['site_title'] ?? 'Mail-ER | Premium Disposable Email';
    $description = $s['meta_description'] ?? 'Secure temporary email service.';
    $keywords = $s['meta_keywords'] ?? 'temp mail, disposable email, privacy';
    $logo = isset($s['site_logo']) ? asset($s['site_logo']) : null;
    $favicon = isset($s['site_favicon']) ? asset($s['site_favicon']) : null;
    $url = url()->current();

    // Dynamic Pages
    $headerPages = \App\Models\Page::where('show_in_header', true)->where('is_published', true)->get();
    $footerPages = \App\Models\Page::where('show_in_footer', true)->where('is_published', true)->get();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', $title); ?></title>

    
    <meta name="description" content="<?php echo e($description); ?>">
    <meta name="keywords" content="<?php echo e($keywords); ?>">
    <link rel="canonical" href="<?php echo e($url); ?>">

    
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e($url); ?>">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', $title); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
    <?php if($logo): ?>
        <meta property="og:image" content="<?php echo e($logo); ?>">
    <?php endif; ?>

    
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo e($url); ?>">
    <meta property="twitter:title" content="<?php echo $__env->yieldContent('title', $title); ?>">
    <meta property="twitter:description" content="<?php echo e($description); ?>">
    <?php if($logo): ?>
        <meta property="twitter:image" content="<?php echo e($logo); ?>">
    <?php endif; ?>

    
    <?php if($favicon): ?>
        <link rel="icon" type="image/png" href="<?php echo e($favicon); ?>">
    <?php endif; ?>

    
    <?php echo $s['custom_header_scripts'] ?? ''; ?>


    
    <?php echo $s['adsense_auto_ads_code'] ?? ''; ?>


    
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        :root {
            --primary-cyan: #00f3ff;
            --primary-violet: #bc13fe;
            --dark-bg: #0a0e27;
            --light-bg: #ffffff;
            --gray-50: #f8f9fa;
            --gray-100: #e9ecef;
            --gray-200: #dee2e6;
            --gray-800: #1a1d29;
            --gray-900: #0f1419;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background: linear-gradient(135deg, #e8eaed 0%, #b8bfc9 100%);
            color: #1a1d29;
            min-height: 100vh;
            position: relative;
            display: flex;
            flex-direction: column;
        }

        /* Modern Animated Background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background:
                radial-gradient(circle at 20% 50%, rgba(0, 243, 255, 0.08) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(188, 19, 254, 0.08) 0%, transparent 50%);
            pointer-events: none;
            z-index: -1;
        }

        /* Professional Header */
        .navbar {
            background: rgba(5, 5, 16, 0.9);
            backdrop-filter: blur(20px) saturate(180%);
            -webkit-backdrop-filter: blur(20px) saturate(180%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3);
            padding: 1rem 0;
            transition: all 0.3s ease;
            border-bottom: 1px solid rgba(0, 243, 255, 0.1);
        }

        .navbar.scrolled {
            padding: 0.5rem 0;
            background: rgba(5, 5, 16, 0.98);
            box-shadow: 0 4px 30px rgba(0, 243, 255, 0.15);
        }

        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
            font-size: 1.75rem;
            color: #ffffff !important;
            letter-spacing: -0.5px;
            transition: all 0.3s ease;
        }

        .navbar-brand:hover {
            transform: translateY(-2px);
            text-shadow: 0 0 15px rgba(0, 243, 255, 0.5);
        }

        .navbar-brand .logo-icon {
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 2rem;
            margin-right: 8px;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.75) !important;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 8px 16px !important;
            margin: 0 2px;
            border-radius: 4px;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-link:hover,
        .nav-link.active {
            color: #fff !important;
            background: transparent;
            text-shadow: 0 0 10px rgba(0, 243, 255, 0.5);
        }

        .nav-link.active::after {
            content: '';
            display: block;
            width: 20px;
            height: 2px;
            background: var(--primary-cyan);
            margin: 4px auto 0;
            box-shadow: 0 0 10px var(--primary-cyan);
        }

        /* Premium Buttons */
        .btn-premium {
            background: linear-gradient(135deg, var(--primary-cyan) 0%, #00d4e6 100%);
            border: none;
            color: #000;
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 12px 32px;
            border-radius: 0;
            box-shadow: 0 4px 15px rgba(0, 243, 255, 0.3);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .btn-premium::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
            transition: left 0.5s;
        }

        .btn-premium:hover::before {
            left: 100%;
        }

        .btn-premium:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 243, 255, 0.5);
        }

        /* Hero Section */
        .hero-section {
            padding: 80px 0 60px;
            text-align: center;
        }

        .hero-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 3.5rem;
            font-weight: 900;
            margin-bottom: 1.5rem;
            line-height: 1.2;
            background: linear-gradient(135deg, var(--dark-bg) 0%, var(--primary-cyan) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-subtitle {
            font-size: 1.25rem;
            color: rgba(0, 0, 0, 0.6);
            margin-bottom: 3rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        /* Premium Card */
        .premium-card {
            background: rgba(250, 250, 250, 0.95);
            backdrop-filter: blur(30px) saturate(180%);
            -webkit-backdrop-filter: blur(30px) saturate(180%);
            border-radius: 0;
            padding: 48px;
            box-shadow:
                0 20px 60px rgba(0, 0, 0, 0.08),
                0 0 0 1px rgba(0, 0, 0, 0.05);
            border: 1px solid rgba(200, 200, 200, 0.3);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .premium-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-cyan), var(--primary-violet));
        }

        .premium-card:hover {
            transform: none;
            box-shadow:
                0 20px 60px rgba(0, 0, 0, 0.08),
                0 0 0 1px rgba(0, 0, 0, 0.05);
        }

        /* Form Elements */
        .form-select,
        .form-control {
            background: rgba(248, 249, 250, 0.8);
            border: 2px solid #e9ecef;
            color: #1a1d29;
            padding: 16px 20px;
            border-radius: 0;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .form-select:focus,
        .form-control:focus {
            outline: none;
            border-color: var(--primary-cyan);
            background: #ffffff;
            box-shadow:
                0 0 0 4px rgba(0, 243, 255, 0.1),
                inset 0 1px 2px rgba(0, 0, 0, 0.05);
            transform: translateY(-2px);
        }

        /* Action Buttons */
        .btn-action {
            background: linear-gradient(135deg, var(--primary-violet) 0%, #9b10d4 100%);
            border: none;
            color: #fff;
            font-weight: 700;
            padding: 16px 28px;
            border-radius: 24px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
            box-shadow: 0 4px 15px rgba(188, 19, 254, 0.3);
            transition: all 0.3s ease;
            font-family: 'Orbitron', sans-serif;
        }

        .btn-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(188, 19, 254, 0.5);
        }

        .btn-outline-custom {
            background: transparent;
            border: 2px solid var(--primary-cyan);
            color: var(--primary-cyan);
            font-weight: 700;
            padding: 14px 28px;
            border-radius: 24px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .btn-outline-custom:hover {
            background: var(--primary-cyan);
            color: #000;
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0, 243, 255, 0.4);
        }

        /* Professional Footer */
        footer {
            background: linear-gradient(135deg, #0a0e27 0%, #1a1d29 100%);
            color: rgba(255, 255, 255, 0.8);
            padding: 80px 0 40px;
            margin-top: 120px;
            position: relative;
        }

        footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-cyan), var(--primary-violet), var(--primary-cyan));
            background-size: 200% 100%;
            animation: gradientMove 3s ease infinite;
        }

        @keyframes gradientMove {

            0%,
            100% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }
        }

        .footer-brand {
            font-family: 'Orbitron', sans-serif;
            font-size: 2rem;
            font-weight: 900;
            margin-bottom: 1rem;
        }

        .footer-brand .logo-icon {
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .footer-links {
            display: flex;
            gap: 2rem;
            justify-content: center;
            flex-wrap: wrap;
            margin: 2rem 0;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            position: relative;
        }

        .footer-links a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-cyan);
            transition: width 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--primary-cyan);
        }

        .footer-links a:hover::after {
            width: 100%;
        }

        .social-links {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin: 2.5rem 0;
        }

        .social-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-size: 1.2rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid transparent;
        }

        .social-links a:hover {
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            color: #000;
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0, 243, 255, 0.4);
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 2rem;
            margin-top: 2rem;
            text-align: center;
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.9rem;
        }

        /* Utility Classes */
        .text-gradient {
            background: linear-gradient(135deg, var(--primary-cyan), var(--primary-violet));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Table Fixes */
        .table thead tr {
            border-bottom: none !important;
        }

        .table-hover tbody tr:hover {
            background-color: transparent !important;
        }

        .table th {
            border-bottom: none !important;
        }

        /* Text Visibility Fixes */
        p,
        .text-muted {
            color: #495057 !important;
            font-weight: 500;
        }

        .hero-subtitle {
            color: #495057 !important;
            font-weight: 500;
        }

        .footer-bottom {
            color: rgba(255, 255, 255, 0.7) !important;
        }

        .form-label {
            color: #212529;
            font-weight: 600;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }

            .premium-card {
                padding: 32px 24px;
            }

            .footer-links {
                flex-direction: column;
                gap: 1rem;
            }
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-in {
            animation: fadeInUp 0.8s ease-out backwards;
        }

        .animate-in-delay-1 {
            animation-delay: 0.1s;
        }

        .animate-in-delay-2 {
            animation-delay: 0.2s;
        }

        .animate-in-delay-3 {
            animation-delay: 0.3s;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php if($logo = \App\Models\Setting::where('key', 'site_logo')->value('value')): ?>
                    <img src="<?php echo e(asset($logo)); ?>" alt="Logo" style="height: 40px;">
                <?php else: ?>
                    <i class="fas fa-envelope-open-text logo-icon"></i>
                    <?php echo e(\App\Models\Setting::where('key', 'site_name')->value('value') ?? 'MAIL-ER'); ?>

                <?php endif; ?>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <i class="fas fa-bars" style="color: #fff;"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>"
                            href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <?php $__currentLoopData = $headerPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is($page->slug) ? 'active' : ''); ?>"
                                href="<?php echo e(url($page->slug)); ?>"><?php echo e($page->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="flex-grow-1" style="padding-top: 100px;">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer>
        <div class="container">
            <div class="text-center mb-5">
                <div class="footer-brand">
                    <?php if($logo = \App\Models\Setting::where('key', 'site_logo')->value('value')): ?>
                        <img src="<?php echo e(asset($logo)); ?>" alt="Logo" style="height: 50px;">
                    <?php else: ?>
                        <i class="fas fa-envelope-open-text logo-icon"></i>
                        <?php echo e(\App\Models\Setting::where('key', 'site_name')->value('value') ?? 'MAIL-ER'); ?>

                    <?php endif; ?>
                </div>
                <p class="text-muted mb-0">Secure, Fast, and Reliable Disposable Email Service</p>
            </div>

            <div class="social-links">
                <?php if($url = \App\Models\Setting::where('key', 'social_twitter')->value('value')): ?>
                    <a href="<?php echo e($url); ?>" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                <?php endif; ?>
                <?php if($url = \App\Models\Setting::where('key', 'social_facebook')->value('value')): ?>
                    <a href="<?php echo e($url); ?>" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
                <?php endif; ?>
                <?php if($url = \App\Models\Setting::where('key', 'social_telegram')->value('value')): ?>
                    <a href="<?php echo e($url); ?>" aria-label="Telegram"><i class="fab fa-telegram"></i></a>
                <?php endif; ?>
                <?php if($url = \App\Models\Setting::where('key', 'social_youtube')->value('value')): ?>
                    <a href="<?php echo e($url); ?>" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                <?php endif; ?>
                <?php if($url = \App\Models\Setting::where('key', 'social_whatsapp')->value('value')): ?>
                    <a href="<?php echo e($url); ?>" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                <?php endif; ?>
                <?php if($url = \App\Models\Setting::where('key', 'social_instagram')->value('value')): ?>
                    <a href="<?php echo e($url); ?>" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <?php endif; ?>
            </div>

            <div class="footer-links">
                <?php $__currentLoopData = $footerPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url($page->slug)); ?>"><?php echo e($page->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="footer-bottom">
                <p class="mb-0">
                    <?php echo \App\Models\Setting::where('key', 'footer_copyright')->value('value') ?? '&copy; ' . date('Y') . ' Mail-ER. All rights reserved.'; ?>

                </p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function () {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Copy to clipboard functionality
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function () {
                alert('Copied: ' + text);
            }, function (err) {
                console.error('Could not copy text: ', err);
            });
        }
    </script>
    
    <?php if($wa = \App\Models\Setting::where('key', 'plugin_whatsapp_number')->value('value')): ?>
        <a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $wa)); ?>" target="_blank"
            style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;">
            <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp"
                style="width: 50px; height: 50px;">
        </a>
    <?php endif; ?>

    <?php echo \App\Models\Setting::where('key', 'plugin_tawk_to_code')->value('value'); ?>


    
    <?php echo $__env->make('frontend.partials.cookie_consent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo \App\Models\Setting::where('key', 'custom_footer_scripts')->value('value'); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\mail-er\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>