

<?php $__env->startSection('content'); ?>
    
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-start">
                
                <div class="col-lg-2 d-none d-lg-block text-center sticky-top" style="top: 80px; z-index: 1;">
                    <?php if($ad = \App\Models\Setting::where('key', 'adsense_home_left')->value('value')): ?>
                        <div class="my-4">
                            <?php echo $ad; ?>

                        </div>
                    <?php else: ?>
                        
                        
                    <?php endif; ?>
                </div>

                
                <div class="col-lg-8">
                    <h1 class="hero-title animate-in">
                        Secure Disposable Email
                    </h1>
                    <p class="hero-subtitle animate-in animate-in-delay-1">
                        Protect your real email address from spam, phishing, and unwanted messages with our instant, secure
                        temporary email service.
                    </p>

                    
                    <?php if($ad = \App\Models\Setting::where('key', 'adsense_home_top')->value('value')): ?>
                        <div class="my-4 text-center">
                            <?php echo $ad; ?>

                        </div>
                    <?php endif; ?>

                    
                    <div class="premium-card animate-in animate-in-delay-2 mb-5">
                        <div class="row g-4 align-items-end">
                            <div class="col-lg-4">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-globe me-2 text-gradient"></i>Select Domain
                                </label>
                                <select id="domainSelect" class="form-select">
                                    <option value="" data-provider="">Random Domain</option>
                                </select>
                            </div>
                            <div class="col-lg-5">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-envelope me-2 text-gradient"></i>Your Email Address
                                </label>
                                <div class="position-relative">
                                    <input type="text" class="form-control" id="emailInput" value=""
                                        placeholder="Click Generate..." readonly>
                                    <div id="loadingSpinner"
                                        class="position-absolute top-50 start-50 translate-middle d-none">
                                        <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-bolt me-2 text-gradient"></i>Generate Email
                                </label>
                                <button class="btn btn-action w-100" onclick="generateEmail()">
                                    Generate
                                </button>
                            </div>
                        </div>

                        <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">
                            <button class="btn btn-outline-custom" onclick="copyEmail()">
                                <i class="far fa-copy me-2"></i>Copy Email
                            </button>
                            <button class="btn btn-outline-custom" onclick="checkInboxNow()">
                                <i class="fas fa-sync-alt me-2"></i>Refresh Inbox
                            </button>
                        </div>
                    </div>

                    
                    <div class="premium-card animate-in animate-in-delay-3">
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <h3 class="mb-0 fw-bold">
                                <i class="fas fa-inbox me-2 text-gradient"></i>Inbox
                            </h3>
                            <span class="badge bg-primary rounded-pill px-3 py-2" id="emailCount">0 messages</span>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr class="border-bottom">
                                        <th scope="col" class="px-3 py-3 text-muted" style="width: 25%;">From</th>
                                        <th scope="col" class="px-3 py-3 text-muted">Subject</th>
                                        <th scope="col" class="px-3 py-3 text-muted text-end" style="width: 20%;">Received
                                        </th>
                                        <th scope="col" class="px-3 py-3 text-center" style="width: 10%;"></th>
                                    </tr>
                                </thead>
                                <tbody id="inboxTableBody">
                                    
                                    <tr>
                                        <td colspan="4" class="text-center py-5">
                                            <div class="mb-3">
                                                <i class="fas fa-inbox fa-3x text-muted opacity-50"></i>
                                            </div>
                                            <p class="text-muted mb-0">No messages yet. Generate an email to get started!
                                            </p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

                
                <div class="col-lg-2 d-none d-lg-block text-center sticky-top" style="top: 80px; z-index: 1;">
                    <?php if($ad = \App\Models\Setting::where('key', 'adsense_home_right')->value('value')): ?>
                        <div class="my-4">
                            <?php echo $ad; ?>

                        </div>
                    <?php else: ?>
                        
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    
    <div class="modal fade" id="emailModal" tabindex="-1" aria-labelledby="emailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content" style="border-radius: 0; border: none;">
                <div class="modal-header"
                    style="border-bottom: 2px solid; border-image: linear-gradient(90deg, var(--primary-cyan), var(--primary-violet)) 1;">
                    <h5 class="modal-title fw-bold" id="emailModalLabel">
                        <i class="fas fa-envelope me-2 text-gradient"></i>Email Details
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-2">FROM</label>
                        <p class="fw-bold mb-0" id="modalFrom">-</p>
                    </div>
                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-2">SUBJECT</label>
                        <p class="fw-bold mb-0" id="modalSubject">-</p>
                    </div>
                    <div class="mb-4">
                        <label class="text-muted small fw-bold mb-2">RECEIVED</label>
                        <p class="text-muted mb-0" id="modalReceived">-</p>
                    </div>
                    <div class="mb-0">
                        <label class="text-muted small fw-bold mb-2">MESSAGE</label>
                        <div class="p-4"
                            style="background: rgba(248, 249, 250, 0.8); border: 1px solid #e9ecef; min-height: 200px;">
                            <div id="modalBody">Loading...</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid #e9ecef;">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <section class="py-5">
        <div class="container">

            
            <div class="text-center mb-5">
                <h2 class="fw-bold display-6 mb-3">Why Choose Mail-ER?</h2>
                <p class="text-muted lead">The most advanced temporary email service on the web</p>
            </div>

            <div class="row g-4 mb-5 pb-5">
                <div class="col-md-4">
                    <div class="premium-card h-100 text-center p-4">
                        <div class="mb-4">
                            <span class="d-inline-block p-3 rounded-circle bg-light">
                                <i class="fas fa-shield-alt fa-3x text-cyan"></i>
                            </span>
                        </div>
                        <h3 class="h4 mb-3 fw-bold">Privacy First</h3>
                        <p class="text-muted">
                            We don't log your IP addresses or track your personal data. Your anonymity is our priority.
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="premium-card h-100 text-center p-4">
                        <div class="mb-4">
                            <span class="d-inline-block p-3 rounded-circle bg-light">
                                <i class="fas fa-bolt fa-3x text-violet"></i>
                            </span>
                        </div>
                        <h3 class="h4 mb-3 fw-bold">Instant Routing</h3>
                        <p class="text-muted">
                            Emails arrive in milliseconds using our high-performance relay servers and globally distributed
                            network.
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="premium-card h-100 text-center p-4">
                        <div class="mb-4">
                            <span class="d-inline-block p-3 rounded-circle bg-light">
                                <i class="fas fa-trash-alt fa-3x text-dark"></i>
                            </span>
                        </div>
                        <h3 class="h4 mb-3 fw-bold">Auto Deletion</h3>
                        <p class="text-muted">
                            Emails are automatically wiped after 24 hours. Your digital footprint is clean, guaranteed.
                        </p>
                    </div>
                </div>
            </div>

            
            <div class="row justify-content-center mb-5 pb-5">
                <div class="col-12 text-center mb-5">
                    <h2 class="fw-bold display-6">How It Works</h2>
                    <p class="text-muted lead">Get started in 3 simple steps</p>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="position-relative p-4">
                        <div class="display-1 fw-bold text-light position-absolute top-0 start-50 translate-middle-x"
                            style="z-index:-1; opacity:0.1;">1</div>
                        <i class="fas fa-mouse-pointer fa-3x text-cyan mb-3"></i>
                        <h4 class="fw-bold">Select Domain</h4>
                        <p class="text-muted">Choose from our list of premium domains or use the random generator.</p>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="position-relative p-4">
                        <div class="display-1 fw-bold text-light position-absolute top-0 start-50 translate-middle-x"
                            style="z-index:-1; opacity:0.1;">2</div>
                        <i class="far fa-copy fa-3x text-violet mb-3"></i>
                        <h4 class="fw-bold">Copy Address</h4>
                        <p class="text-muted">Click the copy button to grab your new temporary email address instantly.</p>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="position-relative p-4">
                        <div class="display-1 fw-bold text-light position-absolute top-0 start-50 translate-middle-x"
                            style="z-index:-1; opacity:0.1;">3</div>
                        <i class="fas fa-envelope-open-text fa-3x text-success mb-3"></i>
                        <h4 class="fw-bold">Receive Mail</h4>
                        <p class="text-muted">Use it anywhere! Emails appear in your inbox automatically without refreshing.
                        </p>
                    </div>
                </div>
            </div>

            
            <div class="premium-card p-5 mb-5">
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <h2 class="fw-bold mb-4">What is Disposable Temporary E-mail?</h2>
                        <p class="text-muted mb-3">A disposable temporary email is a short-lived email address that
                            self-destructs after a certain period. It is also known as <strong>temp mail</strong>,
                            <strong>10 minute mail</strong>, or <strong>throwaway email</strong>.
                        </p>
                        <p class="text-muted mb-3">Using Mail-ER allows you to:</p>
                        <ul class="list-unstyled text-muted">
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Avoid spam in your
                                personal inbox.</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Sign up for services
                                without revealing your identity.</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Test software and
                                websites safely.</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Protect your privacy from
                                data leaks.</li>
                        </ul>
                        <a href="#emailInput" class="btn btn-premium mt-3"
                            onclick="window.scrollTo({top: 0, behavior: 'smooth'})">Get Your Temp Mail Now</a>
                    </div>
                    <div class="col-lg-6 text-center">
                        <img src="https://cdni.iconscout.com/illustration/premium/thumb/secure-data-protection-illustration-download-in-svg-png-gif-file-formats--security-safety-lock-cyber-pack-network-communication-illustrations-4363297.png"
                            alt="Privacy Illustration" class="img-fluid" style="max-height: 350px;">
                    </div>
                </div>
            </div>

            
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h2 class="fw-bold text-center mb-5 section-title">Frequently Asked Questions</h2>
                    <div class="accordion custom-accordion" id="faqAccordion">
                        <div class="accordion-item border-0 mb-3 shadow-sm rounded">
                            <h2 class="accordion-header">
                                <button class="accordion-button fw-bold" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#faq1">
                                    Is this service really free?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body text-muted">
                                    Yes! Mail-ER is 100% free to use. You can generate as many email addresses as you need
                                    without any cost or registration.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item border-0 mb-3 shadow-sm rounded">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#faq2">
                                    How long do email addresses last?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body text-muted">
                                    The email address itself is valid as long as you keep the tab open or until you manually
                                    change it. Received messages are automatically deleted after 24 hours.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item border-0 mb-3 shadow-sm rounded">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#faq3">
                                    Can I send emails?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body text-muted">
                                    Currently, Mail-ER is designed for receiving emails only. This helps us prevent abuse
                                    and keep our service free and reputable.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item border-0 mb-3 shadow-sm rounded">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#faq4">
                                    Is it private?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body text-muted">
                                    Absolutely. We do not track your IP address, we do not require any personal information,
                                    and all content is encrypted and then deleted permanently.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 text-center mb-4">
                    <h2 class="fw-bold section-title mb-2">
                        <i class="fas fa-handshake text-gradient me-2"></i>
                        Our API Partners
                    </h2>
                    <p class="text-muted">Powered by leading temporary email service providers</p>
                </div>
                <div class="col-12">
                    <div class="partners-grid">
                        
                        <a href="https://mail.tm" target="_blank" class="partner-card featured">
                            <div class="partner-logo-wrapper">
                                <i class="fas fa-star fa-3x text-warning"></i>
                            </div>
                            <h6 class="fw-bold mb-1 mt-3">Mail.tm</h6>
                            <small class="text-muted">Recommended Provider</small>
                            <span class="badge bg-success mt-2">Active</span>
                        </a>

                        
                        <a href="https://www.1secmail.com" target="_blank" class="partner-card">
                            <div class="partner-logo-wrapper">
                                <i class="fas fa-envelope-open-text fa-3x text-primary"></i>
                            </div>
                            <h6 class="fw-bold mb-1 mt-3">1SecMail</h6>
                            <small class="text-muted">Fast & Simple</small>
                            <span class="badge bg-success mt-2">Active</span>
                        </a>

                        
                        <a href="https://www.guerrillamail.com" target="_blank" class="partner-card">
                            <div class="partner-logo-wrapper">
                                <i class="fas fa-fighter-jet fa-3x text-danger"></i>
                            </div>
                            <h6 class="fw-bold mb-1 mt-3">Guerrilla Mail</h6>
                            <small class="text-muted">Trusted Since 2006</small>
                            <span class="badge bg-success mt-2">Active</span>
                        </a>

                        
                        <a href="https://dropmail.me" target="_blank" class="partner-card">
                            <div class="partner-logo-wrapper">
                                <i class="fas fa-droplet fa-3x text-info"></i>
                            </div>
                            <h6 class="fw-bold mb-1 mt-3">DropMail.me</h6>
                            <small class="text-muted">GraphQL API</small>
                            <span class="badge bg-success mt-2">Active</span>
                        </a>

                        
                        <a href="https://mailsac.com" target="_blank" class="partner-card">
                            <div class="partner-logo-wrapper">
                                <i class="fas fa-inbox fa-3x text-secondary"></i>
                            </div>
                            <h6 class="fw-bold mb-1 mt-3">Mailsac</h6>
                            <small class="text-muted">Public Inboxes</small>
                            <span class="badge bg-success mt-2">Active</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>



        </div>
    </section>

    
    <style>
        .partners-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 24px;
            padding: 20px 0;
        }

        .partner-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 16px;
            padding: 32px 20px;
            text-align: center;
            text-decoration: none;
            color: inherit;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }

        .partner-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-cyan), var(--primary-violet));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .partner-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.12);
            border-color: rgba(0, 243, 255, 0.3);
        }

        .partner-card:hover::before {
            opacity: 1;
        }

        .partner-logo-wrapper {
            width: 80px;
            height: 80px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .partner-card:hover .partner-logo-wrapper {
            transform: scale(1.1) rotate(5deg);
            background: linear-gradient(135deg, var(--primary-cyan) 0%, var(--primary-violet) 100%);
        }

        .partner-card:hover .partner-logo-wrapper i {
            color: white !important;
        }

        .partner-card h6 {
            font-size: 0.95rem;
            color: #1a1d29;
        }

        .partner-card small {
            font-size: 0.75rem;
        }

        @media (max-width: 768px) {
            .partners-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 16px;
            }

            .partner-card {
                padding: 24px 16px;
            }
        }
    </style>

    
    <?php if($ad = \App\Models\Setting::where('key', 'adsense_home_bottom')->value('value')): ?>
        <div class="container my-5 text-center">
            <?php echo $ad; ?>

        </div>
    <?php endif; ?>

    </div>

    
    <style>
        @keyframes rotate {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        .rotating {
            animation: rotate 1s linear infinite;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let pollInterval;

        // Initialize
        document.addEventListener('DOMContentLoaded', function () {
            fetchDomains();
            checkCurrentSession();
        });

        // 1. Check if user already has an active email in session
        function checkCurrentSession() {
            showLoading(true);
            fetch("<?php echo e(route('email.current')); ?>")
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.email) {
                        setEmailUI(data.email);
                        startPolling();
                    } else {
                        generateEmail(); // Auto generate for new visitor
                    }
                })
                .catch(err => {
                    console.error(err);
                    generateEmail();
                })
                .finally(() => showLoading(false));
        }

        // Fetch available domains
        function fetchDomains() {
            fetch("<?php echo e(route('email.domains')); ?>")
                .then(r => r.json())
                .then(data => {
                    const select = document.getElementById('domainSelect');
                    // select.innerHTML = '<option value="" data-provider="">Random Domain</option>'; // Reset
                    data.forEach(item => {
                        const opt = document.createElement('option');
                        opt.value = item.domain;
                        opt.dataset.provider = item.provider_slug;
                        opt.textContent = "@" + item.domain;
                        opt.style.background = "#050510"; // Ensure readability
                        opt.style.color = "#00f3ff";
                        select.appendChild(opt);
                    });
                })
                .catch(e => console.error(e));
        }

        // 2. Generate New Email
        function generateEmail() {
            showLoading(true);

            // Stop fetching old inbox
            if (pollInterval) clearInterval(pollInterval);
            document.getElementById('inboxTableBody').innerHTML = `
                                                                            <tr>
                                                                                <td colspan="4" class="text-center py-5 text-white-50">
                                                                                    <p class="mb-0">Generating new identity...</p>
                                                                                </td>
                                                                            </tr>`;

            const select = document.getElementById('domainSelect');
            const domain = select.value;
            const provider = select.options[select.selectedIndex]?.dataset.provider;

            let url = "<?php echo e(route('email.generate')); ?>";
            const params = new URLSearchParams();
            if (domain && provider) {
                params.append('domain', domain);
                params.append('provider', provider);
                url += "?" + params.toString();
            }

            fetch(url, {
                method: 'GET'
                // headers removed (CSRF exempted)
            })
                .then(async response => {
                    const text = await response.text();
                    try {
                        const data = JSON.parse(text);
                        if (data.success) {
                            setEmailUI(data.email);
                            startPolling();
                            renderEmptyInbox();
                        } else {
                            alert('Server Error: ' + (data.error || 'Unknown'));
                        }
                    } catch (e) {
                        console.error("Non-JSON:", text);
                        alert("Response Error: " + text.substring(0, 200));
                    }
                })
                .catch(err => {
                    alert('Network Error: ' + err);
                })
                .finally(() => showLoading(false));
        }

        // 3. UI Helpers
        function setEmailUI(email) {
            document.getElementById('emailInput').value = email;
        }

        function showLoading(isLoading) {
            const spinner = document.getElementById('loadingSpinner');
            const input = document.getElementById('emailInput');
            if (isLoading) {
                spinner.classList.remove('d-none');
                input.classList.add('opacity-50');
            } else {
                spinner.classList.add('d-none');
                input.classList.remove('opacity-50');
            }
        }

        function renderEmptyInbox() {
            const tbody = document.getElementById('inboxTableBody');
            tbody.innerHTML = `
                                                                            <tr>
                                                                                <td colspan="4" class="text-center py-5 text-white-50">
                                                                                    <div class="mb-2"><i class="fas fa-satellite-dish fa-2x opacity-50"></i></div>
                                                                                    <p class="mb-0">Waiting for incoming messages...</p>
                                                                                </td>
                                                                            </tr>`;
        }

        // 4. Polling & Messages
        function startPolling() {
            // Poll immediately then every 10s
            checkInboxNow();
            if (pollInterval) clearInterval(pollInterval);
            pollInterval = setInterval(checkInboxNow, 10000);
        }

        function checkInboxNow() {
            // Add rotating animation to refresh icon
            const refreshIcon = document.querySelector('button[onclick="checkInboxNow()"] i');
            if (refreshIcon) {
                refreshIcon.classList.add('rotating');
            }

            fetch("<?php echo e(route('email.messages')); ?>")
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateInboxTable(data.messages);
                    }
                })
                .catch(err => console.error('Polling error', err))
                .finally(() => {
                    // Remove rotation after 1 second
                    setTimeout(() => {
                        if (refreshIcon) {
                            refreshIcon.classList.remove('rotating');
                        }
                    }, 1000);
                });
        }

        function updateInboxTable(messages) {
            const tbody = document.getElementById('inboxTableBody');
            const countBadge = document.getElementById('emailCount');

            // Update count badge
            if (countBadge) {
                countBadge.textContent = messages.length + ' message' + (messages.length !== 1 ? 's' : '');
            }

            if (messages.length === 0) {
                // Only show empty state if currently empty/default
                if (!tbody.innerHTML.includes('No messages yet') && tbody.children.length === 0) {
                    renderEmptyInbox();
                }
                return;
            }

            // Re-render list (Simple implementation: clear and rebuild)
            // Optimization: In real app, diff the list.
            // Re-render list
            let html = '';
            const readMessages = getReadMessages();

            messages.forEach((msg, index) => {
                const displayFrom = cleanSenderName(msg.from || 'Unknown');
                const msgId = String(msg.id);
                const isRead = readMessages.includes(msgId);

                // Styling based on read status
                const weightClass = isRead ? 'fw-normal text-secondary' : 'fw-bold text-dark';
                const subjectClass = isRead ? 'fw-normal text-secondary' : 'fw-bold text-dark';
                const rowClass = isRead ? 'bg-light' : 'bg-white';
                const iconBtn = isRead ? 'btn-outline-secondary' : 'btn-primary';
                const iconClass = isRead ? 'fa-envelope-open' : 'fa-envelope';

                // Escape HTML tokens for safety after formatting
                const safeFrom = displayFrom.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                const subject = (msg.subject || '(No Subject)').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                // Prevent XSS in onclick JSON
                const msgData = JSON.stringify(msg).replace(/'/g, '&apos;').replace(/"/g, '&quot;');

                html += `
                                                    <tr class="align-middle ${rowClass}" style="cursor: pointer;" onclick='openEmailModal(${msgData})' id="row-${msgId}">
                                                        <td class="px-3 py-3 ${weightClass}">${safeFrom}</td>
                                                        <td class="px-3 py-3 ${subjectClass}">${subject}</td>
                                                        <td class="px-3 py-3 text-end text-muted small">${new Date().toLocaleTimeString()}</td>
                                                        <td class="px-3 py-3 text-center">
                                                            <button class="btn btn-sm ${iconBtn}">
                                                                <i class="fas ${iconClass}"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                `;
            });

            tbody.innerHTML = html;
        }

        // --- Read Status Helpers ---
        function getReadMessages() {
            try {
                return JSON.parse(localStorage.getItem('read_emails') || '[]');
            } catch (e) {
                return [];
            }
        }

        function markAsRead(id) {
            const msgId = String(id);
            const read = getReadMessages();
            if (!read.includes(msgId)) {
                read.push(msgId);
                localStorage.setItem('read_emails', JSON.stringify(read));

                // Update UI immediately if row exists
                const row = document.getElementById('row-' + msgId);
                if (row) {
                    row.classList.remove('bg-white');
                    row.classList.add('bg-light');

                    // Update cells
                    const cells = row.querySelectorAll('td');
                    if (cells.length > 1) { // 0: From, 1: Subject
                        cells[0].className = cells[0].className.replace('fw-bold text-dark', 'fw-normal text-secondary');
                        cells[1].className = cells[1].className.replace('fw-bold text-dark', 'fw-normal text-secondary');
                    }

                    // Update button
                    const btn = row.querySelector('.btn');
                    if (btn) {
                        btn.classList.remove('btn-primary');
                        btn.classList.add('btn-outline-secondary');
                        btn.innerHTML = '<i class="fas fa-envelope-open"></i>';
                    }
                }
            }
        }

        function cleanSenderName(from) {
            let displayFrom = from;

            // Format messy sender names
            // Check if it's "Name <email>" format
            if (displayFrom.includes('<')) {
                const match = displayFrom.match(/^"?([^"<]+)"?\s*</);
                if (match && match[1]) {
                    displayFrom = match[1].trim();
                }
            }
            // Check for raw bounce/system tracking emails (e.g. bounces+...@domain.com)
            else if (displayFrom.length > 25 && displayFrom.includes('@')) {
                const parts = displayFrom.split('@');
                const domain = parts[parts.length - 1];
                // Try to get the main domain (last 2 parts)
                const domainParts = domain.split('.');
                if (domainParts.length >= 2) {
                    displayFrom = domainParts.slice(-2).join('.');
                    // Capitalize first letter
                    displayFrom = displayFrom.charAt(0).toUpperCase() + displayFrom.slice(1);
                } else {
                    displayFrom = domain;
                }
            }
            return displayFrom;
        }

        // Open email detail modal
        function openEmailModal(message) {
            // Mark as read immediately
            if (message.id) {
                markAsRead(message.id);
            }

            // Populate modal with basic info
            document.getElementById('modalFrom').textContent = cleanSenderName(message.from || 'Unknown');
            document.getElementById('modalSubject').textContent = message.subject || '(No Subject)';
            document.getElementById('modalReceived').textContent = new Date(message.created_at || message.createdAt || Date.now()).toLocaleString();

            // Show intro or loading message
            const bodyContainer = document.getElementById('modalBody');
            if (message.intro) {
                bodyContainer.innerHTML = `<p>${message.intro}</p><p class="text-muted small mt-3"><i class="fas fa-spinner fa-spin me-2"></i>Loading full message...</p>`;
            } else {
                bodyContainer.innerHTML = '<p class="text-muted"><i class="fas fa-spinner fa-spin me-2"></i>Loading message content...</p>';
            }

            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('emailModal'));
            modal.show();

            // Fetch full message content if ID is available
            if (message.id) {
                fetch(`<?php echo e(route('email.message', ['id' => '__ID__'])); ?>`.replace('__ID__', message.id))
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.message) {
                            const msg = data.message;
                            // Display body content
                            let content = msg.body || msg.text || msg.textBody || msg.intro || '';
                            if (msg.html && Array.isArray(msg.html)) {
                                content = msg.html.join('<br>');
                            } else if (msg.html && typeof msg.html === 'string') {
                                content = msg.html;
                            } else if (msg.htmlBody) {
                                content = msg.htmlBody;
                            }

                            if (content) {
                                bodyContainer.innerHTML = content;
                            } else {
                                bodyContainer.innerHTML = '<p class="text-muted">No message content available</p>';
                            }
                        } else {
                            bodyContainer.innerHTML = '<p class="text-danger">Failed to load message content</p>';
                        }
                    })
                    .catch(err => {
                        console.error('Error fetching message:', err);
                        bodyContainer.innerHTML = '<p class="text-danger">Error loading message content</p>';
                    });
            } else {
                // No ID, show what we have
                bodyContainer.innerHTML = message.intro || '<p class="text-muted">No content available</p>';
            }
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                // Toast or visual feedback
                const btn = document.querySelector('button[onclick="copyEmail()"]');
                const originalHelp = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-check me-2"></i> Copied!';
                setTimeout(() => btn.innerHTML = originalHelp, 2000);
            });
        }

        // Wrapper function for copy button
        function copyEmail() {
            const email = document.getElementById('emailInput').value;
            if (email && email !== 'Click Generate...') {
                copyToClipboard(email);
            } else {
                alert('Please generate an email first!');
            }
        }

        function openInbox() {
            window.scrollTo({ top: document.querySelector('.table-responsive').offsetTop - 100, behavior: 'smooth' });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jaldhaka/public_html/resources/views/frontend/home.blade.php ENDPATH**/ ?>