<?php if(\App\Models\Setting::where('key', 'cookie_consent_enabled')->value('value')): ?>
    <div id="cookie-consent-banner" class="cookie-banner-wrapper" style="display: none;">
        <div
            class="glass-panel p-4 rounded-3 d-flex flex-column flex-md-row justify-content-between align-items-center gap-4">
            <div class="d-flex align-items-center gap-3">
                <div class="cookie-icon text-warning fs-2"><i class="fas fa-cookie-bite"></i></div>
                <div>
                    <h5 class="fw-bold text-white mb-1">We value your privacy</h5>
                    <p class="mb-0 text-white-50 small">
                        <?php echo e(\App\Models\Setting::where('key', 'cookie_consent_message')->value('value') ?? 'We use cookies to enhance your browsing experience and analyze our traffic.'); ?>

                        <a href="<?php echo e(url('privacy-policy')); ?>" class="text-cyan text-decoration-none ms-1">Privacy Policy</a>
                    </p>
                </div>
            </div>
            <div class="d-flex gap-2 align-items-center">
                <button id="btn-reject-cookies" class="btn btn-outline-light btn-sm px-3">
                    <?php echo e(\App\Models\Setting::where('key', 'cookie_consent_decline')->value('value') ?? 'Decline'); ?>

                </button>
                <button id="btn-accept-cookies" class="btn btn-primary btn-sm px-4 glow-effect">
                    <?php echo e(\App\Models\Setting::where('key', 'cookie_consent_agree')->value('value') ?? 'Accept'); ?>

                </button>
            </div>
        </div>
    </div>

    <style>
        .cookie-banner-wrapper {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            width: 90%;
            max-width: 900px;
            z-index: 10000;
            animation: slideUpCookie 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        .cookie-banner-wrapper .glass-panel {
            background: rgba(10, 14, 30, 0.9);
            backdrop-filter: blur(25px) saturate(180%);
            -webkit-backdrop-filter: blur(25px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-left: 4px solid var(--primary-cyan);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
        }

        .glow-effect {
            box-shadow: 0 0 15px rgba(0, 243, 255, 0.3);
        }

        @keyframes slideUpCookie {
            from {
                opacity: 0;
                transform: translate(-50%, 50px);
            }

            to {
                opacity: 1;
                transform: translate(-50%, 0);
            }
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const consent = localStorage.getItem('cookie_consent');

            if (!consent) {
                setTimeout(() => {
                    const banner = document.getElementById('cookie-consent-banner');
                    if (banner) banner.style.display = 'block';
                }, 1000);
            }

            const acceptBtn = document.getElementById('btn-accept-cookies');
            if (acceptBtn) {
                acceptBtn.addEventListener('click', function () {
                    localStorage.setItem('cookie_consent', 'accepted');
                    dismissBanner();
                });
            }

            const rejectBtn = document.getElementById('btn-reject-cookies');
            if (rejectBtn) {
                rejectBtn.addEventListener('click', function () {
                    localStorage.setItem('cookie_consent', 'rejected');
                    dismissBanner();
                });
            }

            function dismissBanner() {
                const banner = document.getElementById('cookie-consent-banner');
                banner.style.opacity = '0';
                banner.style.transform = 'translate(-50%, 20px)';
                banner.style.transition = 'all 0.5s ease';
                setTimeout(() => {
                    banner.style.display = 'none';
                }, 500);
            }
        });
    </script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mail-er\resources\views/frontend/partials/cookie_consent.blade.php ENDPATH**/ ?>