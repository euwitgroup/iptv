<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin - <?php echo e(\App\Models\Setting::where('key', 'site_name')->value('value') ?? 'Mail-ER'); ?></title>
    <?php if($favicon = \App\Models\Setting::where('key', 'site_favicon')->value('value')): ?>
        <link rel="icon" type="image/png" href="<?php echo e(asset($favicon)); ?>">
    <?php endif; ?>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>

    <style>
        :root {
            --header-bg: #2b3c4e;
            /* Dark Blue from image header */
            --sidebar-bg: #ffffff;
            --content-bg: #f5f7fb;
            /* Light gray background */
            --card-bg: #ffffff;
            --text-primary: #333333;
            --text-secondary: #888888;
            --active-blue: #007bff;
            --sidebar-width: 260px;
            --header-height: 60px;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--content-bg);
            color: var(--text-primary);
            min-height: 100vh;
            text-rendering: optimizeLegibility;
        }

        /* Top Header */
        .top-header {
            height: var(--header-height);
            background-color: var(--header-bg);
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
            display: flex;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .brand-logo {
            font-weight: 700;
            font-size: 1.25rem;
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
            width: var(--sidebar-width);
        }

        .brand-logo img {
            max-height: 40px;
            margin-right: 10px;
        }

        .header-search {
            flex-grow: 1;
            max-width: 400px;
        }

        .header-search input {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: #fff;
            padding: 8px 15px;
            border-radius: 4px;
            width: 100%;
        }

        .header-search input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            position: fixed;
            top: var(--header-height);
            bottom: 0;
            left: 0;
            background-color: var(--sidebar-bg);
            border-right: 1px solid #e1e4e8;
            z-index: 1020;
            overflow-y: auto;
            padding-bottom: 20px;
        }

        /* Sidebar User Profile Widget */
        .sidebar-user {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
        }

        .sidebar-user img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }

        .sidebar-user-info h6 {
            margin: 0;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .sidebar-user-info small {
            color: var(--text-secondary);
            font-size: 0.75rem;
        }

        /* Sidebar Menu */
        .sidebar-menu {
            padding: 15px 0;
        }

        .menu-category {
            font-size: 0.75rem;
            text-transform: uppercase;
            color: var(--text-secondary);
            padding: 10px 25px;
            font-weight: 600;
            letter-spacing: 0.5px;
            margin-top: 10px;
        }

        .nav-link {
            color: #555;
            padding: 10px 25px;
            display: flex;
            align-items: center;
            font-size: 0.9rem;
            font-weight: 500;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }

        .nav-link:hover {
            color: var(--active-blue);
            background-color: #f8f9fa;
        }

        .nav-link.active {
            color: var(--active-blue);
            background-color: #f0f7ff;
            border-left-color: var(--active-blue);
        }

        .nav-link i {
            width: 20px;
            margin-right: 10px;
            font-size: 1rem;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 30px;
            margin-top: var(--header-height);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .page-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: #2b3c4e;
            margin: 0;
        }

        .breadcrumb {
            margin-bottom: 5px;
            font-size: 0.8rem;
            color: var(--text-secondary);
            text-transform: uppercase;
        }

        .breadcrumb-item a {
            color: var(--text-secondary);
            text-decoration: none;
        }

        /* Cards - White Clean */
        .card {
            background: var(--card-bg);
            border: none;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
            margin-bottom: 20px;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            color: var(--text-secondary);
            font-size: 0.85rem;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 15px;
            letter-spacing: 0.5px;
        }

        .card-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2b3c4e;
            margin-bottom: 5px;
        }

        /* Alert Banner */
        .alert-warning-custom {
            background-color: #fff9e6;
            border: 1px solid #ffeeba;
            color: #856404;
            border-radius: 6px;
            padding: 12px 20px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
        }

        .alert-warning-custom i {
            margin-right: 10px;
            font-size: 1.1rem;
        }

        /* Buttons */
        .btn-success-custom {
            background-color: #4cd137;
            /* Bright green from image */
            border: none;
            color: #fff;
            padding: 8px 20px;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
        }

        .btn-success-custom:hover {
            background-color: #44bd32;
        }

        /* Chart Placeholder */
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
            background: #f8f9fa;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #aaa;
        }

        /* Avatar */
        .avatar-sm {
            width: 32px;
            height: 32px;
        }

        .avatar-md {
            width: 40px;
            height: 40px;
        }

        .rounded-circle {
            border-radius: 50% !important;
        }
    </style>
</head>

<body>

    
    <div class="top-header">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="brand-logo">
            <?php if($logo = \App\Models\Setting::where('key', 'site_logo')->value('value')): ?>
                <img src="<?php echo e(asset($logo)); ?>" alt="Logo">
            <?php else: ?>
                <i class="fas fa-layer-group me-2"></i>
                <?php echo e(\App\Models\Setting::where('key', 'site_name')->value('value') ?? 'Admin Panel'); ?>

            <?php endif; ?>
        </a>
        <div class="header-search d-none d-md-block ms-4">
            <input type="text" placeholder="Search...">
        </div>
        <div class="ms-auto d-flex align-items-center">
            <div class="dropdown me-3">
                <a href="#" class="text-white text-decoration-none">
                    <i class="far fa-bell"></i>
                </a>
            </div>
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle text-white"
                    data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(Auth::user()->name)); ?>&background=0d8abc&color=fff"
                        class="rounded-circle avatar-sm me-2" alt="User">
                    <span class="d-none d-sm-inline"><?php echo e(Auth::user()->name); ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                    <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2 text-muted"></i> Profile</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2 text-muted"></i> Settings</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="dropdown-item text-danger" type="submit">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    
    <div class="sidebar">
        
        <div class="sidebar-user">
            <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(Auth::user()->name)); ?>&background=random"
                alt="User">
            <div class="sidebar-user-info">
                <h6><?php echo e(Auth::user()->name); ?></h6>
                <small class="text-muted">Administrator</small>
            </div>
            <a href="#" class="ms-auto text-muted"><i class="fas fa-ellipsis-v"></i></a>
        </div>

        <div class="sidebar-menu">
            <div class="menu-category">Menu</div>

            <a href="<?php echo e(route('admin.dashboard')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <i class="fas fa-home"></i> Dashboards
            </a>

            <div class="menu-category">Apps</div>

            <a href="<?php echo e(route('admin.providers.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.providers.*') ? 'active' : ''); ?>">
                <i class="fas fa-server"></i> Providers
            </a>
            <a href="<?php echo e(route('admin.inbox.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.inbox.*') ? 'active' : ''); ?>">
                <i class="fas fa-envelope"></i> Inbox
            </a>
            <a href="<?php echo e(route('admin.users.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
                <i class="fas fa-users"></i> Users
            </a>

            <div class="menu-category">Content</div>

            <a href="<?php echo e(route('admin.pages.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.pages.*') ? 'active' : ''); ?>">
                <i class="fas fa-file-alt"></i> Pages
            </a>

            <div class="menu-category">System</div>

            <a href="<?php echo e(route('admin.reports.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="<?php echo e(route('admin.settings.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>">
                <i class="fas fa-cog"></i> Settings
            </a>
        </div>
    </div>

    
    <div class="main-content">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fas fa-check-circle me-2"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="fas fa-times-circle me-2"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session('warning')): ?>
            <div class="alert alert-warning alert-dismissible fade show shadow-sm" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo e(session('warning')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session('info')): ?>
            <div class="alert alert-info alert-dismissible fade show shadow-sm" role="alert">
                <i class="fas fa-info-circle me-2"></i> <?php echo e(session('info')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH /home/jaldhaka/public_html/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>