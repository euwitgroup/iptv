

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h1 class="page-title">System Reports</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Reports</li>
                </ol>
            </nav>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title text-muted">Total Emails Generated</h6>
                    <div class="card-value text-primary"><?php echo e(number_format($stats['total_emails'])); ?></div>
                    <div class="small <?php echo e($stats['emails_today'] > 0 ? 'text-success' : 'text-muted'); ?>">
                        <i class="fas fa-arrow-up"></i> <?php echo e(number_format($stats['emails_today'])); ?> today
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title text-muted">Messages Received</h6>
                    <div class="card-value text-success"><?php echo e(number_format($stats['total_messages'])); ?></div>
                    <div class="small <?php echo e($stats['messages_today'] > 0 ? 'text-success' : 'text-muted'); ?>">
                        <i class="fas fa-arrow-up"></i> <?php echo e(number_format($stats['messages_today'])); ?> today
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title text-muted">Active Providers</h6>
                    <div class="card-value text-info"><?php echo e($providerStats->count()); ?></div>
                    <div class="small text-muted">
                        Available for rotation
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-8 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Email Generation Trend (Last 7 Days)</h5>
                    <div class="chart-container" style="position: relative; height:300px;">
                        <canvas id="emailTrendChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Provider Popularity</h5>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Provider</th>
                                    <th class="text-end">Usage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $providerStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-light text-dark border"><?php echo e($stat->provider_slug); ?></span>
                                        </td>
                                        <td class="text-end fw-bold"><?php echo e(number_format($stat->count)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const ctx = document.getElementById('emailTrendChart').getContext('2d');
                const chart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode($chartData['labels'], 15, 512) ?>,
                        datasets: [{
                            label: 'Emails Generated',
                            data: <?php echo json_encode($chartData['data'], 15, 512) ?>,
                            borderColor: '#007bff',
                            backgroundColor: 'rgba(0, 123, 255, 0.1)',
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    color: '#f0f0f0'
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        }
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jaldhaka/public_html/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>